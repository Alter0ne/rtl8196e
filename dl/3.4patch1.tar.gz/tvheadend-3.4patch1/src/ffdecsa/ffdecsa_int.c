#define PARALLEL_MODE PARALLEL_32_INT
#include "FFdecsa.c"
