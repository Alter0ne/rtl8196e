#define PARALLEL_MODE PARALLEL_128_SSE2
#include "FFdecsa.c"
