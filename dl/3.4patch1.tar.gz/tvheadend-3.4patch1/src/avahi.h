void avahi_init(void);
