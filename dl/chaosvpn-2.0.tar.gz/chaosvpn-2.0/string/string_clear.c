#include "string.h"

void
string_clear(struct string*s)
{
	s->_u._s.length = 0;
}
