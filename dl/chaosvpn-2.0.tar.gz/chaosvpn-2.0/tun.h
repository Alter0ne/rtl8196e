#ifndef __TUN_H
#define __TUN_H

#define TUN_DEV   "/dev/net/tun"
#define TUN_PATH  "/dev/net"

extern int tun_check_or_create(); 

#endif
