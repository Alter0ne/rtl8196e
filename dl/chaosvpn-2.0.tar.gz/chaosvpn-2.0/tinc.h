#ifndef __TINC_H
#define __TINC_H

#include <sys/types.h>
#include "string/string.h"
#include "config.h"


#define TINC_DEFAULT_PORT "665"
/*
   ^^ Note: This 665 is a typo, it should have been 655 instead.
            But fixing this may mean creating imcompatibiliies between
            older versions of this program and current versions, peers
            using the default port would have to change their firewall
            rules - so just keep it.
            (The ancient perl version correctly used 655)
 */

#define TINC_DEFAULT_CIPHER "blowfish"
#define TINC_DEFAULT_COMPRESSION "0"
#define TINC_DEFAULT_DIGEST "sha1"

extern int tinc_write_config(struct config*);
extern int tinc_write_hosts(struct config *config);
extern int tinc_write_updown(struct config*, bool up);
extern int tinc_write_subnetupdown(struct config*, bool up);
extern char *tinc_get_version(struct config *config);
extern pid_t tinc_get_pid(struct config *config);

#endif
