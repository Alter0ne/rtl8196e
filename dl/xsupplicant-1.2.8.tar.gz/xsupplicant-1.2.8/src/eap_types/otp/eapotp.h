/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: eapotp.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _EAPOTP_H_
#define _EAPOTP_H_

#include "profile.h"

int eapotp_setup(struct generic_eap_data *);
int eapotp_process(struct generic_eap_data *, uint8_t *, int, uint8_t *, int *);
int eapotp_get_keys(struct interface_data *);
int eapotp_cleanup(struct generic_eap_data *);

#endif
