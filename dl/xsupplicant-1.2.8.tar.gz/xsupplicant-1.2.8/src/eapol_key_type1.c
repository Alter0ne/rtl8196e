/*******************************************************************
 * Handle keying for type 1 (RC4, non-TKIP) EAPOL Keys
 * File: eapol_key_type1.c
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 * $Id: eapol_key_type1.c,v 1.42 2006/10/05 22:33:28 chessing Exp $
 * $Date: 2006/10/05 22:33:28 $
 * $Log: eapol_key_type1.c,v $
 * Revision 1.42  2006/10/05 22:33:28  chessing
 * Proprietary Cisco LEAP functionality is now available to drivers that support it.
 *
 * Revision 1.41  2006/06/01 22:49:49  galimorerpg
 * Converted all instances of u_char to uint8_t
 * Fixed a bad #include in the generic frame handler.
 *
 * Revision 1.40  2006/05/26 22:04:58  chessing
 * Fixed some memory access errors, and cleaned up some wext stuff that was causing issues with the madwifi driver in wext mode.
 *
 * Revision 1.39  2006/05/24 18:42:22  chessing
 * Small fix from Carsten Grohman, and a few little fixes/changes from me.
 *
 * Revision 1.38  2006/05/13 05:56:44  chessing
 * Removed last pieces of code that relied on SIGALRM.  Active scan timeout is now configurable so that people that wish to hammer on their cards now have the option to do that. ;)
 *
 * Revision 1.37  2006/04/25 01:17:42  chessing
 * LOTS of code cleanups, new error checking/debugging code added, and other misc. fixes/changes.
 *
 * Revision 1.36  2005/10/17 03:56:53  chessing
 * Updates to the libxsupconfig library.  It no longer relies on other source from the main tree, so it can be used safely in other code with problems.
 *
 * Revision 1.35  2005/10/14 02:26:17  shaftoe
 * - cleanup gcc 4 warnings
 * - (re)add support for a pid in the form of /var/run/xsupplicant.<iface>.pid
 *
 * -- Eric Evans <eevans@sym-link.com>
 *
 * Revision 1.34  2005/08/25 03:40:28  chessing
 * Small fix to resolve an issue with some new code that would have broken wired connections.
 *
 * Revision 1.33  2005/08/25 03:34:05  chessing
 * Removed a bunch of functions from config.c that could be handled better in other ways.
 *
 * Revision 1.32  2005/08/09 01:39:14  chessing
 * Cleaned out old commit notes from the released version.  Added a few small features including the ability to disable the friendly warnings that are spit out.  (Such as the warning that is displayed when keys aren't rotated after 10 minutes.)  We should also be able to start when the interface is down.  Last, but not least, we can handle empty network configs.  (This may be useful for situations where there isn't a good reason to have a default network defined.)
 *
 *
 *******************************************************************/

#include <stdio.h>
#include <openssl/hmac.h>
#include <openssl/rc4.h>
#include <string.h>
#include <netinet/in.h>
#include "xsup_debug.h"
#include "xsup_err.h"
#include "frame_structs.h"
#include "cardif/cardif.h"
#include "key_statemachine.h"
#include "eapol_key_type1.h"
#include "xsupconfig.h"
#include "timer.h"

#ifdef USE_EFENCE
#include <efence.h>
#endif

int eapol_dump_keydata(char *inframe, int framesize)
{
  struct key_packet *keydata;
  uint16_t length;

  if (!xsup_assert((inframe != NULL), "inframe != NULL", FALSE))
    return XEMALLOC;

  keydata = (struct key_packet *)inframe;

  debug_printf(DEBUG_INT, "Key Descriptor   = %d\n",keydata->key_descr);

  memcpy(&length, keydata->key_length,2);
  debug_printf(DEBUG_INT, "Key Length       = %d\n",ntohs(length));
  debug_printf(DEBUG_INT, "Replay Counter   = ");
  debug_hex_printf(DEBUG_INT, keydata->replay_counter, 8);
  debug_printf(DEBUG_INT, "Key IV           = ");
  debug_hex_printf(DEBUG_INT, keydata->key_iv, 16);
  debug_printf(DEBUG_INT, "Key Index (RAW)  = %02X\n",keydata->key_index);
  debug_printf(DEBUG_INT, "Key Signature    = ");
  debug_hex_printf(DEBUG_INT, keydata->key_signature, 16);

  return XENONE;
}

/************************************
 *
 * Check the HMAC on the key packet we got.  If we can't validate the
 * HMAC, then we return FALSE, indicating an error.
 *
 ************************************/
int eapol_key_type1_check_hmac(struct interface_data *thisint, char *inframe,
			       int framesize)
{
  struct key_packet *keydata;
  char *framecpy, *calchmac;
  int outlen, retVal, length;

  if (!xsup_assert((thisint != NULL), "thisint != NULL", FALSE))
    return XEMALLOC;

  if (!xsup_assert((inframe != NULL), "inframe != NULL", FALSE))
    return XEMALLOC;

  framecpy = NULL;
  calchmac = NULL;
  keydata = NULL;
  outlen = 0;
  retVal = 0;
  length = 0;

  if (thisint->keyingMaterial == NULL)
    {
      debug_printf(DEBUG_EVERYTHING, "No keying material available!  Ignoring "
		   "key frame!\n");
      return XEMALLOC;
    }

  // First, make a copy of the frame.
  framecpy = (char *)malloc(framesize);
  if (framecpy == NULL) return XEMALLOC;

  memcpy(framecpy, inframe, framesize);

  // Now, we want to zero out the HMAC.
  keydata = (struct key_packet *)&framecpy[4];

  memcpy(&length, keydata->key_length, 2);

  bzero((char *)&keydata->key_signature, 16);

  // Once we have done that, we need to calculate the HMAC.
  calchmac = (char *)malloc(16);   // The resulting MAC is 16 bytes long.
  if (calchmac == NULL) return XEMALLOC;

  debug_printf(DEBUG_NORMAL, "HMACing (%d) : \n", framesize);
  debug_hex_dump(DEBUG_NORMAL, framecpy, framesize);

  debug_printf(DEBUG_NORMAL, "Using key (%d) : ", thisint->keyingLength);
  debug_hex_printf(DEBUG_NORMAL, thisint->keyingMaterial+32, thisint->keyingLength);

  HMAC(EVP_md5(), thisint->keyingMaterial+32, 
       thisint->keyingLength, (uint8_t *) framecpy, framesize, 
       (uint8_t *) calchmac, (u_int *) &outlen);

  // Now, we need to compare the calculated HMAC to the one sent to us.
  keydata = (struct key_packet *)&inframe[4];

  eapol_dump_keydata((char *)keydata, framesize);

  if (memcmp(calchmac, keydata->key_signature, 16) == 0)
    {
      // The HMAC is valid.
      retVal = TRUE;
    } else {
      retVal = FALSE;
    }

  // Clean up after ourselves.
  free(framecpy);
  framecpy = NULL;
  free(calchmac);
  calchmac = NULL;

  return retVal;
}

int eapol_key_type1_get_rc4(struct interface_data *thisint, uint8_t *enckey, 
			    uint8_t *deckey, int keylen, uint8_t *iv, int ivlen)
{
  uint8_t *wholekey = NULL;
  RC4_KEY key;

  if (!xsup_assert((thisint != NULL), "thisint != NULL", FALSE))
    return XEMALLOC;

  if (!xsup_assert((enckey != NULL), "enckey != NULL", FALSE))
    return XEMALLOC;

  if (!xsup_assert((deckey != NULL), "deckey != NULL", FALSE))
    return XEMALLOC;

  if (!xsup_assert((iv != NULL), "iv != NULL", FALSE))
    return XEMALLOC;

  wholekey = (uint8_t *)malloc(sizeof(uint8_t) * (ivlen + thisint->keyingLength));
  if (wholekey == NULL) return XEMALLOC;

  memcpy(wholekey, iv, ivlen);

  if (!thisint->keyingMaterial)
    {
      debug_printf(DEBUG_NORMAL, "Invalid keying material!  Keys will not be "
		   "handled correctly!\n");
      return XEMALLOC;
    }

  memcpy(wholekey + ivlen, thisint->keyingMaterial, thisint->keyingLength);

  RC4_set_key(&key, ivlen + thisint->keyingLength, wholekey);
  RC4(&key, keylen, enckey, deckey);

  if (wholekey)
    {
      free(wholekey);
      wholekey = NULL;
    }

  return XENONE;
}

/*********************************
 *
 * If our rekey timer expires, we should quietly remove it.  In the case of
 * this timer, we WANT it to expire with no events!  (Otherwise, the card
 * in use may have issues.)
 *
 *********************************/
void eapol_key_type1_clear_timer(struct interface_data *intdata)
{
  debug_printf(DEBUG_EVERYTHING, "Clearing rekey problem timer.  (This is "
	       "harmless!)\n");
  timer_cancel(REKEY_PROB_TIMER);
}

/*********************************
 *
 * Set up our timer to warn if the driver may have the card reset issue.
 *
 *********************************/
void eapol_key_type1_set_rekey_prob_timer()
{
  if (timer_check_existing(REKEY_PROB_TIMER))
    {
      debug_printf(DEBUG_NORMAL, "Less than %d seconds have elapsed since the "
		   "last key was set!  Either your AP has the rekey interval "
		   "set dangerously low, or your card may reset everytime new "
		   "keys are set!  Please check the rekey interval time on "
		   "your AP and report your card type, driver, and driver "
		   "version number to the list!\n", REKEY_PROB_TIMEOUT);
      timer_reset_timer_count(REKEY_PROB_TIMER, REKEY_PROB_TIMEOUT);
    } else {
      // There isn't an existing counter, so set up a new one.
      timer_add_timer(REKEY_PROB_TIMER, REKEY_PROB_TIMEOUT, NULL,
		      &eapol_key_type1_clear_timer);
    }
}

/*********************************
 *
 * Display the stale key warning, and disable the timer that was running.
 *
 *********************************/
void eapol_key_type1_stale_key_warn(struct interface_data *intdata)
{
  struct config_globals *globals;

  globals = config_get_globals();

  if (!xsup_assert((globals != NULL), "globals != NULL", FALSE))
    return;

  debug_printf(DEBUG_NORMAL, "Your unicast key has been in use for %d "
	       "minute(s).  Given the time it takes to crack WEP keys, your "
	       "data is now less secure than it was.  You should consider "
	       "asking your network administrator to lower the rekey interval"
	       " for your wireless network.\n\n"
	       " *** PLEASE NOTE ***  This is just a warning message, and does"
	       " not indicate that your WEP key has been broken!\n", 
	       (globals->stale_key_timeout/60));
  timer_cancel(STALE_KEY_WARN_TIMER);
}

/*********************************
 *
 * Set a timer that watches how long a key has been in use.  (Should only
 * be used for unicast keys, since broadcast keys aren't very secure to
 * begin with!)  If the timer expires, then we need to warn the user that
 * their security may be weaker than it used to be.
 *
 *********************************/
void eapol_key_type1_set_stale_key_warn_timer()
{
  struct config_globals *globals;

  globals = config_get_globals();

  if (!xsup_assert((globals != NULL), "globals != NULL", FALSE))
    return;

  if (timer_check_existing(STALE_KEY_WARN_TIMER))
    {
      timer_reset_timer_count(STALE_KEY_WARN_TIMER, 
			      globals->stale_key_timeout);
    } else {
      // Set up a new warning counter.
      timer_add_timer(STALE_KEY_WARN_TIMER, globals->stale_key_timeout, 
		      NULL, &eapol_key_type1_stale_key_warn);
    }
}

/*********************************
 *
 * Decrypt the key, and set it on the interface.  If there isn't a key to
 * decrypt, then use the peer key.
 *
 *********************************/
int eapol_key_type1_decrypt(struct interface_data *thisint, char *inframe,
			    int framesize)
{
  struct key_packet *keydata = NULL;
  int keylen, rc=0;
  uint16_t length;
  uint8_t *newkey = NULL, *enckey = NULL;
  struct config_globals *globals;

  if (!xsup_assert((thisint != NULL), "thisint != NULL", FALSE))
    return XEMALLOC;

  if (!xsup_assert((inframe != NULL), "inframe != NULL", FALSE))
    return XEMALLOC;

  keydata = (struct key_packet *)&inframe[0];

  memcpy(&length, keydata->key_length, 2);
  keylen = ntohs(length);

  debug_printf(DEBUG_INT, "EAPoL Key Processed: %s [%d] %d bytes.\n",
	       keydata->key_index & UNICAST_KEY ? "unicast" : "broadcast",
	       (keydata->key_index & KEY_INDEX)+1, keylen);

  if ((keylen != 0) && ((framesize)-sizeof(*keydata) >= keylen))
    {
      newkey = (uint8_t *)malloc(sizeof(uint8_t) * keylen);
      if (newkey == NULL) return XEMALLOC;

      enckey = (uint8_t *)&inframe[sizeof(struct key_packet)];

      debug_printf(DEBUG_INT, "Key before decryption : ");
      debug_hex_printf(DEBUG_INT, enckey, keylen);

      if (eapol_key_type1_get_rc4(thisint, enckey, newkey, keylen, 
				  keydata->key_iv, 16) != XENONE)
	{
	  debug_printf(DEBUG_NORMAL, "Couldn't decrypt new key!\n");
	  return XEBADKEY;
	}

      debug_printf(DEBUG_INT, "Key after decryption : ");
      debug_hex_printf(DEBUG_INT, newkey, keylen);

      if (cardif_set_wep_key(thisint, newkey, keylen, keydata->key_index)
	  != 0)
	{
	  rc = FALSE;
	} else {

	  //  If the unicast flag is set, start the warning timer.
	  if (keydata->key_index & 0x80)
	    {
	      debug_printf(DEBUG_NORMAL, "Set unicast WEP key. (%d bits)\n",
			   (keylen * 8));
	      eapol_key_type1_set_rekey_prob_timer();
	      eapol_key_type1_set_stale_key_warn_timer();
	    }
	  else
	    {
	      debug_printf(DEBUG_NORMAL, "Set broadcast/multicast WEP key. "
			   "(%d bits)\n", (keylen * 8));
	    }

	  rc = TRUE;
	  UNSET_FLAG(thisint->flags, ROAMED);
	}

      free(newkey);
      newkey = NULL;
    } else {
      debug_printf(DEBUG_INT, "Using peer key!\n");

      globals = config_get_globals();

      if (globals)
	{
	  if (!TEST_FLAG(globals->flags, CONFIG_GLOBALS_NO_FRIENDLY_WARNINGS))
	    {
	      debug_printf(DEBUG_NORMAL, "*WARNING* This AP uses the key "
			   "generated during the authentication\nprocess.  If "
			   "reauthentication doesn't happen frequently enough "
			   "your connection\nmay not be very secure!\n");
	    }
	}

      if (cardif_set_wep_key(thisint, thisint->keyingMaterial, keylen, 
			     keydata->key_index) != 0)
	{
	  rc = FALSE;
	} else {
	  rc = TRUE;

	  //  If the unicast flag is set, start the warning timer.
	  if (keydata->key_index & 0x80)
	    {
	      eapol_key_type1_set_rekey_prob_timer();
	      eapol_key_type1_set_stale_key_warn_timer();
	    }
	}
    }

  // If we reach this point, then we should remember the length of the
  // keys for later comparison.
  if (keydata->key_index & UNICAST_KEY)
    {
      thisint->statemachine->unicastKeyLen = keylen;
    } else {
      thisint->statemachine->broadcastKeyLen = keylen;
    }

  return rc;
}

/**********************************
 *
 * We are handed in an EAPoL key frame.  From that frame, we check the frame
 * to make sure it hasn't been changed in transit.  We then determine the 
 * correct key, and make the call to set it.
 *
 **********************************/
void eapol_key_type1_process(struct interface_data *thisint)
{
  struct key_packet *keydata;
  struct eapol_header *eapolheader;
  uint8_t *inframe;
  int framesize;
  int framelen;
  struct config_globals *globals;

  if (!xsup_assert((thisint != NULL), "thisint != NULL", FALSE))
    return;

  globals = config_get_globals();

  if (!xsup_assert((globals != NULL), "globals != NULL", FALSE))
    return;

  inframe = thisint->recvframe;
  framesize = thisint->recv_size;

  eapolheader = (struct eapol_header *)&inframe[OFFSET_PAST_MAC];

  framelen = ntohs(eapolheader->eapol_length);

  keydata = (struct key_packet *)&inframe[OFFSET_TO_EAPOL+4];

  if (keydata->key_descr != RC4_KEY_TYPE)
    {
      debug_printf(DEBUG_NORMAL, "Key type isn't RC4!\n");
      return;
    }

  if (eapol_key_type1_check_hmac(thisint, (char *)&inframe[OFFSET_TO_EAPOL], framelen+4)==FALSE)
    {
      debug_printf(DEBUG_NORMAL, "HMAC failed on key data!  This key will be discarded.\n");
      return;
      }

  if (eapol_key_type1_decrypt(thisint, (char *)&inframe[OFFSET_TO_EAPOL+4],
			      (framelen)) != TRUE)
    {
      debug_printf(DEBUG_NORMAL, "Failed to set wireless key!\n");
      return;
    }

  if ((thisint->statemachine->unicastKeyLen != 0) && 
      (thisint->statemachine->broadcastKeyLen != 0) &&
      (thisint->statemachine->unicastKeyLen != 
       thisint->statemachine->broadcastKeyLen))
    {

      if (!TEST_FLAG(globals->flags, CONFIG_GLOBALS_NO_FRIENDLY_WARNINGS))
	{
	  debug_printf(DEBUG_NORMAL, "[WARNING] Unicast and broadcast keys "
		       "are different lengths!  Some cards/drivers/APs do "
		       "not like this combination!\n");
	}
    }
  thisint->recv_size = 0;
}
