/**
 * General routines
 *
 * Licensed under the dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: xsup_common.c
 *
 * Authors: Carsten Grohmann
 *
 * $Id: xsup_common.c,v 1.1 2006/08/25 23:37:18 chessing Exp $
 * $Date: 2006/08/25 23:37:18 $
 * $Log: xsup_common.c,v $
 * Revision 1.1  2006/08/25 23:37:18  chessing
 * Numerous patches that have come in over the last month or two.
 *
 */

#include <string.h>

#ifdef USE_EFENCE
#include <efence.h>
#endif

char* Strncpy(char *dest, const char *src, size_t n)
{
  strncpy(dest, src, n);
  dest[n-1] = 0;
  return dest;
}
