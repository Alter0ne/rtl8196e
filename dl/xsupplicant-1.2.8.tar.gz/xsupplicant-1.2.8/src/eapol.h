/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: eapol.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _EAPOL_H_
#define _EAPOL_H_

#include "profile.h"

#define MAX_EAPOL_VER     2

// EAPOL Types
#define EAP_PACKET        0
#define EAPOL_START       1
#define EAPOL_LOGOFF      2
#define EAPOL_KEY         3
#define EAPOL_ASF_ALERT   4

int eapol_init(struct interface_data *);
int eapol_cleanup(struct interface_data *);
void eapol_build_header(int, int, int, char *);
int eapol_execute(struct interface_data *);
int eapol_withframe(struct interface_data *, int);
uint8_t eapol_get_eapol_ver();

#endif
