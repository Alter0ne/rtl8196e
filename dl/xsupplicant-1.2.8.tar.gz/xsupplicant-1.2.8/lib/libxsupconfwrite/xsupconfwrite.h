/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _XSUPCONFWRITE_H_
#define _XSUPCONFWRITE_H_

/* *** (public) Function defs  */

int xsupconfwrite_write_config(struct config_data *, char *);
char *xsupconfwrite_strerr(int);

/* *** Error codes */
#define XSUPCONFWRITE_ERRNONE        0

#define XSUPCONFWRITE_CHECKERRNO -1

#define XSUPCONFWRITE_GENIOERR  -2

#define XSUPCONFWRITE_INVALID_DEST  -3

#define XSUPCONFWRITE_BADNETLIST -4

#define XSUPCONFWRITE_NOFACILITY -5

#define XSUPCONFWRITE_NOFILEHANDLE -6

#define XSUPCONFWRITE_NOGLOBALDATA -7

#define XSUPCONFWRITE_NONETWORKDATA -8

#define XSUPCONFWRITE_NONETWORKNAME -9

#define XSUPCONFWRITE_INVALIDCRYPTO -10

#define XSUPCONFWRITE_NOEAPDATA -11

#define XSUPCONFWRITE_BADTTLSPHASE2 -12

#define XSUPCONFWRITE_NOPHASE2EAPDATA -13

#define XSUPCONFWRITE_INVALIDINNEREAP -14

#endif /* _XSUPCONFWRITE_H_ */
