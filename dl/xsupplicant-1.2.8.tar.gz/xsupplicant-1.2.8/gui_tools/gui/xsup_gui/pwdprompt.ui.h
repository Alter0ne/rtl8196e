/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/

void pwdPrompt::setDisplay(char *data, int len)
{
    char *eapMeth = NULL;
    char *chalTxt = NULL;
    
     // The format of the data will be [EAP method][\0](Challenge Text)(\0)
    eapMeth = data;
    
    if ((strlen(eapMeth)+1) != (unsigned int)len)
    {
	chalTxt = (char *)&data[strlen(eapMeth)+2];
    }
    
    eapMethod->setText(QString(eapMeth));
    challengeTxt->setText(QString(chalTxt));
}

void pwdPrompt::setPwd(char **pwd)
{
    mypwd = pwd;
}

void pwdPrompt::pwdOkay()
{
    printf("Password is %s\n", pwdEdit->text().ascii());
    (*mypwd) = strdup(pwdEdit->text().ascii());
    printf("Closing\n");
    close();
    return;
}
