extern "C" {
  #include "xsupconfig.h"
  #include "xsupconfcheck.h"
  #include "xsupconfwrite.h"
  #include "xsupgui.h"
}
