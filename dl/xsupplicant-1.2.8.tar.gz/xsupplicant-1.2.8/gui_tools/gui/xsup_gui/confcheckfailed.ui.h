/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/


void confCheckFailed::handleLogMsg(char *buf, int buflen)
{
    int bufptr = 0, cur;

    cur = bufptr;

    // Since QT doesn't know what to do with \n, we need to figure it out for it.
    while (cur < buflen)
    {
        if (buf[cur] == '\n')
        {
            buf[cur]= 0x00;

            cErrs->insertItem(QString(&buf[bufptr]), -1);

            bufptr = cur+1;
        }
        cur++;
    }

    if ((bufptr < buflen) && (buf[bufptr] != 0x00))
    {
        // We have one that we didn't do yet.
        cErrs->insertItem(QString(&buf[bufptr]), -1);

    }
}


void confCheckFailed::setErrors( cerrs *mycerrs )
{
    cerrs *cur;
    
    if (mycerrs == NULL)
    {
	printf("We were called, but there are no errors!?\n");
	return;
    }
    
    cErrs->setSelectionMode(QListBox::NoSelection);
    
    errs = mycerrs;
    
    cur = errs;
    
    while (cur)
    {
	handleLogMsg(cur->line, strlen(cur->line));

	cur = cur->next;
    }
}
