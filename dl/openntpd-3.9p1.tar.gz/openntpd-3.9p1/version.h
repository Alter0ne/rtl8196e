/* $Id: version.h,v 1.6 2006/05/14 05:27:48 dtucker Exp $ */

#define OPENNTPD_VERSION	"3.9"
