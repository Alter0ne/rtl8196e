#ifndef _COMMON_DEFINES_H_
#define _COMMON_DEFINES_H_

#define CONN_MODE1 1
#define CONN_MODE2 2

#define SERVERS_LIST_SIZE 50
#define ID_LIST_SIZE 100

#define MY_TMP_BUF_LEN 50

#define MAX_SESSIONS_DEFAULT 100 
#define MAX_SESSIONS_MIN 1
#define MAX_SESSIONS_MAX 1000   

#define LEVEL_0 0
#define LEVEL_1 1
#define LEVEL_2 2
#define LEVEL_3 3
#define DEFAULT_LOGGING_LEVEL  LEVEL_2

typedef struct addrParts
{
    int a;
    int b;
    int c;
    int d;
};


#endif
