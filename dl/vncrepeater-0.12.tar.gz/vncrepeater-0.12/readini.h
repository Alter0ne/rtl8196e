
#ifndef _READINI_H_
#define _READINI_H_

//variables
extern int viewerPort;

extern int serverPort;

extern int allowedModes;

extern int loggingLevel;

extern int allowedMode1ServerPort; 

extern int requireListedId;

extern int maxSessions;

extern int idList[];

extern int requireListedServer;

extern addrParts srvListAllow[];

extern addrParts srvListDeny[];

extern char listenerIpAddress[];

extern char runAsUser[];

//functions
addrParts getAddrPartsFromString(char *ipString);
bool readIniFile(char *iniFilePathAndName);

#endif
