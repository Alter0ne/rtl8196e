#ifndef REPEATERPROC_H
#define REPEATERPROC_H

extern int doRepeater(int server, int viewer);

#endif
