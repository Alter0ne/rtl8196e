#ifndef __JRANDOM_H__
#define __JRANDOM_H__

#include <sys/types.h>

typedef struct timeval TV;

#include <sys/time.h>
#include <unistd.h> 

enum {  NONE=0, USER, UNIFORM, NORMAL, EXPONENTIAL, 
	HEXPONENTIAL, TRIANG, CAUCHY, LOGNORMAL, 
	GAMMA, BETA, STATIC, MARKOV2D, POISSON };

#define RND_MAXPARAMS 7
#define RND_MAX_FUNCTIONS (POISSON+1)
#define RND_DEBUG


struct usergiven_distribution
{
	unsigned 	pos;
	size_t 		count;
	double 		values[1];
};

struct markov2d_dist
{
	unsigned	state;
	unsigned	iterations;
	struct timeval	time_state_entered;	
};

typedef struct random_distribution rdist;
typedef double distribution_function(const rdist *dist);

struct random_distribution
{
        unsigned short		name;
        short 		limits;
        distribution_function 	*nextval;
        double 		params[RND_MAXPARAMS];
	void		*userdata;
#ifdef RND_DEBUG
	size_t		gen_count;
#endif
};


extern	void	setup_rnd(unsigned short seed[3]);
extern	double	myrand(void);
extern	void	getseedval(unsigned short seed[3]);

extern distribution_function triangd;
extern distribution_function uniformd;
extern distribution_function normald;
extern distribution_function exponentiald;
extern distribution_function hexponentiald;
extern distribution_function cauchyd;
extern distribution_function lognormald;
extern distribution_function gammad;
extern distribution_function betad;
extern distribution_function userd;
extern distribution_function staticd;
extern distribution_function poissond;
extern distribution_function markov2d;
extern distribution_function noned;

extern size_t get_dtype_count(short name);
extern size_t get_overall_count(void);
extern size_t get_dist_count(const rdist *dist);

/** Function initializes the distribution correctly.
 *
 */
extern inline void init_dist(rdist *dist)
{
	int i;
	dist->name = NONE;
	dist->limits = 0;
	dist->nextval = noned;
	
	for (i = 0; i < RND_MAXPARAMS; i++)
		dist->params[i] = 0.0;

	dist->userdata = NULL;
#ifdef RND_DEBUG
	dist->gen_count = 0;
#endif /* RND_DEBUG */
}

/** Return difference between two timeval structures
 * 
 * The timeval passed as the second parameter is substracted from
 * the first parameter. The returned timeval has a negative 
 * tv_sec field if the second parameter is later than the first one.
 * The returned tv_usec field is never negative. The function can
 * handle unnormalized timevals correctly.
 *
 * @param timeval structure (substraction base)
 * @param timeval structure (substracted from base)
 *
 * @return Difference between parameters as a timeval structure.
 */

extern inline TV diff_tv(TV tv2, TV tv1)
{
    tv2.tv_usec -= tv1.tv_usec;
    if (tv2.tv_usec < 0) {
        tv2.tv_sec--;
        tv2.tv_usec += 1000000;
    }

    tv2.tv_sec -= tv1.tv_sec;
    return tv2;
}

/*
 * Compare two timeval structures
 *
 * Functions returns an integer less than, equal to or, greater than
 * zero if the parameter (base) is found to, respectively, to be earlier, 
 * same, or later than the second parameter.
 *
 * @param timeval structure (comparison base)
 * @param timeval structure (compared to base)
 *
 * @return An integer containing the result of the comparison
 */

extern inline int cmp_tv(TV tv2, TV tv1)
{
    TV tv = diff_tv(tv2, tv1);

    if (tv.tv_sec >= 0)
        return 1;
    if (!tv.tv_sec && !tv.tv_usec)
        return 0;
    return -1;
}

/*
 * Check if an event has occured.
 *
 */
  
extern inline int happened(TV tv_ev)
{
  TV tv;
  gettimeofday(&tv, NULL);
  return cmp_tv(tv, tv_ev) > 0;
}

/*
 * Add together two timeval structures
 *
 */

extern inline TV add_tv(TV tv1, TV tv2)
{
  tv1.tv_usec += tv2.tv_usec; 
  tv1.tv_sec += tv1.tv_usec / 1000000;
  tv1.tv_usec = tv1.tv_usec % 1000000;
  tv1.tv_sec += tv2.tv_sec;
             
  return tv1;
}

/*
 * Convert time from milliseconds to timeval.
 *
 * Works for time intervals, not for absolute time.
 *
 * @param msec time in milliseconds
 * @return converted time in timeval structure
 */  

extern inline TV ms2tv(long ms)
{
  struct timeval tv;
  tv.tv_sec=ms / 1000;
  tv.tv_usec=(ms % 1000) * 1000;
  return tv;
}

/*
 * Return current time plus time interval.
 *
 */

extern inline TV cur_time_rel(long ms)
{
  TV tv;
  gettimeofday(&tv, NULL);
  return add_tv(tv, ms2tv(ms));
}      

#endif /* __JRANDOM_H__ */
