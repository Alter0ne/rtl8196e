/* 
 *
 * 	Jugi's Traffic Generator
 *
 * o based on LTG (CoRiTel) which again is based on TTCP (classic),
 *   now mostly re-written
 * o Creates TCP or UDP (CBR and VBR) streams
 * o Possible to set the TOS/DSCP for flows
 * o receiver can be set to loop forever, listening for clients
 * o three variations for sleeping between sending UDP packets with a
 *   certain bitrate
 * o variations of how to send packets
 *   a) interval between every packet
 *   b) send b# of packets every "tick" micro seconds
 *   c) certain bandwidth
 *   d) take info from external files 
 * 
 *   See the readme for details on usage.
 *
 */

#include "jtg_vers.h"
#include "jtg.h"


            
int main(int argc, char *argv[])
{
    int i=0;
    int j=0;
    int optval=0, ret=0;
    socklen_t optlen=0;
    unsigned long diffis;
    long diff1=0,diff2=0,diff_p1=0;
    long diff3=0;
    unsigned long highest_pkt=0, lost_pckts=0;
    unsigned char prio=0;
    int op=0, args_found=1;
    char inet_ntop_buf[64];
    int tickset=0;
    int pcktspersecset=0;
    int superpriority=0;
    int small_pckts=0;	/* Did the transfer have only small packets? */
    int normalize_timestamps = 0;
    int have_base_time = 0;
    int gtod_ts = 0; /* gettimeofday-based direct timestamps */
    int nbuf_start = 0;

    FILE *pckt_fr=NULL;
    FILE *del_fr=NULL;
    
    if (argc < 2) goto usage;

    fr=stdout;
    
    if(signal(SIGINT,sigs) == SIG_ERR)
    {
         printf("Can't catch SIGINT\n");
         return -1;
    }

    if(setjmp(jmpbuffer) != 0){ goto finish;}

    i=0;

    while(tcpopts[i++].namelen != 0) tcpoptions++;


    /*
     * Start parsin the command line parameters, and enable certain flags and
     * set relevant parameters.
     *
     */ 

    while((op = getopt(argc,argv,"aA:b:B:d:D:e:f:F:gG:hikl:Lm:n:N:o:p:PqQrRs:S:tT:uvVwWx:y")) != -1)
    {
	args_found++;
        switch (op)
        {
            case 'a':
		a_method=2;
                break;
            case 'A':
                strncpy (a_host, optarg, strlen(optarg));
                a_method = 1;
                break;
            case 'b':
		udp=1;
                cbr_bw=atoi(optarg);
                break;
            case 'B':
                block = atoi(optarg);
		udp=1;
                break;
            case 'd':
                transfer_time=atof(optarg);
                break;
            case 'D':
            	burst_idle=atoi(optarg);
            	break;
            case 'e':
                end_time=atoi(optarg);
                break;
            case 'f':
                pckt_filename=optarg;
            	use_pckt_file=1;
		udp=1;
                break;
            case 'F':
                delay_filename=optarg;
		use_delay_file=1;
		udp=1;
                break;
            case 'g':
                gnuplot=1;
                break;
            case 'G':
                gnuplot=1;
		gnuplot_filename=optarg;
                break;
            case 'h':
                pusage(argv[0]);
                break;
            case 'i':
                normalize_timestamps = 1;
                break;
	    case 'I':
#ifdef USE_IPV6
	        strncpy (bind_ip6, optarg, strlen(optarg));
#else
	        strncpy (bind_ip4, optarg, strlen(optarg));
#endif
	        do_bind = 1;
	        break;
            case 'k':
                end_receiver = 1;
                break;
            case 'l':
                buf_tmp = atoi(optarg);
                break;
            case 'L':
                loop = 1;
                break;
            case 'm':
		pckts_per_sec=atof(optarg);
		pcktspersecset=1;
		trans=1;
		break;
            case 'n':
                nbuf = atoi(optarg);
                break;
            case 'N':
                loop_max = atoi(optarg);
                break;
            case 'o':
                prio=atoi(optarg);
                break;
            case 'p':
                port = atoi(optarg);
                break;
            case 'P':
                process_latency = 1;
                break;
            case 'q':
                quiet = 1;
                verb = 0;
                break;
            case 'Q':
            	quiet=1;
            	verb=0;
                logverb = 1;
		fr=stdout;
                break;
            case 'r':
                trans = 0;
                break;
	    case 'R':
	    	gtod_ts=1;
	    	break;
            case 's':
                if(parsetcpopt(optarg,0)==0)
                {
                  fprintf(stderr,"Unknown or malformed option: %s\n",optarg);
                  exit(0);
                }
                break;
            case 'S':
                if(parsetcpopt(optarg,1)==0)
                {
                  fprintf(stderr,"Unknown or malformed option: %s\n",optarg);
                  exit(0);
                }
                break;
            case 't':
                trans = 1;
                break;
            case 'T':
                tick=atoi(optarg);
		tickset=1;
                break;
            case 'u':
                udp = 1;
                break;
            case 'v':
                verb = 1;
                break;
            case 'V':
                verb = 2;
                break;
            case 'w':
                BUSYWAIT=1;
                OPEN=0;
                break;
            case 'W':
                SELECT=1;
                OPEN=0;
                break;
            case 'x':
              port_tx = atoi(optarg);
              if (port_tx == 0) check_port_tx = 0;
              break;
	    case 'y':
	      superpriority=1;
	      break;
            default:
		printf("Unknown parameter: %s\n",optarg);
		return 0;
        }
    }

    
    /* Some sanity checks about the parameters given by the user */
    
    if((cbr_bw && use_pckt_file) || (cbr_bw && use_delay_file))
    	err_exit("Can't give both \"-b\" and a file to read values from!",0);
    if(use_delay_file&&tick)
    	err_exit("Can't give both \"-T\" and a delay file to read values from!",0);    	
    if(use_pckt_file&&buf_tmp)
    	err_exit("Can't give both \"-l\" and a packet file to read values from!",0);

    if(cbr_bw&&buf_tmp&&tick)
        err_exit("Can't give all of \"-b\", \"-l\" and \"-T\"",0);
    if(cbr_bw&&!buf_tmp&&!tick)
        err_exit("With \"-b\", you must also give \"-l\" or \"-T\"",0);

    if(cbr_bw&&tickset&&pcktspersecset)
        err_exit("You can't give both \"-T\" and \"-m\"",0);

    if(pcktspersecset&&pckts_per_sec <= 0)
    	err_exit("Parameter for \"-m\" must be a positive integer",0);

    /* Initialization of internal variables based on the command line parameters */
  
    if(trans) buflen = (buf_tmp)? buf_tmp: WRITE_BUF;
    else buflen = (buf_tmp)? buf_tmp: READ_BUF;
    
    if(!use_pckt_file)
    {
      dataa = nbuf*buflen;
#ifdef USE_IPV6
      if(udp) ipdataa = nbuf*(buflen+IP6_HEADER_SIZE+UDP_HEADER_SIZE);
      else ipdataa = nbuf*(buflen+IP6_HEADER_SIZE+TCP_HEADER_SIZE);
#else
      if(udp) ipdataa = nbuf*(buflen+IP_HEADER_SIZE+UDP_HEADER_SIZE);
      else ipdataa = nbuf*(buflen+IP_HEADER_SIZE+TCP_HEADER_SIZE);
#endif
    }

    if(pcktspersecset)
    	tick = (1000000/pckts_per_sec);

    if(udp&&trans&&!use_pckt_file&&!use_delay_file)
    {
	if(cbr_bw&&buf_tmp)
	{
            /* # of packets in one second
             * interval to get # of pckts in one second
             */
            tick = 1000000.0 / (cbr_bw*1.0/(buflen*8.0));
            block = 1;
	}
	else if(cbr_bw&&tick)
	{
            /* # of packets in one second
             * interval to get # of pckts in one second
             */
            buflen = (cbr_bw / (1000000/tick))/8;
	    if(buflen > MTU) err_exit("Packet size will get too big",0);
            block = 1;
	}
	else
	{
	    if(!tick) tick=TICK;
	    cbr_bw =  (1000000/tick)*block*buflen*8.0;
	}

	if(!pcktspersecset)
	    pckts_per_sec = (float) (1000000.0/tick)*block;
#ifdef USE_IPV6
        ip_bw = pckts_per_sec * (buflen+IP6_HEADER_SIZE+UDP_HEADER_SIZE)*8;
#else
        ip_bw = pckts_per_sec * (buflen+IP_HEADER_SIZE+UDP_HEADER_SIZE)*8;
#endif

	/* If verbose mode, print the values to be used for packet transfer */

	if(verb)
	{
		printf("block %d, ",block);
		if(!use_pckt_file) printf("buflen %d, ",buflen);
		if(!use_pckt_file) printf("bits/pckt %d\n",buflen*8);
		if(!use_delay_file) printf("tick %d us, ",tick);
		if(!use_delay_file) printf("ticks in one sec %.1f\n",1000000.0/tick);
		if(!use_delay_file) printf("pkcts per sec %.1f, ",pckts_per_sec);
		if((!use_delay_file) && (!use_pckt_file))
		{
		  printf("bw per sec %.1f kbps\n",(1000000.0/tick)*block*buflen*8.0);
		  printf("blocks from bw value %d (%d)\n",(cbr_bw)/((1000000/tick)*buflen*8),block);
		}
		if((transfer_time == 0.0) && (dataa>0))
		{
			printf("User data to be sent: %lu B (%lu b)\n",dataa,dataa*8);
			printf("IP data to be sent: %lu B (%lu b)\n",ipdataa,ipdataa*8);
		}
		else if(transfer_time > 0.0)
			printf("User data to be sent for %.3f seconds\n",transfer_time);

	}	
	packets=nbuf;
    }

    if(trans) 	/* transmitting node code, set up destination variables */
    {
	if(!tick) tick=TICK;
        if (optind == argc) {printf("Missing destination address\n"); return -1;}
        memset((char *) &sinhim,0,sizeof(sinhim));

        host = argv[argc-1];

#ifdef USE_IPV6
        if ((addr=gethostbyname(host)) == NULL)  err("bad hostname");
        memcpy((char *) &sinhim.sin6_addr, addr->h_addr, addr->h_length);
	sinhim.sin6_family = addr->h_addrtype;
        sinhim.sin6_port = htons(port);

        if (check_port_tx)      
	    sinme.sin6_port = htons(port_tx);        /* user choice */
	else	
	    sinme.sin6_port = 0;            		/* free choice */
        /* bind the sending socket to specified address */
        if (do_bind)
        {
          if (atoi (bind_ip6) > 0)
          {
            /* Numeric */
            if ((addr=gethostbyname(bind_ip6)) == NULL)  err("bad hostname");
            memcpy((char *) &sinme.sin6_addr, addr->h_addr, addr->h_length);
	    sinme.sin6_family = addr->h_addrtype;
          }
        }
#else
        if (atoi(host) > 0 )
        {
            /* Numeric */
            sinhim.sin_family = AF_INET;
            sinhim.sin_addr.s_addr = inet_addr(host);
        } 
        else
        {
            if ((addr=gethostbyname(host)) == NULL)
                err("bad hostname");
            sinhim.sin_family = addr->h_addrtype;
	    memcpy((char *) & sinhim.sin_addr, addr->h_addr,addr->h_length);
        }
        sinhim.sin_port = htons(port);
        if (check_port_tx)      
	    sinme.sin_port = htons(port_tx);        /* user choice */
	else	
	    sinme.sin_port = 0;            		/* free choice */

        /* bind the sending socket to specified address */
        if (do_bind)
        {
          if (atoi (bind_ip4) > 0)
          {
            /* Numeric */
            sinme.sin_family = AF_INET;
            sinme.sin_addr.s_addr = inet_addr(bind_ip4);
          }
        }
#endif	    	    
    } 
    else             /* receiver, set up destination port */
#ifdef USE_IPV6
    	sinme.sin6_port =  htons(port);
#else
    	sinme.sin_port =  htons(port);
#endif


    /* set up receiver and sender buffer */   
    if(buflen <= 0) err("buflen");
    
    buf = (char *) malloc(buflen);
    if( buf  == (char *)NULL)
        err("malloc");

    bzero(buf,buflen);


    if(!quiet)
    fprintf(stderr,"jtg%s: nbuf=%d, buflen=%d, port=%d\n",
                trans?"-t":"-r",nbuf, (use_pckt_file)? 0: buflen, port);

    /* create socket */
    
#ifdef USE_IPV6
    if ((fd = socket(PF_INET6, udp?SOCK_DGRAM:SOCK_STREAM, 0)) < 0)
        err("socket");
#else
    if ((fd = socket(PF_INET, udp?SOCK_DGRAM:SOCK_STREAM, 0)) < 0)
        err("socket");
#endif
     
    if(!quiet)
        udp?mes("socket (udp)"):mes("socket (tcp)");

    if(!trans && (verb==2) && udp && !quiet) mes("extra verbose logging");

    setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&optval,optlen);

    if(!quiet)
    if(trans&&udp&&!use_pckt_file&&!use_delay_file)
    	fprintf(stderr,"jtg%s: CBR stream target bandwidths:\n\
    	%.1f Kbit/s (data) and \n\
    	%.1f Kbit/s with IP+UDP headers\n",
        trans?"-t":"-r",cbr_bw/1000.0, ip_bw/1000.0);

    optval = prio;
    optlen = sizeof(optval);

    /* Shift left two places due to the ECN bits */
    optval=prio<<2;

    if(!quiet)
    if(prio)
        fprintf(stderr,"jtg%s: -o%u specified: 0x%x (after shift 0x%x)\n",
        trans?"-t":"-r",prio,prio,optval);

    if(prio) /* set up possible priority of the transfer */
    {
        ret = setsockopt(fd,IPPROTO_IP,IP_TOS, &optval, sizeof(optval));
	if(ret == -1){ perror("jtg-t: Setting the DSCP/TOS byte failed"); return 0;}
    }

/* Check if TCP options must be set */

    if(tcpoptionsset)
    {
      if(settcpopts(fd)==0)
        err_exit("Error in setting TCP options",1);
      else if(verb)
      {
      	fprintf(stderr,"jtg%s: TCP options set:\n",(trans?"-t":"-r"));
	printtcpopts();
      }
    }

    if (bind(fd, (struct sockaddr*) &sinme, sizeof(sinme)) < 0)
        err("bind");
    
back:      

    rx_num=0;
    
    if(loop) loop_n++;
    
    if((gnuplot) && (!trans) && (!loop))
    {
      filename=gnuplot_filename;	
      verb=1;
      fr=fopen(filename,"w+");
      if(fr==NULL) err("unable to open gnuplot file");
    }
    else if ((gnuplot) && (!trans) && (loop))
    {
        filename = gnuplot_filename;
        verb=1;
        loop_filename=malloc(strlen(filename)+4);
        sprintf(loop_filename,"%s.%d",filename,loop_n);
        fr = fopen(loop_filename,"w+");
        if(fr==NULL) err("unable to open gnuplot loop file");
        if(!udp) tcplog=1;
    }
    else if ((!trans) && (!logverb) && (optind < argc))
    {
        filename = argv[argc-1];
        if (strlen(filename)<1)
        {
          fr=stdout;
	  filename=NULL;
	  loop_filename=NULL;
	  if(!udp) tcplog=1;
        }
        else if(loop)
        {
	  verb=1;
          loop_filename=malloc(strlen(filename)+4);
	  sprintf(loop_filename,"%s.%d",filename,loop_n);
          fr = fopen(loop_filename,"w+");
          if(fr==NULL) err("unable to open loop file");
	  if(!udp) tcplog=1;
        }
        else
        {
          verb=1;
	  fr = fopen(filename,"w+");
	  loop_filename=NULL;
          if(fr==NULL) err("unable to open data file");
	  if(!udp) tcplog=1;	  
	}
    }

    if(logverb&&!udp) tcplog=1;
    if(gnuplot&&!udp) tcplog=1;

    if(udp && !quiet)
    {
        sockaddrlen = sizeof (sock_name);
        if(getsockname(fd, (struct sockaddr*)&sock_name, &sockaddrlen)==0)
#ifdef USE_IPV6
        fprintf(stderr,"jtg%s: local port %d \n", trans?"-t":"-r", htons(sock_name.sin6_port));
#else
        fprintf(stderr,"jtg%s: local port %d \n", trans?"-t":"-r", htons(sock_name.sin_port));
#endif

    }    
        
    if(!quiet)
    if(!trans)    fprintf(stderr,"jtg%s: waiting for a new client",trans?"-t":"-r");
    fflush(stdout);

    if (!udp)  /* Operate on TCP */
    {
        if (trans) 
        {
            /* We are the client if transmitting */
            if(options)
            {
                if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
                     err("setsockopt");
            }
         
              if(connect(fd, (struct sockaddr*) &sinhim, sizeof(sinhim) ) < 0)
                err("connect");
            if(!quiet) mes("connect");
        
            sockaddrlen = sizeof (sock_name);
            if (getsockname(fd, (struct sockaddr*)&sock_name, &sockaddrlen)==0)
            {
#ifdef USE_IPV6
            	if(!quiet) fprintf(stderr,"jtg%s: local port %d \n", trans?"-t":"-r", htons(sock_name.sin6_port));
#else
            	if(!quiet) fprintf(stderr,"jtg%s: local port %d \n", trans?"-t":"-r", htons(sock_name.sin_port));
#endif
            }
            else
            fprintf(stderr,"error getsockname\n");        
        } /* end if(trans) */
        else 
        {
            /* otherwise, we are the server and 
            * should listen for the connections
            */

            listen(fd, 0);   /* allow a queue of 0 */

            if(options)
            {
                if( setsockopt(fd, SOL_SOCKET, options, &one, sizeof(one)) < 0)
                    err("setsockopt");
            }

            fromlen = sizeof(frominet);
            domain = AF_INET;
            if((rfd = accept(fd, (struct sockaddr*)&frominet, &fromlen) ) < 0)
                err("accept");

            if(!quiet) fprintf(stderr," > accept");
        }
    }

    prep_timer();

    errno = 0;

    /*
     * get the time of day just before the transfer begins, used later
     * for some calculations
     *
     */
    
    if(!quiet)
    if(trans)
    {
	if(use_pckt_file && !use_delay_file)
		fprintf(stderr,"jtg-t: sending pckts every %.1f ms, pckt size from %s\n",
		tick/1000.0,pckt_filename);
	else if(!use_pckt_file && use_delay_file)
		fprintf(stderr,"jtg-t: sending %d sized packets with an interval from %s\n",
		buflen,delay_filename);
	else if(use_pckt_file && use_delay_file)
		fprintf(stderr,"jtg-t: sending pattern taken from %s and %s\n",pckt_filename,delay_filename);
        else if(udp)
        {
            char str[16];
            int i=0, s=0;
            sprintf(&str[0],"%.1f",tick/1000.0);
            fprintf(stderr,"jtg-t: Sending model:\n");        
            while(s<(64-block))
            {
                for(i=0;i<block;i++,s++)
                    fprintf(stderr,"#");
                fprintf(stderr," %.1fms ",tick/1000.0);
                s+=strlen(str)+4;
            }
            fprintf(stderr,"\n");
        }
        else
            fprintf(stderr,"jtg-t: Sending a byte stream at full speed...");
    }


   /*
    *  Tuomas 31.01.2003, enhanced by Jukka 01.03.2003
    *  Open TCP-connection to server via alternative route. Keep it open until
    *  UDP transfer is ready.
    *
    */

    if (udp && a_method)
    {
      if(trans)
      {
#ifdef USE_IPV6
        if ((a_fd = socket(AF_INET6, SOCK_STREAM, 0)) < 0)
#else
        if ((a_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
#endif
          err("a_socket");

        if(a_method == 2)
        {      
  	  a_port=port;
  	  memcpy(a_host,host,strlen(host));
        }
        else
        {
          /* get name and port */
          if ((a_pos = index (a_host, ':')) == NULL)
          {
          	/* There is only an IP OR a port, so which is it? */
          	if((a_pos = index (a_host, '.')) == NULL) /* Not an IPv4? */
          	{
          		if((a_pos = index (a_host, ':')) != NULL) /* An IPv6? */
          		{
          			if((a_pos = index (a_pos, ':')) != NULL) /* Really? */
          			{
          				printf("An IPv6 address here? Sorry, can't handle that, yet...:(\n");
          				exit(-1);
          			}
          		}
          		
          		fprintf (stderr, "invalid alternative host[:port]: %s\n", a_host);
			exit(-1);
          	}
          	else /* an IP address was given only*/
		{
	        	a_port=port; /* then use the main port */
		}          		
          }
	  else
	  {
          	a_port = atoi (a_pos+1);
          	*a_pos = '\0';
          }

          printf("%s:%d\n",a_host,a_port);
        }

        bzero ((char *) &a_sinhim, sizeof (a_sinhim));

#ifdef USE_IPV6
        if ((a_addr = gethostbyname2 (a_host,AF_INET6)) == NULL) err("bad alternative hostname");
        a_sinhim.sin6_family = a_addr->h_addrtype;
        memcpy((char *) &a_sinhim.sin6_addr, a_addr->h_addr, a_addr->h_length);
        a_sinhim.sin6_port = htons(a_port);
#else
        if (atoi(a_host) > 0 )
        {
            /* Numeric */
            a_sinhim.sin_family = AF_INET;
            a_sinhim.sin_addr.s_addr = inet_addr(a_host);
        }
        else
        {
            if ((a_addr = gethostbyname (a_host)) == NULL)
              err("bad alternative hostname");
            a_sinhim.sin_family = a_addr->h_addrtype;
	    memcpy((char *) & a_sinhim.sin_addr, a_addr->h_addr,a_addr->h_length);
        }
        a_sinhim.sin_port = htons(a_port);
#endif

        if(connect(a_fd, (struct sockaddr*) &a_sinhim, sizeof(a_sinhim) ) < 0)
          err("a_connect");
      }
      else /* receiving */
      {
	if(!a_fd_init)
        {
	  if(a_method==2) a_port=port;
	  else a_port=atoi(a_host);
#ifdef USE_IPV6
          if ((a_listenfd = socket(AF_INET6, SOCK_STREAM, 0)) < 0)
#else
          if ((a_listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
#endif
            err("a_socket");

#ifdef USE_IPV6
          a_sinme.sin6_family = AF_INET;
          a_sinme.sin6_port = htons(a_port);
#else
          a_sinme.sin_family = AF_INET;
          a_sinme.sin_addr.s_addr = 0;
          a_sinme.sin_port = htons(a_port);
#endif          

          if (bind(a_listenfd, (struct sockaddr*) &a_sinme, sizeof(a_sinme)) < 0)
            err("a_bind");
          a_fd_init=1;
        }

        listen(a_listenfd, 0);   /* allow a queue of 0 */

        a_fromlen = sizeof(a_frominet);
        if((a_fd = accept (a_listenfd, (struct sockaddr*) &a_frominet, &a_fromlen))<0)
          err("a_accept");
      } /* receiving */
    } /* if a_method */

    if(use_pckt_file)
    {
        pckt_fr = fopen(pckt_filename,"r+");
        if(pckt_fr == NULL) err("fopen pckt file");
        i=0;
    	while((i<MAX_VALUES) && (fscanf(pckt_fr,"%u",&pckt_table[i]) == 1)) i++;
	pckt_table_max=i;
	fclose(pckt_fr);
	j=buflen;
        while(i>0)
        {
		if(pckt_table[i] > j) j=pckt_table[i];
		i--;
	}
        if(verb) fprintf(stderr,"jtg-t: %d Packet sizes read (max %d)\n",pckt_table_max,j);
        free(buf);
        buf= malloc(j);
        bzero(buf,j);
    }

    if(use_delay_file)
    {
        del_fr = fopen(delay_filename,"r+");
        if(del_fr == NULL) err("fopen delay file");
    	i=0;
    	while((i<MAX_VALUES) && (fscanf(del_fr,"%lu",&delay_table[i]) == 1)) i++;
	delay_table_max=i;
	fclose(del_fr);
        if(verb) fprintf(stderr,"jtg-t: %d Delay values read\n", delay_table_max);
    }

    if(superpriority) /*  Let's give us SUPER priority...:) */
    {
      setpriority(PRIO_PROCESS,0,-20);
      if(errno == EACCES)
      {
	perror("Couldn't set higher priority");
	errno=0;  /* Ash... didn't succeed...:) */
	return 0;
      }
    }

    gettimeofday(&t1, (struct timezone *)0);

    /*
     *    Begin sender code
     *
     */

    
    if (trans)
    { 
        pattern( buf, buflen );
	packets=0;
	nbytes_tot=0;

        if(buflen >= 12)
        {
            pkt_num =   (unsigned long *) (buf);
            pkt_time_sec =   (unsigned long *) (buf+4);
            pkt_time_usec =  (unsigned long *) (buf+8);
        }

        if(normalize_timestamps)
        {
            if(buflen >= 20)
    	    {
                pkt_ntime_sec =   (unsigned long *) (buf+12);
                pkt_ntime_usec =  (unsigned long *) (buf+16);
            }
        }


	if(transfer_time > 0.0)
	{
 	  endtime.tv_sec = t1.tv_sec + (transfer_time*1000000)/1000000;
	  endtime.tv_usec = t1.tv_usec + ((unsigned long)(transfer_time*1000000) % 1000000);
	}

        if(buflen >= 12)
	{
	  gettimeofday(&tx,NULL);
	  *pkt_num =  htonl((unsigned long) tx_num);
	  *pkt_time_sec =  htonl((unsigned long) tx.tv_sec);
	  *pkt_time_usec = htonl((unsigned long) tx.tv_usec);
	}

	if(normalize_timestamps && (buflen >= 20))
	{
          if(buflen >= 20)
          {
	      *pkt_ntime_sec =  htonl((unsigned long) base_time.tv_sec);
	      *pkt_ntime_usec = htonl((unsigned long) base_time.tv_usec);
	      have_base_time = 1;
          }
        }

	/*
	 * This is the starting time for sending, now the sender should be
	 * more or less initialized and we can start the work...:)
	 *
	 */
	     
	gettimeofday(&starttime,NULL);

	if(normalize_timestamps)
	{
	    base_time.tv_sec=starttime.tv_sec;
	    base_time.tv_usec=starttime.tv_usec;
	}

        if(buflen >= 12)
	{
/*	  gettimeofday(&tx,NULL); */
	  *pkt_num =  htonl((unsigned long) tx_num);
	  *pkt_time_sec =  htonl((unsigned long) starttime.tv_sec);
	  *pkt_time_usec = htonl((unsigned long) starttime.tv_usec);
	}

	if(normalize_timestamps && (buflen >= 20))
	{
          if(buflen >= 20)
          {
	      *pkt_ntime_sec =  htonl((unsigned long) base_time.tv_sec);
	      *pkt_ntime_usec = htonl((unsigned long) base_time.tv_usec);
	      have_base_time = 1;
          }
        }

	while(1)
	{
	    if (nbuf_start == 0)
		nbuf_start=nbuf;
	    nbuf=nbuf_start;
        while(1)
        {
            	gettimeofday(&t2,NULL);
		if(udp)
		{
	          if(use_pckt_file) buflen=pckt_table[packets%pckt_table_max];
		  if(use_pckt_file && (buflen < 12)) buflen=12;

		  if(use_delay_file) tick=delay_table[packets%delay_table_max];
		}

		/* Did the user give an end time for the transfer? (transfer_time) */
		
		if(transfer_time > 0.0)
		{
			ret=diff_tv(t2,endtime);
			if(ret > 0) break;
		}
		else if(!(nbuf--)) break;

		if(udp)
		if((process_latency) || (verb && !process_latency))
		{ 
 		  t_tmp.tv_sec=starttime.tv_sec;
  		  t_tmp.tv_usec=starttime.tv_usec;
 		  add_int2tv(&t_tmp,processing_latency_tick_sum);
		  processing_latency_tick_sum+=tick;
		  processing_latency = diff_tv(t2,t_tmp);
		}

		if(verb&&udp)
		{
	          printf("Should be sent at %s, was sent actually at ",tvtoa(t_tmp));
		  printf("%s\n",tvtoa(t2));
		  printf("Packet left %.3f ms too %s\n",
		  processing_latency/1000.0,(processing_latency > 0 ? "late":"early"));
		}

		if(Nwrite(fd,buf,buflen) != buflen) break;
		packets++;
		nbytes_tot+=buflen;
		
		if((buflen >= 12) && (verb) && (udp))
		    printf("Pkt %u: time %u.%u\n", ntohl(*pkt_num),ntohl(*pkt_time_sec), ntohl(*pkt_time_usec) );

                /*
                 * send block# of packets and delay for tick usec
                 *
                 * if udp sender, delay to create CBR/VBR
                 *
                 */

                if(udp)
                {
                    cont++;
		    if(buflen >= 12)
		      *pkt_num =  htonl((unsigned long) ++tx_num);
                    if (cont==block)
                    {
			if(process_latency) delay(tick-processing_latency,TAKE_STATS);
			else delay(tick,TAKE_STATS);			
                        cont = 0;
                        if(buflen >= 12)
                        {
                            gettimeofday(&tx,NULL);
			    *pkt_time_sec =  htonl((unsigned long) tx.tv_sec);
			    *pkt_time_usec = htonl((unsigned long) tx.tv_usec);
                        }
			if(normalize_timestamps && (buflen >= 20))
			{
  	                    if(buflen >= 20)
        	            {
			      *pkt_ntime_sec =  htonl((unsigned long) base_time.tv_sec);
			      *pkt_ntime_usec = htonl((unsigned long) base_time.tv_usec);
			      have_base_time = 1;
                            }
                        }
                    }
                }
            } /* while */
            	if (!loop || (loop_n++ == loop_max)) break;
            	if(udp)
                {
		    /* Tick-processing_latency is already slept when cont == block,
		     * so we don't take it account twice */
		    if(process_latency)
		        delay(burst_idle-((cont==block)?(tick-processing_latency):0),TAKE_STATS);
		    else 
		        delay(burst_idle-((cont==block)?tick:0),TAKE_STATS);
		    /* Fix the processing latency */
		    processing_latency_tick_sum+=(burst_idle-((cont==block)?tick:0));
		    cont = 0;
		    if(buflen >= 12)
                    {
			gettimeofday(&tx,NULL);
			*pkt_time_sec =  htonl((unsigned long) tx.tv_sec);
			*pkt_time_usec = htonl((unsigned long) tx.tv_usec);
		    }
		    if(normalize_timestamps && (buflen >= 20))
		    {
			if(buflen >= 20)
			{
			    *pkt_ntime_sec =  htonl((unsigned long) base_time.tv_sec);
			    *pkt_ntime_usec = htonl((unsigned long) base_time.tv_usec);
			    have_base_time = 1;
			}
		    }
                    
                }
            }

            if(!quiet)
                fprintf(stderr,"jtg-t: transmission done.\n");
    } /* end transmitter */

    /*
     *    Begin receiver code
     *
     */

    else
    {
	register int cnt=0;
        unsigned long index=0, prev_index=0;
        nbytes_tot=0;
        cput = 0;
        realt = 0;
        yes=1;
        going=0;
	logverbheaderprinted=0;
        rx_num=0;
	errno=0;
	small_pckts=1;

        if(udp) rfd=fd;

        for(j=0;j<4;j++)
	{
	  tx_rx_now[j]=0;
	  tx_rx_prev[j]=0;
	}

        if(buflen >= 12)
        {
            pkt_num =   (unsigned long *) (buf);
            pkt_time_sec =   (unsigned long *) (buf+4);
            pkt_time_usec =  (unsigned long *) (buf+8);
        }

        if(normalize_timestamps)
        {
            if(buflen >= 20)
    	    {
                pkt_ntime_sec =   (unsigned long *) (buf+12);
                pkt_ntime_usec =  (unsigned long *) (buf+16);
            }
        }

        gettimeofday(&t1,NULL);

        while ((cnt=Nread(rfd,a_fd,buf,buflen)) > 0)  
        {
            if((cnt != CONTROL_MSG_LEN) && (udp)) rx_num++;
            else if(udp&&is_data_pckt(buf,cnt)) rx_num++;
            else if (!udp) rx_num++;

	    if((udp) && (going != 2) && (cnt != CONTROL_MSG_LEN)) going=1;
	    else if((udp)&&(going != 2)&&(is_data_pckt(buf,cnt))) going=1;

	    if(udp)
	    {
		prev_index=index;
	    	if(cnt >= 12) /* info included? */
	    	{
		  small_pckts=0;
		  index = ntohl(*pkt_num);
		  if(index > highest_pkt) highest_pkt = index;
		  
		  tx_rx_now[0] = ntohl(*pkt_time_sec);
		  tx_rx_now[1] = ntohl(*pkt_time_usec);
		  tx_rx_now[2] = rx.tv_sec;
		  tx_rx_now[3] = rx.tv_usec;

		  if((!have_base_time) && (normalize_timestamps) && (cnt >= 20))
		  {
		    base_time.tv_sec  = ntohl(*pkt_ntime_sec);
		    base_time.tv_usec =	ntohl(*pkt_ntime_usec);
		    have_base_time = 1;
		  }

		  if((have_base_time) && (cnt >=20)) do_normalize();
		  else
		  {
		    localtime_r(&tx_rx_now[0],&tm1);
		    localtime_r(&tx_rx_now[2],&tm2);
		  }

		  if(gnuplot || (verb==2)) /* Need the diff-values later? */
		  {
		    /* Interval (jitter) at sender */
		    if(index >0)
		      diff1 = (tx_rx_now[0]-tx_rx_prev[0])*1000000 + tx_rx_now[1] - tx_rx_prev[1];

		    /* Interval = jitter at receiver */
		    if(index > 0)
		      diff2 = (tx_rx_now[2]-tx_rx_prev[2])*1000000 + tx_rx_now[3] - tx_rx_prev[3];

		    /* Transmission time */
		    diff3 = (tx_rx_now[2]-tx_rx_now[0])*1000000 + tx_rx_now[3] - tx_rx_now[1];

		    tx_rx_prev[0]=tx_rx_now[0];
		    tx_rx_prev[1]=tx_rx_now[1];
		    tx_rx_prev[2]=tx_rx_now[2];
		    tx_rx_prev[3]=tx_rx_now[3];
		  }
	          
  		  if((verb) || (logverb))
		  {
			if((!logverbheaderprinted) && (!gnuplot))
			{
			  fprintf(fr,"# Test started %s",datetoa());
#ifdef USE_IPV6
			  fprintf(fr,", sender %s:%u\n",inet_ntop(PF_INET6,&from.sin_addr,inet_ntop_buf,64),ntohs(from.sin_port));
#else
			  fprintf(fr,", sender %s:%u\n",inet_ntop(AF_INET,&from.sin_addr,inet_ntop_buf,64),ntohs(from.sin_port));
#endif
			  logverbheaderprinted=1;
			}

			if(!gnuplot)
			{
		  	  if(!gtod_ts)
		  	    fprintf(fr,"Seq>%lu TxTime>%02d:%02d:%02d.%06lu RxTime>%02d:%02d:%02d.%06lu Size>%u\n",
			    index, tm1.tm_hour, tm1.tm_min, tm1.tm_sec,tx_rx_now[1],
			    tm2.tm_hour, tm2.tm_min, tm2.tm_sec,tx_rx_now[3], cnt);
			  else
			    fprintf(fr,"Seq>%lu TxTime>%ld.%06ld RxTime>%ld.%06ld Size>%u\n",
			    index, tx_rx_now[0],tx_rx_now[1],tx_rx_now[2],tx_rx_now[3], cnt);
			  
			}
			else if((gnuplot)) /* && (rx_num != 1)) */
			{
			  if(index-prev_index != 1)
			  {
		  	    for(i=1;i<index-prev_index;i++)
			      fprintf(fr,"%.3f 0 - -\n",
			        ((rx.tv_sec*1000.0) + (rx.tv_usec/1000.0)
			        - (starttime.tv_sec * 1000.0) - (starttime.tv_usec/1000.0))/1000.0);
			  		
			  }
			  if(rx_num == 1)
			    fprintf(fr,"0.0 ");
			  else 
			    fprintf(fr,"%.3f ",
			      ((rx.tv_sec*1000.0) + (rx.tv_usec/1000.0)
			      - (starttime.tv_sec * 1000.0) - (starttime.tv_usec/1000.0))/1000.0);
			  fprintf(fr,"%lu ", index);

			  if(diff3 > 0) fprintf(fr,"%.3f ", diff3/1000.0);
			  else fprintf(fr,"- ");

                           /* previous packet came through, jitter positive, not first pckt ? */
			  if((index-prev_index == 1) && (diff2 > 0) && (rx_num > 1))
			    fprintf(fr,"%.3f\n", diff2/1000.0);
		          else fprintf(fr,"-\n");
		          fflush(fr);
			}

  		  if((verb==2) && (!gnuplot))
		    fprintf(fr,"# Seq>%lu TxTime>%lu.%lu RxTime>%lu.%lu Size>%u\n",
			index,tx_rx_now[0],tx_rx_now[1],
			tx_rx_now[2],tx_rx_now[3],cnt);
		  if((verb==2) && (!gnuplot))
		    fprintf(fr,"# Seq>%lu TxTime>%02d:%02d:%02d.%06lu (%lu) \
RxTime>%02d:%02d:%02d.%06lu (%lu): %lu (%ld) (%ld) (%ld)\n",
			index,
			tm1.tm_hour, tm1.tm_min, tm1.tm_sec,tx_rx_now[1],diff1,
			tm2.tm_hour, tm2.tm_min, tm2.tm_sec,tx_rx_now[3],diff2,
			diff3,(diff3-diff1+diff2),-diff1+diff2,(diff3-diff1+diff2)-diff_p1);

			if(index > 0) diff_p1 += -diff1+diff2;
		} /* if(index < ...) */
		} /* if(cnt >= 12) */

                t1.tv_sec=rx.tv_sec;
                t1.tv_usec=rx.tv_usec;

                if(going==1)
                {
                    going = 2;
                    prep_timer();
                    gettimeofday(&starttime, NULL);
		    if(!quiet && udp) fprintf(stderr," > got it");
		    if(loop_filename != NULL)
		      printf(" (log: %s)",loop_filename);
		    else if(filename != NULL)
		      printf(" (log: %s)",filename);
	 	    fflush(stdout);
                }
	    } /* if udp */
            else /* tcp receiver */
            {
	        if(((verb) || (logverb)) && (fr != NULL))
		{
		  if( (!logverbheaderprinted))
		  {
		    fprintf(fr,"# Test started %s",datetoa());
#ifdef USE_IPV6
		    fprintf(fr,", sender %s:%u\n",inet_ntop(PF_INET6,&frominet.sin6_addr,inet_ntop_buf,64),ntohs(frominet.sin6_port));
#else
		    fprintf(fr,", sender %s:%u\n",inet_ntop(AF_INET,&frominet.sin_addr,inet_ntop_buf,64),ntohs(frominet.sin_port));
		    perror("inet_ntop");
#endif
		    logverbheaderprinted=1;
		  }
		  if(nbytes_tot==0)
		    fprintf(fr,"0.0 ");
		  else fprintf(fr,"%.6f ",
 	            ((rx.tv_sec*1000.0) + (rx.tv_usec/1000.0) - (starttime.tv_sec * 1000.0) - (starttime.tv_usec/1000.0))/1000.0);
	 	  fprintf(fr,"%.1f\n",(nbytes_tot+cnt)/1000.0);
		}
            	if(!going)
                {
                    going = 1;
                    prep_timer();
                    gettimeofday(&starttime, NULL);
		    if(loop_n) printf(" (log: %s)",filename);
		    fflush(stdout);
		}
            }

            if((going==0) && ( cnt == CONTROL_MSG_LEN ) && udp)
            {
              if(buf[0]=='K')
              {
              	end_receiver=1; 
              	break;
              }
            }            

            if((going==2) && udp && (( cnt == CONTROL_MSG_LEN ) && (!is_data_pckt(buf,cnt))))
            {
              if(buf[0]=='K') end_receiver=1;
              else end_receiver=0;
              break;  /* this is like "EOF" */
            }
            else
                nbytes_tot += cnt;
        }
    }

finish:
    /* get the time the sending ended */
    gettimeofday(&t2, (struct timezone *)0);

    if((fromsigs) || end_receiver)
    {
      if(!trans)
      {
        if(rx_num == 0)
	{
          /* Remove latest file */
	 if(loop_filename != NULL)
		unlink(loop_filename);
	 else if(filename != NULL)
		unlink(filename);
	}
      }
    }

    /*
     * send a small packet that informs the receiver that the session is closed
     * Send a few to be more sure... if one is lost...
     * Alternative method: send an 'F' to the TCP connection
     *
     */

    if(udp&&trans)
    {
	if(a_method)
	{
		char f = 'F';
		if(end_receiver) f='K';

		if(end_time > 0)
		  sleep(end_time); /* sleep a few seconds before closing the UDP socket
                                      this may help to reduce ICMP error messages... */

		(void)Nwrite(a_fd,&f,1);
		close(a_fd);
	}
	else /* 'normal' way */
	{
	  if(end_receiver) memcpy(buf,"KCCC",4);
	  else memcpy(buf,"FCCC",4);

  	  if(end_time > 0)
	    sleep(end_time); /* sleep a few seconds before closing the UDP socket
                               this may help to reduce ICMP error messages... */

	  delay(10000,NO_STATS); /* 10 ms */
          (void)Nwrite( fd, buf, 4 ); /* rcvr end */
	  delay(25000,NO_STATS); /* 25 ms */
          (void)Nwrite( fd, buf, 4 ); /* rcvr end */
	  delay(50000,NO_STATS); /* 50 ms */
          (void)Nwrite( fd, buf, 4 ); /* rcvr end */
        }
    }

    if(!quiet && !trans)
    {
    	if(udp && rx_num) fprintf(stderr," > received %lu pkts\n",rx_num);
    	else if(rx_num) fprintf(stderr," > received %lu bytes\n",nbytes_tot);
	else fprintf(stderr,"\n");
    }

    if(fr != NULL) /* so packet info log is open? */
    {
	if(small_pckts) fprintf(fr,"#No statistics, received only %lu small packets worth %lu bytes\n",rx_num,nbytes_tot);
	fflush(fr);
    }

    if(udp&&!loop)
    {
      if(!a_method && end_time > 0)
	sleep(end_time); /* sleep a few seconds before closing the UDP socket
                            this may help to reduce ICMP error messages... */
	close(fd);
	if(errno)
	  err("IO");
    }

    (void)read_timer(stats,sizeof(stats));

    /* User didn't want any output? If so, exit now */
    if(quiet && !loop && !tcplog) goto end;

    /* If max streams to log was set and we have done enough, exit now */
    if((loop) && (loop_n == loop_max)) goto end;

    /* If we are looping, not ordered to stop, and did not come here from CTRL-C,
       continue operation */

    if((loop && !trans) && (!fromsigs) && (!end_receiver)) goto back;

    /* If we were ordered to stop or user pressed CTRL-C, exit now */
    if(loop && end_receiver) goto end;

    if(fromsigs && logverb) goto end;

    /* No packets received? No need to print statistics then. */

    if((!trans) && (rx_num == 0)) goto end;


    if((!tcplog) && (verb==2))
    {
      fprintf(stderr,"jtg%s: %s\n", trans?"-t":"-r", stats);
      if( cput <= 0.0 )  cput = 0.001;
      if( realt <= 0.0 )  realt = 0.001;
      fprintf(stderr,"jtg%s: %lu bytes (%lu bits) and %lu %s processed\n",
                trans?"-t":"-r", nbytes_tot, nbytes_tot*8, trans?packets:rx_num,
                udp?"packets":trans?"write()-calls":"read()-calls" );
      fprintf(stderr,"jtg%s: %9g CPU sec  = %9g KB/cpu sec,  %9g Kbits/cpu sec\n",
                trans?"-t":"-r",cput,((double)nbytes_tot)/cput/1024,
                ((double)nbytes_tot)*8/cput/1024 );
      fprintf(stderr,"jtg%s: %9g real sec = %9g KB/real sec, %9g Kbits/sec\n",
                trans?"-t":"-r", realt,((double)nbytes_tot)/realt/1024,
                ((double)nbytes_tot)*8/realt/1024 );
    }

    if(!trans)
    {
    	if(!udp)
            diffis = (t2.tv_sec - starttime.tv_sec) * 1000000 + (t2.tv_usec - starttime.tv_usec);
	else
            diffis = (t2.tv_sec - starttime.tv_sec) * 1000000 + (t2.tv_usec - starttime.tv_usec);

	if(tcplog) fprintf(fr,"# transmission time %.6f s.\n",diffis/1000000.0);

	if(!quiet) fprintf(stderr,"jtg-r: transmission time %.3f s.\n",diffis/1000000.0);

	if(udp && (rx_num > 0))
	{
	  lost_pckts = highest_pkt+1 - rx_num;
          fprintf(stderr,"jtg-r: received packets %ld, lost %lu (%.2f%%), bytes %ld, avpkt %ld\n",
            rx_num,lost_pckts,(100.0*lost_pckts/(highest_pkt+1)),nbytes_tot, nbytes_tot/(rx_num));
	  fprintf(stderr,"jtg-r: %.3f pkts/s\n",(rx_num)/(diffis/1000000.0));
          fprintf(stderr,"jtg-r: estimated average user data bandwidth %.1f Kbit/s\n",
            (nbytes_tot*8.0/(diffis/1000000.0))/1000.0);
           
          fprintf(stderr,"jtg%s: estimated average link bandwidth %.1f Kbit/s\n",
           trans?"-t":"-r",
           ipv6?(((nbytes_tot*8.0)+((IP6_HEADER_SIZE+UDP_HEADER_SIZE)*(rx_num)*8.0))/(diffis/1000000.0))/1000.0:
           (((nbytes_tot*8.0)+((IP_HEADER_SIZE+UDP_HEADER_SIZE)*(rx_num)*8.0))/(diffis/1000000.0))/1000.0);
	}
	else
	{
	  if(tcplog)
	  {
	    fprintf(fr,"# received bytes %lu, read()-calls %lu\n",nbytes_tot,rx_num);
            fprintf(fr,"# average user data bandwidth %.1f Kbit/s\n",
              (nbytes_tot*8.0/(diffis/1000000.0))/1000.0);
	  }
	  if(!quiet)
            fprintf(stderr,"jtg-r: average user data bandwidth %.1f Kbit/s\n",
              (nbytes_tot*8.0/(diffis/1000000.0))/1000.0);
	}
    }
    
    if(trans) 
    {
    	diffis = (t2.tv_sec - starttime.tv_sec) * 1000000 + (t2.tv_usec - starttime.tv_usec);
    	dataa = nbytes_tot;

	if(udp) tick = (total_tick / sel_num);

    	if(!udp)
        {
            fprintf(stderr, "jtg-t: Transmission time: %.6f sec\n",diffis/1000000.0);
            fprintf(stderr, "jtg-t: Transmitted bytes %ld\n",dataa);
        }
        
        if(udp)    
        {
	    fprintf(stderr,"jtg-t: transmitted %d packets, %ld bytes\n",packets, dataa);
            fprintf(stderr, "jtg-t: transmission time: %.6f sec (%sinterval %d us)\n",
            diffis/1000000.0,(use_delay_file? "avg. ":""),tick);
            fprintf(stderr,"jtg-t: avg delay %.1f ms, calls %lu, error sum %.1f (aver %.3f) msec\n",
                   tick/1000.0,sel_num, sel_err/1000.0,(sel_err/(long)sel_num)/1000.0 );
    
            if(OPEN)
            fprintf(stderr,"jtg-t: delay call used %s\n",
               tick>bw_limit?"select()":"busy waiting");
            else if(BUSYWAIT && SELECT)
                fprintf(stderr,"jtg-t: delay call used the hybrid model\n");
            else
                fprintf(stderr,"jtg-t: delay call used %s\n",SELECT?"select()":"busy waiting");
        }

    	if(udp&&!ipv6) ipdataa = nbytes_tot+(packets*(IP_HEADER_SIZE+UDP_HEADER_SIZE));
    	else if(udp&&ipv6) ipdataa = nbytes_tot+(packets*(IP6_HEADER_SIZE+UDP_HEADER_SIZE));
    	else if(!udp&&!ipv6) ipdataa = nbytes_tot+(packets*(IP_HEADER_SIZE+TCP_HEADER_SIZE));
    	else if(!udp&&ipv6) ipdataa = nbytes_tot+(packets*(IP6_HEADER_SIZE+TCP_HEADER_SIZE));

        fprintf(stderr,"jtg%s: estimated average user data bandwidth %.1f Kbit/s\n",
           trans?"-t":"-r", (dataa*8.0/(diffis/1000000.0))/1000.0);

        fprintf(stderr,"jtg%s: estimated%s average link bandwidth %.1f Kbit/s\n",
           trans?"-t":"-r", udp?"":" (very rough!)",(ipdataa*8.0/(diffis/1000000.0))/1000.0);
    }

end:

    if(tcpoptionsset) restoretcpopts();
    if(fr != NULL) fclose(fr);
    free(buf);
    if(loop_filename != NULL) free(loop_filename); 
    return 0;

usage:
    pusage(argv[0]);
    return 0;
} /* end main */

void err(char *s)
{
        fprintf(stderr,"jtg%s: ", trans?"-t":"-r");
        perror(s);
        fprintf(stderr,"errno=%d\n",errno);
	exit(0);
}

void mes(char *s)
{
  fprintf(stderr,"jtg%s: %s\n", trans?"-t":"-r", s);
}

void pattern(register char *cp, register int cnt)
{
/*  register char c=0; */
  while( cnt-- > 0 )
  {
/*    while( !isprint((c&0x7F)) )  c++; */
    *cp++ = DATA_MSG_CH;/*(c++&0x7F); */
  }
}

/******* timing *********/

static struct   timeval time0;  /* Time at which timeing started */
static struct   rusage ru0;     /* Resource utilization at the start */

static struct   timeval time_last;  /* Time of last check */

static void prusage();
static void tvadd();
static void tvsub();
static void psecs();

/*
 *                      P R E P _ T I M E R
 */
void prep_timer()
{
    gettimeofday(&time0, (struct timezone *)0);
    getrusage(RUSAGE_SELF, &ru0);
    
    time_last.tv_sec = time0.tv_sec;
    time_last.tv_usec = time0.tv_usec;
    nbytes_last = 0;
}

/*
 *                      R E A D _ T I M E R
 * 
 */
double read_timer(char * str, int len)
{
        struct timeval timedol;
        struct rusage ru1;
        struct timeval td;
        struct timeval tend, tstart;
        char line[132];

        getrusage(RUSAGE_SELF, &ru1);
        gettimeofday(&timedol, (struct timezone *)0);
        prusage(&ru0, &ru1, &timedol, &time0, line);
        (void)strncpy( str, line, len );

        /* Get real time */
        tvsub( &td, &timedol, &time0 );
        realt = td.tv_sec + ((double)td.tv_usec) / 1000000;

        /* Get CPU time (user+sys) */
        tvadd( &tend, &ru1.ru_utime, &ru1.ru_stime );
        tvadd( &tstart, &ru0.ru_utime, &ru0.ru_stime );
        tvsub( &td, &tend, &tstart );
        cput = td.tv_sec + ((double)td.tv_usec) / 1000000;
        if( cput < 0.00001 )  cput = 0.00001;
        return( cput );
}

static void
prusage(r0, r1, e, b, outp)
        register struct rusage *r0, *r1;
        struct timeval *e, *b;
        char *outp;
{
        struct timeval tdiff;
        register time_t t;
        register char *cp;
        register int i;
        int ms;

        t = (r1->ru_utime.tv_sec-r0->ru_utime.tv_sec)*100+
            (r1->ru_utime.tv_usec-r0->ru_utime.tv_usec)/10000+
            (r1->ru_stime.tv_sec-r0->ru_stime.tv_sec)*100+
            (r1->ru_stime.tv_usec-r0->ru_stime.tv_usec)/10000;
        ms =  (e->tv_sec-b->tv_sec)*100 + (e->tv_usec-b->tv_usec)/10000;

#define END(x)  {while(*x) x++;}
        cp = "%Uuser %Ssys %Ereal %P %Xi+%Dd %Mmaxrss %F+%Rpf %Ccsw";
        for (; *cp; cp++)
        {
            if (*cp != '%')
                *outp++ = *cp;
            else if (cp[1]) switch(*++cp)
            {
                case 'U':
                    tvsub(&tdiff, &r1->ru_utime, &r0->ru_utime);
                    sprintf(outp,"%d.%01ld", (int)tdiff.tv_sec, tdiff.tv_usec/100000);
                    END(outp);
                    break;

                case 'S':
                    tvsub(&tdiff, &r1->ru_stime, &r0->ru_stime);
                    sprintf(outp,"%d.%01ld", (int) tdiff.tv_sec, tdiff.tv_usec/100000);
                    END(outp);
                    break;

                case 'E':
                    psecs(ms / 100, outp);
                    END(outp);
                    break;

                case 'P':
                    sprintf(outp,"%d%%", (int) (t*100 / ((ms ? ms : 1))));
                    END(outp);
                    break;

                case 'W':
                        i = r1->ru_nswap - r0->ru_nswap;
                        sprintf(outp,"%d", i);
                        END(outp);
                        break;

                case 'X':
                        sprintf(outp,"%ld", t == 0 ? 0 : (r1->ru_ixrss-r0->ru_ixrss)/t);
                        END(outp);
                        break;

                case 'D':
                        sprintf(outp,"%ld", t == 0 ? 0 :
                            (r1->ru_idrss+r1->ru_isrss-(r0->ru_idrss+r0->ru_isrss))/t);
                        END(outp);
                        break;

                case 'K':
                        sprintf(outp,"%ld", t == 0 ? 0 :
                            ((r1->ru_ixrss+r1->ru_isrss+r1->ru_idrss) -
                            (r0->ru_ixrss+r0->ru_idrss+r0->ru_isrss))/t);
                        END(outp);
                        break;

                case 'M':
                        sprintf(outp,"%ld", r1->ru_maxrss/2);
                        END(outp);
                        break;

                case 'F':
                        sprintf(outp,"%ld", r1->ru_majflt-r0->ru_majflt);
                        END(outp);
                        break;

                case 'R':
                        sprintf(outp,"%ld", r1->ru_minflt-r0->ru_minflt);
                        END(outp);
                        break;

                case 'I':
                        sprintf(outp,"%ld", r1->ru_inblock-r0->ru_inblock);
                        END(outp);
                        break;

                case 'O':
                        sprintf(outp,"%ld", r1->ru_oublock-r0->ru_oublock);
                        END(outp);
                        break;
                case 'C':
                        sprintf(outp,"%ld+%ld", r1->ru_nvcsw-r0->ru_nvcsw,
                                r1->ru_nivcsw-r0->ru_nivcsw );
                        END(outp);
                        break;
                }
        }
        *outp = '\0';
}

static void tvadd(struct timeval *tsum, struct timeval *t0, struct timeval *t1)
{

        tsum->tv_sec = t0->tv_sec + t1->tv_sec;
        tsum->tv_usec = t0->tv_usec + t1->tv_usec;
        if (tsum->tv_usec > 1000000)
                tsum->tv_sec++, tsum->tv_usec -= 1000000;
}

static void tvsub(struct timeval *tdiff, struct timeval *t1, struct timeval *t0)
{

        tdiff->tv_sec = t1->tv_sec - t0->tv_sec;
        tdiff->tv_usec = t1->tv_usec - t0->tv_usec;
        if (tdiff->tv_usec < 0)
                tdiff->tv_sec--, tdiff->tv_usec += 1000000;
}

static void psecs(long l, register char *cp)
{
    register int i;

    i = l / 3600;
    if (i)
    {
        sprintf(cp,"%d:", i);
        END(cp);
        i = l % 3600;
        sprintf(cp,"%d%d", (i/60) / 10, (i/60) % 10);
        END(cp);
    }
    else
    {
        i = l;
        sprintf(cp,"%d", i / 60);
        END(cp);
    }
    i %= 60;
    *cp++ = ':';
    sprintf(cp,"%d%d", i / 10, i % 10);
}

/*
 *                      N R E A D
 */

int Nread(int fd, int afd, char *buf, int count )
{
    register int cnt = -1;
    int max_fd = -1;
    fd_set rset;
    int retval;
    char buffer[16];
    len = sizeof(from);

    if( udp && !a_method)
      cnt = recvfrom(fd,(char *)buf,count,0,(struct sockaddr*)&from,&len);
    else if( udp && a_method)
    {
        FD_ZERO (&rset);
        FD_SET (fd, &rset);
        if (afd > -1)
          FD_SET (afd, &rset);

        max_fd = (fd > afd) ? fd + 1 : afd + 1;
        retval = select (max_fd, &rset, NULL, NULL, NULL);
        if (retval)
        {

          /* normal data */
          if (FD_ISSET (fd, &rset))
          {
            cnt = recvfrom(fd,(char *)buf,count,0,(struct sockaddr*)&from,&len);
          }
          /* data from alternative address */
          else if  (FD_ISSET (afd, &rset))
          {
            cnt = read (afd, buffer, 16);
            if (cnt > 0)
            {
              if (buffer[0] == 'F')
                cnt = -2;
              else if (buffer[0] == 'K')
              {
                cnt = -2;
                end_receiver=1;
              }
            }
          }
        }
    }
    else
    {
        if( b_flag )
            cnt = mread( fd, buf, count ) ; /* fill buf */
        else
            cnt = read( fd, buf, count );
    }

    if (cnt != -2 && ioctl(fd,SIOCGSTAMP,&rx) == -1)
    {
        /* Can't do ioctl, the user not not have root priviledges? */
        errno=0;
        gettimeofday(&rx,NULL);
    }

    return(cnt);
}

/*
 *                      N W R I T E
 */
 
int Nwrite(int fd, char *buf, int count )
{
    register int cnt;
    if( udp )
    {
again:
        cnt = sendto( fd, buf, count, 0, (struct sockaddr*) &sinhim, sizeof(sinhim) );
        if( cnt<0 && errno == ENOBUFS )  
        {
            delay(1000,NO_STATS);
            errno = 0;
            goto again;
        }
    } 
    else 
        cnt = write( fd, buf, count );
    return(cnt);
}

/* The delay()-function is very crude at the moment. The main issue with
trying to sleep with the Linux select()-call is that the granularity of
the call is around 10ms. This means that value under 10ms will only be
triggered at the next 10ms interval. Similarly, a timeout request of
11ms will timeout on average after 20ms.

The three methods for sleeping are 

    o OPEN (will be deduced from the timer value),
    o SELECT (forces to use select always),
    o BUSYWAIT (forces to use busy waiting always), and
    o "hybrid" if both SELECT and BUSYWAIT were requested
    
    See the code for more detail...:) 
*/

void delay(int us, int take_stats)
{
    struct timeval tv;
    struct timeval td;
    struct timeval wake;

    int differ=0;
    int excess=0;
    int whole=0;

    if(take_stats) total_tick+=tick;

    /* smooth the timer value, if it "just" exceeds the next
     * timer granularity-related interval
     * ONLY if the timer type was not set to "hybrid"
     */

    if(!(SELECT&&BUSYWAIT) && (us > bw_limit))
    {
        if((us%select_granularity) < select_smoothing)
            us = (us/select_granularity)*10000;
    }

    if(us > 1000000) /* Super-big timeout */
    {
        tv.tv_sec=us/1000000;
        tv.tv_usec=us%1000000;
    }
    else
    {
        tv.tv_sec = 0;
        tv.tv_usec = us;
    }
    
    gettimeofday(&wake, NULL);

    wake.tv_usec += us;
    
    if(wake.tv_usec > 1000000)
    {
        /* IJ: Fixed a BUG when usecs was larger or equal to 2secs */
        wake.tv_sec  += wake.tv_usec / 1000000;
        wake.tv_usec %= 1000000;
    }

    if(((OPEN) && (us < bw_limit)) || (BUSYWAIT&&!SELECT)) /* do busy waiting waiting? */
    {
        do {
            gettimeofday(&td, (struct timezone *)0);
               differ = (td.tv_sec - wake.tv_sec)*1000000 + (td.tv_usec - wake.tv_usec);
        } while(differ < 0);
    }
    else if((OPEN) || (SELECT && !BUSYWAIT)) /* rely on the select()-call to sleep almost according to plan...:) */
    {
        (void) select( 1, NULL, NULL, NULL, &tv );
    }        
    else if(SELECT && BUSYWAIT) /* use the hybrid model */
    {
        whole=(us/select_granularity)*10000;
        excess = (us%select_granularity);

        /* First the select()-based delay */

        tv.tv_usec=whole;
        (void) select( 1, NULL, NULL, NULL, &tv );

        /* Then the busy-waiting, iff select() timed out early enough */
        tv.tv_usec=excess;

        do {
            gettimeofday(&td, (struct timezone *)0);
               differ = (td.tv_sec - wake.tv_sec)*1000000 + (td.tv_usec - wake.tv_usec);
        } while(differ < 0);
    }
    else
        err("problem with the timer type");
            
    if(take_stats)
    {
      gettimeofday(&td, (struct timezone *)0);
      differ = (td.tv_sec - wake.tv_sec)*1000000 + (td.tv_usec - wake.tv_usec);
      sel_num++;
      sel_err += differ;
      if(verb) printf("Sleep time requested: %d, error %d, error sum %ld\n",us, differ,sel_err);
    }
}

/*
 *                      M R E A D
 *
 * This function performs the function of a read(II) but will
 * call read(II) multiple times in order to get the requested
 * number of characters.  This can be necessary because
 * network connections don't deliver data with the same
 * grouping as it is written with.  Written by Robert S. Miles, BRL.
 */
 
int mread(int fd, register char *bufp, unsigned n)
{
    register unsigned       count = 0;
    register int            nread;

    do {
        nread = read(fd, bufp, n-count);
        if(nread < 0)
        {
            perror("jtg_mread");
            return(-1);
        }
        if(nread == 0)
            return((int)count);
        count += (unsigned)nread;
        bufp += nread;
    } while(count < n);

    return((int)count);
}

/*
 * Add an interger value of us to a timeval
 *
 */


void add_int2tv(struct timeval *to, int us)
{
    to->tv_sec += us/1000000;
    to->tv_usec += us%1000000;
    if(to->tv_usec > 1000000) { to->tv_sec++; to->tv_usec -= 1000000;}
        
    if(to->tv_usec < 0)
    {
        to->tv_sec--;
        to->tv_usec += 1000000;
    }
}


/*
 *
 * Return the given time in my ascii format
 *
 */
 
char* tvtoa(struct timeval tv)
{
        static char jep[32];
        struct tm tm;
        int n;
        localtime_r(&tv.tv_sec,&tm);
        n=snprintf(&jep[0],32,"%d:%s%d:%s%d.",
        tm.tm_hour,
        (tm.tm_min>9)?"":"0",tm.tm_min,
        (tm.tm_sec>9)?"":"0",tm.tm_sec);
        if(tv.tv_usec < 100000) jep[n++]='0';
        if(tv.tv_usec < 10000) jep[n++]='0';
        if(tv.tv_usec < 1000) jep[n++]='0';
        if(tv.tv_usec < 100) jep[n++]='0';
        if(tv.tv_usec < 10) jep[n++]='0';
        sprintf(&jep[n],"%lu",tv.tv_usec);
        return &jep[0];
}

/*
 *
 * Return the current time in ascii format
 *
 */
 
char* timetoa()
{
        static char jep[32];
        struct timeval tv;
        struct tm tm;
        int n;
        gettimeofday(&tv,NULL);
        localtime_r(&tv.tv_sec,&tm);
        n=snprintf(&jep[0],32,"%d:%s%d:%s%d.",
        tm.tm_hour,
        (tm.tm_min>9)?"":"0",tm.tm_min,
        (tm.tm_sec>9)?"":"0",tm.tm_sec);
        if(tv.tv_usec < 100000) jep[n++]='0';
        if(tv.tv_usec < 10000) jep[n++]='0';
        if(tv.tv_usec < 1000) jep[n++]='0';
        if(tv.tv_usec < 100) jep[n++]='0';
        if(tv.tv_usec < 10) jep[n++]='0';
        sprintf(&jep[n],"%lu",tv.tv_usec);
        return &jep[0];
}

/*
 *
 * Return the current date in ascii format
 *
 */

char* datetoa()
{
	static char datetoabuf[64];
	time_t tim;
	time(&tim);

	ctime_r(&tim,datetoabuf);
	datetoabuf[strlen(datetoabuf)-1]='\0';
 	return datetoabuf;
}

/*
 *
 * Signal handler. We only care about SIGINT to close gracefully.
 *
 */

static void sigs(int signo)
{
    if(signo == SIGINT)
    {
	/* Go to finish and clean-up
	 * See Stevens, page 299.
	 */
	fromsigs=1;
	longjmp(jmpbuffer,1);
    }
}

/*
 *
 * Parses the given command line parameter for TCP options.
 * Format is e.g. "keepalive=30" for setting a 30 s. keepalive probe.
 * 
 * Mode defines whether the old value must be stored beforehand.
 *
 */

int parsetcpopt(char *arg, int mode)
{
  int c=0;
  int found=0;
  int nxt=0;
  char p[64];
  char para[32];
  int l = strlen(arg);
  memcpy(p,arg,l);
  p[l]='\0';
  while((p[c] != '=') && (p[c] != '\0')) c++;
  if(p[c] == '\0') return 0; /* improper parameter given */

  memcpy(para,p,c);

  do {
    if(strncmp(para,tcpopts[nxt].name,tcpopts[nxt].namelen)==0)
    {
      tcpopts[nxt].value=atoi(&p[c+1]);
      tcpopts[nxt].option_set=1;
      if(mode)
      {
      	if(tcpopts[nxt].option_use != USE_PROC)
      	  err_exit("Socket options can not be restored, use \"-s\"",0);
      	else tcpopts[nxt].option_use = USE_PROCANDRESTORE;
      }
      found=1;
      tcpoptionsset++;
    }
    else nxt++;
    if(nxt == tcpoptions) return 0;
  } while(!found);
  return 1;
}

/*
 * Print the TCP options set
 *
 */
 
void printtcpopts()
{
  int b=0;
  if(tcpoptions)
  for(b=0;b<tcpoptions;b++)
    if(tcpopts[b].option_set)
      fprintf(stderr,"       %s: %d\n",tcpopts[b].name,tcpopts[b].value);
}

/*
 * Go through the list of options and set as needed
 * 
 */
 
int settcpopts(int sock_fd)
{
  int b=0;
  char buf[32];
  int n=0;
  
  for(b=0;b<tcpoptions;b++)
  {
    if(tcpopts[b].option_set)
    {
    	if(tcpopts[b].option_use==USE_SETSOCKOPT)
    	{
    	  if(setsockopt(sock_fd,SOL_SOCKET,tcpopts[b].option,&tcpopts[b].value,sizeof(tcpopts[b].value)) != 0)
    	    return 0;    		
    	}
	else if(tcpopts[b].option_use==USE_SETSOCKOPTTCP)
    	{
    	  if(setsockopt(sock_fd,IPPROTO_TCP,tcpopts[b].option,&tcpopts[b].value,sizeof(tcpopts[b].value)) != 0)
    	    return 0;    		
    	}

    	else if(tcpopts[b].option_use==USE_PROC)
    	{
	  procfd=open(tcpopts[b].proc_entry,O_WRONLY);
	  if(procfd == -1)
	    err_exit("opening /proc",1);
	  n= snprintf(buf,32,"%d",tcpopts[b].value);
	  if(n < 1) err_exit("snprintf()",1);
	  buf[n]='\0';
	  if(write(procfd,buf,n) != n) err_exit("write to /proc",1);
	  close(procfd);
    	}
    	else if(tcpopts[b].option_use==USE_PROCANDRESTORE)
    	{
	  procfd=open(tcpopts[b].proc_entry,O_RDWR);
	  if(procfd == -1)
	    err_exit("opening /proc",1);
	  n=read(procfd,buf,32);
	  if(!n) return 0;
	  tcpopts[b].oldvalue = atoi(buf);
	  n=snprintf(buf,32,"%d",tcpopts[b].value);
	  if(n < 1) err_exit("snprintf()",1);
	  buf[n]='\0';
	  if(write(procfd,buf,n) != n) err_exit("write to /proc",1);
	  close(procfd);
    	}
    	else return 0;
    }   
  }
  return 1;
}

/*
 * Go through the list of options and restore as needed
 * 
 */
 
void restoretcpopts()
{
  int b=0;
  char buf[32];
  int n=0;
  
  for(b=0;b<tcpoptions;b++)
  {
    if((tcpopts[b].option_set) && (tcpopts[b].option_use==USE_PROCANDRESTORE))
    {
      procfd=open(tcpopts[b].proc_entry,O_WRONLY);
      if(procfd == -1)
	    err_exit("opening /proc",1);
      n=snprintf(buf,32,"%d",tcpopts[b].oldvalue);
      if(n < 1) err_exit("snprintf()",1);
      buf[n]='\0';
      if(write(procfd,buf,n) != n) err_exit("write to /proc",1);
      close(procfd);
    }   
  }
}
  
/*
 *
 * Prints out the help, that is, the parameters, and exits
 *
 */

void pusage( char *name)
{
#ifdef USE_IPV6
  fprintf(stderr,"jtg6 %s\n",jtg_vers);
#else
  fprintf(stderr,"jtg %s\n",jtg_vers);
#endif
  fprintf(stderr,"Usage: %s -t [-options] host (def: sender)\n\
  Common parameters for both sender and receiver:\n\
  -u     use UDP instead of TCP\n\
  -sxx   set socket or TCP option=value pairs\n\
  -Sxx   set socket or TCP option=value pairs (restore old value on exit)\n\
  -p##   port number to send to/listen at (def: 2000)\n\
  -e##   delay in seconds before ending test (sender & receiver, def: 0)\n\
  -i     normalize timestamps\n\
  -v     verbose mode\n\
  -q     \"be quiet!\"\n",name);

  fprintf(stderr,"  -a     use alternative TCP connection to host IP/name to inform\n\
         that the test has ended default is receiver's addr and port\n\
  -Axx   define another [addr:]port for control-communications with the receiver\n\
  -h     help\n\
\n  Sender only parameters:\n\
  -l##   length of packets written to network (def: 1000)\n\
  -n##   number of bufs written to network (def: 100)\n\
  -x##   port number in tx (def: 0=free choice) \n\
  -I##   Bind sender to specified IP address\n\
  -d##   transmission time in seconds \n");

  fprintf(stderr,"  -B##   number of packets per each tick (def: 1) [CBR] \n\
  -T##   length of delay \"tick\" in usec (default 100000=100ms)\n\
  -L     enable identical bursts\n\
  -N##   number of identical bursts\n\
  -D##   delay between identical bursts (default 100000=100ms)\n\
  -b##   user data bandwidth for CBR in bits/s\n\
  -o##	 DSCP for flow (decimal). Possible values:\n\
         EF: 46, AF1: 10/12/14, AF2: 18/20/22, AF3: 26/28/30, AF4: 34/36/38\n\
  -w     force the sender to use busy waiting\n");

  fprintf(stderr,"  -W     force the sender to use select (-w -W: use both based on HZ)\n\
  -P     take into account processing latencies (send pckts more accurately)\n\
  -fxx   take packet size info from file \"xx\"\n\
  -Fxx   packet delay interval info from file \"xx\"\n\
  -k     kill the receiver AFTER this transfer (used by only the sender)\n");

  fprintf(stderr,"\nReceiver only extra parameters: %s -r -[uspAelLNvqQ] [log filename]\n\
  -l##  length of network read buf (def: 1500)\n\
  -L    Loop to listen for several incoming connections\n\
  -N##  upper limit to the number of streams received (used with -L)\n\
  -V    extra information to screen or into log files\n\
  -g    enable drawing real-time plots of the arrived UDP packets\n\
  -G    specify the filename for gnuplot (def. jtg.dat)\n\
  -Q    \"be quiet\" otherwise, but print the log of received packets on stdout\n",name);
  exit(-1);
}
