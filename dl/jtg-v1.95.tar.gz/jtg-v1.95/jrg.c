#include "jrandom.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

rdist D;

void usage( char *str )
{
	fprintf(stderr,"Usage: %s distribution_name par1,par2,par3,par4 number_of_values\n",str);
	fprintf(stderr,"Example: %s triangular 100,500,200 10000\n",str);
	fprintf(stderr, "Distributions:\n");
	fprintf(stderr,"\"beta (beta)\", parameters (4): gamma1_shape,gamma2_shape,min,max\n");
	fprintf(stderr,"\"cauchy (cau)\", parameters (4): mean,std_dev,min,max\n");
	fprintf(stderr,"\"exponential (exp)\", parameters (3): mean,min,max\n");
	fprintf(stderr,"\"gamma (gam)\", parameters (4): shape1,shape2,min,max\n");
	fprintf(stderr,"\"hexponential (hexp)\", parameters (7): mean1,mean2,prob_for_1,min1,max1,min2,max2\n");
	fprintf(stderr,"\"lognormal (logn)\", parameters (4): myy,lambda,min,max\n");
	fprintf(stderr,"\"markov2 (markov2)\", parameters (4): pois1,prob_to_2,pois2,prob_to_1\n");
	fprintf(stderr,"\"normal (nor)\", parameters (4): myy,lambda,min,max\n");
	fprintf(stderr,"\"poisson (poi)\", parameters (1): mean value\n");
	fprintf(stderr,"\"static (stat)\", parameters (1): static value\n");
	fprintf(stderr,"\"triangular (tri)\", parameters: min,max,peak\n");
	fprintf(stderr, "\"uniform (uni)\", parameters: min,max values\n");
	exit(-1);
}

int parse_params(rdist *d, char *par, int vals)
{
	float t[7];
	int p=0;
	
	if(sscanf(par,"%f,%f,%f,%f,%f,%f,%f",&t[0],&t[1],&t[2],&t[3],&t[4],&t[5],&t[6]) != vals) return 1;
	
	for(p=0;p<vals;p++)
		d->params[p]=t[p];

	return 0;
}

float min=100000000.0,max=0.0;
unsigned long mini=0,maxi=0;

int main(int argc, char *argv[])
{
	int i=0;
	unsigned long values=0;
	float val=0.0,avg=0.0;
	
	unsigned short seed[]={0,0,0};
	setup_rnd(seed);

	if(argc != 4) usage(argv[0]);

	init_dist(&D);

	values=atoi(argv[3]);
	
	if(strncmp(argv[1],"uniform",3)==0)
	{
	  if(parse_params(&D,argv[2],2)) {
	  	printf("Bad number of parameters for uniform\n");
	  	usage(argv[0]);
	  }
	  D.nextval=uniformd;
	  fprintf(stdout,"#Distribution: uniform %s\n",argv[2]);
	}

	else if(strncmp(argv[1],"triangular",3)==0)
	{
	  if(parse_params(&D,argv[2],3)) {
	  	printf("Bad number of parameters for triangular\n");
	  	usage(argv[0]);
	  }
	  D.nextval=triangd;
	  fprintf(stdout,"#Distribution: triangular %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"normal",3)==0)
	{
	  if(parse_params(&D,argv[2],3)) {
	  	printf("Bad number of parameters for normal\n");
	  	usage(argv[0]);
	  }
	  D.nextval=normald;
	  fprintf(stdout,"#Distribution: normal %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"exponential",3)==0)
	{
	  if(parse_params(&D,argv[2],3)) {
	  	printf("Bad number of parameters for exponential\n");
	  	usage(argv[0]);
	  }
	  D.nextval=exponentiald;
	  fprintf(stdout,"#Distribution: exponential %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"hexponential",4)==0)
	{
	  if(parse_params(&D,argv[2],7)) {
	  	printf("Bad number of parameters for hexponential\n");
	  	usage(argv[0]);
	  }
	  D.nextval=hexponentiald;
	  fprintf(stdout,"#Distribution: hyperexponential %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"cauchy",3)==0)
	{
	  if(parse_params(&D,argv[2],4)) {
	  	printf("Bad number of parameters for cauchy\n");
	  	usage(argv[0]);
	  }
	  D.nextval=cauchyd;
	  fprintf(stdout,"#Distribution: cauchy %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"lognormal",4)==0)
	{
	  if(parse_params(&D,argv[2],4)) {
	  	printf("Bad number of parameters for lognormal\n");
	  	usage(argv[0]);
	  }
	  D.nextval=lognormald;
	  fprintf(stdout,"#Distribution: lognormal %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"gamma",3)==0)
	{
	  if(parse_params(&D,argv[2],4)) {
	  	printf("Bad number of parameters for gamma\n");
	  	usage(argv[0]);
	  }
	  D.nextval=gammad;
	  fprintf(stdout,"#Distribution: gamma %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"beta",4)==0)
	{
	  if(parse_params(&D,argv[2],4)) {
	  	printf("Bad number of parameters for beta\n");
	  	usage(argv[0]);
	  }
	  D.nextval=betad;
	  fprintf(stdout,"#Distribution: beta %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"static",4)==0)
	{
	  if(parse_params(&D,argv[2],1)) {
	  	printf("Bad number of parameters for static\n");
	  	usage(argv[0]);
	  }
	  D.nextval=staticd;
	  fprintf(stdout,"#Distribution: static %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"poisson",3)==0)
	{
	  if(parse_params(&D,argv[2],1)) {
	  	printf("Bad number of parameters for poisson\n");
	  	usage(argv[0]);
	  }
	  D.nextval=poissond;
	  fprintf(stdout,"#Distribution: poisson %s\n",argv[2]);
	}	

	else if(strncmp(argv[1],"markov2",7)==0)
	{
	  if(parse_params(&D,argv[2],4)) {
	  	printf("Bad number of parameters for markov2\n");
	  	usage(argv[0]);
	  }
	  D.nextval=markov2d;
	  fprintf(stdout,"#Distribution: markov2 %s\n",argv[2]);
	}	

	/* main loop, very simple */
	
	for(i=0;i<values;i++)
	{
		val=D.nextval(&D);
		fprintf(stdout,"%.6f\n",val);
		if(min>val) { min=val; mini=i;}
		if(max<val) { max=val; maxi=i;}
		avg+=val/values;
	}
	fprintf(stdout,"#Min/Max/Avg: %.3f/%.3f/%.3f\n",min,max,avg);
	return 0;
}
