#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>

/* 
   Okey... I'm lazy. Could have done a flexible linked list of values...
   Now we only consider MAXVALS number of values. Increase this if it is
   too small for you. :) 
*/

#define MAXVALS 128000 

inline int compfloat(const void *x, const void *y)
{
    float pp,qq;
    pp = (float)(*(float *)x);
    qq = (float)(*(float *)y);    
    if(pp<qq) return -1;
    if(pp>qq) return 1;
    return 0;
}

int main(int argc, char *argv[])
{
	int intervals=100;
	char line[1024];
	float val=0.0;
	int ret=1;
	unsigned long values=0, next=0,i=0;
	float valt[MAXVALS];
	float min=0.0,max=0.0,avg=0.0, limit=0.0, interval_len;

	if(argc != 2)
	{
		printf("Usage: %s [number_of_intervals] < file\n",argv[0]);
		printf("E.g. %s 100 < delay_values.txt\n",argv[0]);
		return 0;
	}

	intervals=atoi(argv[1]);

	do {
		if(fgets(line,1023,stdin) == NULL) break;
		
		/* Skip comment lines */
		if(line[0] == '#') continue;
		
		ret=sscanf(line,"%f\n",&val);

		/* No more values? */
		if(ret != 1) break;
		
		valt[next]=val;
		if(next==0) { min=val;max=val;}
		else
		{
			if(val<min) min=val;
			if(val>max) max=val;
		}
		next++;
		values++;
		if(values == MAXVALS) break;
	} while(ret == 1);

	for(i=0;i<values;i++)
		avg += valt[i]/values;

	printf("# Values %lu, Min/Max/Avg: %.3f/%.3f/%.3f\n",values,min,max,avg);

	qsort(&valt[0],values,sizeof(float),compfloat);
	
	interval_len=(max-min)/(intervals*1.0);

	next=0;
	limit=min+interval_len;
	for(i=0;i<values;i++)
	{
		if(valt[i]<limit) next++;
		else
		{
			printf("%.6f %lu\n",limit,next);
			next=1;
			limit+=interval_len;
		}
	}
	printf("%.6f %lu\n",limit,next);	
	return 0;
}
			
