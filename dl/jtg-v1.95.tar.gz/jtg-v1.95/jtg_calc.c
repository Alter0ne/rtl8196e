#include "jtg_calc.h"

/*
 * Normalize the value and print it out
 *
 */
 
void process_normalize()
{
        if(!gtod_ts)
        {
       	  ntv_tx.tv_sec=(tx_hm+((tx_s*S_TO_US)/S_TO_US)) - baseline_tx.tv_sec;

	  if( ((unsigned long)(tx_s*S_TO_US) % S_TO_US) < baseline_tx.tv_usec)
	  {
	    ntv_tx.tv_sec--;
	    ntv_tx.tv_usec = ((unsigned long)(tx_s*S_TO_US) % S_TO_US) + S_TO_US - baseline_tx.tv_usec;
	  }
	  else ntv_tx.tv_usec = ((unsigned long)(tx_s*S_TO_US) % S_TO_US) - baseline_tx.tv_usec;
	
          ntv_rx.tv_sec=(rx_hm+((rx_s*S_TO_US)/S_TO_US)) - baseline_tx.tv_sec;

	  if( ((unsigned long)(rx_s*S_TO_US) % S_TO_US) < baseline_tx.tv_usec)
	  {
	    ntv_rx.tv_sec--;
	    ntv_rx.tv_usec = ((unsigned long)(rx_s*S_TO_US) % S_TO_US) + S_TO_US - baseline_tx.tv_usec;
	  }
	  else ntv_rx.tv_usec = ((unsigned long)(rx_s*S_TO_US) % S_TO_US) - baseline_tx.tv_usec;
	}
	else
	{
		ntv_tx.tv_sec = tx.tv_sec - baseline_tx.tv_sec;
		ntv_rx.tv_sec = rx.tv_sec - baseline_tx.tv_sec;
			
	        if(tx.tv_usec < baseline_tx.tv_usec)
	        {
	          ntv_tx.tv_sec--;
	          ntv_tx.tv_usec = tx.tv_usec + S_TO_US - baseline_tx.tv_usec;
	  	}
	        else ntv_tx.tv_usec = tx.tv_usec - baseline_tx.tv_usec;

		if(rx.tv_usec < baseline_tx.tv_usec)
	        {
	          ntv_rx.tv_sec--;
	          ntv_rx.tv_usec = rx.tv_usec + S_TO_US - baseline_tx.tv_usec;
	  	}
	        else ntv_rx.tv_usec = rx.tv_usec - baseline_tx.tv_usec;
	}
			
	printf("Seq>%u TxTime>%s",seq,tvtoa(ntv_tx));
	printf(" RxTime>%s",tvtoa(ntv_rx));
	printf(" Size>%u\n",size);
	total++;
}

int main(int argc, char *argv[])
{

   register int i=0;
   register int j=0;
   register int k=0;

    /* Parse all possible command-line options */
    
    while((op = getopt(argc,argv,"a:d:f:hi:lm:M:np:NRsv")) != -1)
    {
      switch (op)
      {
      	case 'a':
          MOVINGAVGSMOOTH=atoi(optarg);
      	  break;
      	case 'd':
          DELAY_ERROR = atoi(optarg);
      	  break;
      	case 'f':
          CLOCK_DRIFT=atoi(optarg);
      	  break;
      	case 'h':
      	  usage(argv[0]);
      	  break;
      	case 'i':
          memcpy(filename_id,optarg,strlen(optarg));
          is_filename_id=1;
      	  break;
      	case 'l':
	  no_files=1;
      	  break;
      	case 'm':
          MINDELAY=atof(optarg);
          sanity_check=1;
      	  break;
      	case 'M':
          MAXDELAY=atof(optarg);
          sanity_check=1;
      	  break;
      	case 'n':
	  keep_old=0;
      	  break;
      	case 'N':
	  no_files=1;
	  normalize=1;
      	  break;
      	case 'p':
          if(sscanf(optarg,"%d,%d",&submin,&submax) != 2)
          {
          	printf("Wierd interval given for -p %s\n",optarg);
          	usage(argv[0]);
	  }
	  subset=1;          	
          break;
      	case 'R':
          gtod_ts=1;
      	  break;
      	case 's':
          sanity_check=1;
      	  break;
      	case 'v':
          verbose=1;
      	  break;
        default:
          printf("Unknown parameter: %s\n",optarg);
          usage(argv[0]);
      }
    }      	  

/* set the filenames for the output graphs and statistics */

  if(normalize) no_files=1;
  
  if(!no_files)
  {
    if(is_filename_id)
    {
  	memcpy(delay_fn,"delay_",6);
	memcpy(jitter_fn,"jitter_",7);
	memcpy(ipdv_fn,"ipdv_",5);
   	memcpy(delay_pdf_fn,"delay_",6);
	memcpy(jitter_pdf_fn,"jitter_",7);
	memcpy(ipdv_pdf_fn,"ipdv_",5);
   	memcpy(delay_df_fn,"delay_",6);
	memcpy(jitter_df_fn,"jitter_",7);
	memcpy(ipdv_df_fn,"ipdv_",5);
	memcpy(ipdv_dfa_fn,"ipdv_",5);
   	memcpy(delay_avg_fn,"delay_",6);
   	memcpy(lost_fn,"lost_",5);
   	memcpy(stats_fn,"stats_",6);

	len=strlen(filename_id);

   	memcpy(&delay_fn[6],filename_id,len);
   	memcpy(&jitter_fn[7],filename_id,len);
   	memcpy(&ipdv_fn[5],filename_id,len);

   	memcpy(&delay_pdf_fn[6],filename_id,len);
   	memcpy(&jitter_pdf_fn[7],filename_id,len);
   	memcpy(&ipdv_pdf_fn[5],filename_id,len);

   	memcpy(&delay_df_fn[6],filename_id,len);
   	memcpy(&jitter_df_fn[7],filename_id,len);
   	memcpy(&ipdv_df_fn[5],filename_id,len);
   	memcpy(&ipdv_dfa_fn[5],filename_id,len);

   	memcpy(&delay_avg_fn[6],filename_id,len);
   	memcpy(&lost_fn[5],filename_id,len);
   	memcpy(&stats_fn[6],filename_id,len);

	/* end of filename */
   	memcpy(&delay_fn[6+len],".dat",4);
   	memcpy(&jitter_fn[7+len],".dat",4);
   	memcpy(&ipdv_fn[5+len],".dat",4);

   	memcpy(&delay_pdf_fn[6+len],"_pdf.dat",8);
   	memcpy(&jitter_pdf_fn[7+len],"_pdf.dat",8);
   	memcpy(&ipdv_pdf_fn[5+len],"_pdf.dat",8);

   	memcpy(&delay_df_fn[6+len],"_df.dat",7);
   	memcpy(&jitter_df_fn[7+len],"_df.dat",7);
   	memcpy(&ipdv_df_fn[5+len],"_df.dat",7);
   	memcpy(&ipdv_dfa_fn[5+len],"_dfa.dat",8);

   	memcpy(&delay_avg_fn[6+len],"_avg.dat",8);
   	memcpy(&lost_fn[5+len],".dat",4);
   	memcpy(&stats_fn[6+len],".txt",4);

    }
    else
    {
  	memcpy(delay_fn,"delay.dat",9);
	memcpy(jitter_fn,"jitter.dat",10);
	memcpy(ipdv_fn,"ipdv.dat",8);

   	memcpy(delay_pdf_fn,"delay_pdf.dat",13);
	memcpy(jitter_pdf_fn,"jitter_pdf.dat",14);
	memcpy(ipdv_pdf_fn,"ipdv_pdf.dat",12);

   	memcpy(delay_df_fn,"delay_df.dat",12);
	memcpy(jitter_df_fn,"jitter_df.dat",13);
	memcpy(ipdv_df_fn,"ipdv_df.dat",11);
	memcpy(ipdv_dfa_fn,"ipdv_dfa.dat",12);

   	memcpy(delay_avg_fn,"delay_avg.dat",13);
   	memcpy(lost_fn,"lost.dat",8);
   	memcpy(stats_fn,"stats.txt",9);
     }
  }

    if(no_files) stats_fp=stdout;
    else
    {
      if((stats_fp = fopen(stats_fn,"w")) == NULL)
      {
    	perror("Error opening stats file");
    	return -1;
      }
    }

    for (i=0;i<MAX;i++)
    {
    	trt[i][0]=0;trt[i][1]=0;trt[i][2]=0;trt[i][3]=0;
	jit_t[i]=0;
	del_t[i]=0;
	ipdv_t[i]=0;
	ipdv_t_abs[i]=0;
    }

    j=0;
    /*
       Read all values in. Expected line format:

       Seq>0001 TxTime>10:11:23.123456 RxTime 10:11:23.234567 Size>56

       or, if "-R" was given, expect:
       
       Seq>0001 TxTime>1106577055.105593 RxTime>1106577055.125663 Size>1000
       
    */



    /* Read in all the input */ 
    
    do {
	if(fgets(line,1023,stdin) == NULL) break;
	
	if(verbose) printf("%s",line);
	
	if(!gtod_ts) ret=8;
	else ret=6;

	if((line[0] == '#') && (normalize)) printf("%s",line);

	if(line[0] == '#') continue;

	if(!gtod_ts)
          ret=sscanf(line,"Seq>%u TxTime>%u:%u:%f RxTime>%u:%u:%f Size>%u\n",
          &seq,&tx_h,&tx_m,&tx_s,&rx_h,&rx_m,&rx_s,&size);
	else
          ret=sscanf(line,"Seq>%u TxTime>%ld.%ld RxTime>%ld.%ld Size>%u\n",
          &seq, (long*) &tx.tv_sec, (long *)&tx.tv_usec,
          (long *)&rx.tv_sec, (long *)&rx.tv_usec, &size);

	/* All read? (Or erroneous line encountered? */

        if((!gtod_ts)&&(ret != 8))
        {
        	/* Make a check to see if the timestamps are actually in gettimeofday-format */

	        ret=sscanf(line,"Seq>%u TxTime>%ld.%ld RxTime>%ld.%ld Size>%u\n",
        	&seq, (long*) &tx.tv_sec, (long *)&tx.tv_usec,
	        (long *)&rx.tv_sec, (long *)&rx.tv_usec, &size);

		if(ret == 6) gtod_ts=1;
          	else
          	  	 break;
        }

        if((gtod_ts) && (ret != 6)) break;


	subtotal=seq;
	
	/* Was the subset given, are we interested in this packet? */
	
	if((subset) && ((seq<submin) || (seq > submax))) continue;

	if(subset) subseq=seq;
        
	/* Precalculate temporaries; needed in many places */
	tx_hm = (tx_h * 3600) + (tx_m*60);
	rx_hm = (rx_h * 3600) + (rx_m*60);

	if(total==0)
	{
	    if(!gtod_ts)
	    {
	      baseline_tx.tv_sec=tx_hm+((tx_s*S_TO_US)/S_TO_US);
  	      baseline_tx.tv_usec = (unsigned long)(tx_s*S_TO_US) % S_TO_US;
	      baseline_rx.tv_sec=rx_hm+((rx_s*S_TO_US)/S_TO_US);
  	      baseline_rx.tv_usec = ((unsigned long)(rx_s*S_TO_US) % S_TO_US)+DELAY_ERROR; /* Add the error at the start of the transfer, if given (otherwise it's zero) */
  	    }
  	    else
  	    {
  	      baseline_tx.tv_sec=tx.tv_sec;
  	      baseline_tx.tv_usec = tx.tv_usec;
  	      baseline_rx.tv_sec=rx.tv_sec;
  	      baseline_rx.tv_usec = rx.tv_usec+DELAY_ERROR; /* Add the error at the start of the transfer, if given (otherwise it's zero) */
  	    }

	    /* Did the DELAY make the us value go over 1000000? */
	    if(baseline_rx.tv_usec > 1000000)
	    {
	    	baseline_rx.tv_sec += ((baseline_rx.tv_usec) / S_TO_US);
	    	baseline_rx.tv_usec -= ((baseline_rx.tv_usec) % S_TO_US);
	    }
	    	
	}

	if(normalize) process_normalize();
	else
	{
	  /* Got too many packets already? */
	  if(seq == MAX) break;
        
	  pkt_avg+=size;

        if((seq>0) && (seq > prev+1))
        {
           lost += (seq-prev-1);
           if(seq - (prev+2)) /* If more than one packet lost */
               last += sprintf(&missing[last],"[%d,%d] ",prev+1,seq-1);
           else /* Exactly one packet lost */
               last += sprintf(&missing[last],"[%d] ",prev+1);
           loss_bursts++;
        }
	if(seq > high_seq) high_seq=seq;

	if(seq < high_seq)
		if(!no_files) fprintf(stats_fp,"Packet %d was reordered (highest seq %d)\n",seq,total);	

	PKT_INFO(seq,ret);

	if(ret && (keep_old))
	{
	  if(!no_files) fprintf(stats_fp,"Duplicate packet! Will not store this value, keeping old.\n");
	  duplicate_pkts++;
	}
	else
	{
	  PKT_INFO(seq,ret);
	  if(ret && (!keep_old))
	  {
	    if(!no_files) fprintf(stats_fp,"Duplicate packet ! Will use the new value.\n");
	    duplicate_pkts++;
	  }

	  if(!gtod_ts)
	  {	  
	    if (total > 0)
	    {
	      /* Wrap the timer correctly if needed. This is multiple mid-night 
	       * wrap-arounds safe as long as the transfer has at least 
	       * few packets per day. Negative wrap-around constrains us
	       * to one packet per WRAP_AROUND_SAFETY_MARGIN.
	       */

	      if (tx_hm + tx_extra + WRAP_AROUND_SAFETY_MARGIN < trt[prev][0]) 
	      {
		  tx_extra += 24*3600; /* seconds to add */
	      }

	      /* Check for negative wrap-around */

	      if (tx_hm + tx_extra  > trt[prev][0] + WRAP_AROUND_SAFETY_MARGIN)
	      {
		  /* Oops, packet was reordered or duplicate!? Packet was 
		   * sent during the previous day!? */
		  tx_extra -= 24*3600;  /* seconds to substract */
	      }
	      /* IJ 14.07.2004: Is SAFETY_MARGIN required? If timestamps
	       * are always ordered, it is not! Also negative wrap-around
	       * check is not necessary.
	       */
	      if (rx_hm + rx_extra + WRAP_AROUND_SAFETY_MARGIN < trt[prev][2]) 
	      {
		  rx_extra += 24*3600;  /* seconds to add */
	      }
	    }

 	    /* Sender timestamp */
	    trt[seq][0] = tx_hm + tx_extra + ((long)(tx_s*S_TO_US) / S_TO_US);
	    trt[seq][1] = ((long)(tx_s * S_TO_US)) % S_TO_US;

	    /* Receiver timestamp */
	    trt[seq][2] = rx_hm + rx_extra + ((long)(rx_s*S_TO_US) / S_TO_US);
	    trt[seq][3] = ((long) (rx_s * S_TO_US)) % S_TO_US;
	  }
	  else /* timestamps are already in gtod-format */
	  {
	  	trt[seq][0] = tx.tv_sec;
		trt[seq][1] = tx.tv_usec;
		trt[seq][2] = rx.tv_sec;
		trt[seq][3] = rx.tv_usec;
	  }

	  prev=seq;
	  }
	} /* else of "if(normalize) */       	
	
	  total++;

    } while(1);

    if(normalize) return 0;

    if(verbose)
	printf("%s Found %d packets\n",timetoa(),prev);

    if(total==0)
    {
    	fprintf(stderr,"No packets found! Check the log file.\n");
    	return 0;
    }
    
    /* Let's find out the first packet we catched. This might not be number "0". */
    
    for(i=0;i<seq;i++)
    {
    	PKT_INFO(i,ret);
    	if(ret) {
    		first_pckt=i;
    		break;
    	}
    }


    /* All values now in, start calculating performance values */

    /* The last packet was not legal, thus, seq must be re-initialized */


    if(!subset) seq=prev;
    else seq=subseq;

    j=0;

/*
 * Add the delay error given by the user and the possible clock drift
 *
 */

    if((DELAY_ERROR != 0) || (CLOCK_DRIFT != 0))
    {
	if(verbose)
	{
		printf("%s Adding corrections:\n",timetoa());
		if(DELAY_ERROR != 0) printf("\tdelay error of %ld us\n",DELAY_ERROR);
		if(CLOCK_DRIFT != 0) printf("\tclock drift of %ld us/s\n",CLOCK_DRIFT);
	}
      for(i=first_pckt;i<=seq;i++)
      {
      	PKT_INFO(i,ret);
      	if(ret)
      	{
	  if(verbose) printf("Orig:\t%ld %ld %ld %ld\n",trt[i][0],trt[i][1],trt[i][2],trt[i][3]);
	  if(DELAY_ERROR != 0) ADD_TO_TRT(i,3,DELAY_ERROR);
	  if(CLOCK_DRIFT != 0)
	  {
	  	drift_error = (FROMSTART(i) / 1000000.0) * CLOCK_DRIFT;
		if(verbose) printf("drift_error: %ld\n",drift_error);
	  	ADD_TO_TRT(i,3, (long)drift_error);
	  }
	  if(verbose)printf("New:\t%ld %ld %ld %ld\n\n",trt[i][0],trt[i][1],trt[i][2],trt[i][3]);
	}
      }
      if(DELAY_ERROR != 0) if(!no_files) fprintf(stats_fp,"Added delay error of %.3f ms\n",DELAY_ERROR/1000.0);
      if(CLOCK_DRIFT != 0) if(!no_files) fprintf(stats_fp,"Added drift error of %.3f us/2\n",CLOCK_DRIFT/1000.0);
    }
    else
    {
    	if(!no_files) fprintf(stats_fp,"No corrections to original timestamps requested.\n\n");
    	if(verbose) printf("%s No corrections to original timestamps requested\n",timetoa());
    }
    
/*
 *
 *	Calculate Delay stats
 *
 */

    l_tmp=0; ul_tmp=0;

    if(verbose) printf("%s Calculating delay stats\n",timetoa());

    for(i=first_pckt;i<=seq;i++)
    {
	diff_txrx = (trt[i][2] - trt[i][0])*S_TO_US + trt[i][3] - trt[i][1];

	if(diff_txrx < 0)
	{
	  fprintf(stats_fp,"Negative delay encountered in packet n. %d. Will not calculate delay & IPDV stats.\n\n",i);
	  if(verbose) printf("%s Negative delay encountered, will not calculate delay stats!\n",timetoa());
	  negative_delays++;
	}

	PKT_INFO(i,ret);
	if((ret)&&(!no_files))
	{
	  PKT_INFO(i-1,ret);
	  if((i>0) && ret)
		fprintf(stats_fp,"%d (%.3fs): tx %lu %lu (%ld) rx %lu %lu (%ld)> diff_txrx %.3f ms",i,
		((trt[i][0]-baseline_tx.tv_sec)*S_TO_US+trt[i][1]-baseline_tx.tv_usec)/S_TO_USF,
		trt[i][0],trt[i][1],
		(trt[i][0]-trt[i-1][0])*S_TO_US +trt[i][1]-trt[i-1][1],
		trt[i][2],trt[i][3],
		(trt[i][2]-trt[i-1][2])*S_TO_US +trt[i][3]-trt[i-1][3],
		diff_txrx/1000.0);
	  else
		fprintf(stats_fp,"%d (%.3fs): tx %lu %lu (0) rx %lu %lu (0)> diff_txrx %.3f ms",i,
		((trt[i][0]-baseline_tx.tv_sec)*S_TO_US+trt[i][1]-baseline_tx.tv_usec)/S_TO_USF,
		trt[i][0],trt[i][1],
		trt[i][2],trt[i][3],
		diff_txrx/1000.0);

	  PKT_INFO(i-2,ret);
	  if((i>1) && ret)
	  {
		l_tmp  = (trt[i-1][0]-trt[i-2][0])*S_TO_US +trt[i-1][1]-trt[i-2][1];
		l_tmp2 = (trt[i][0]-trt[i-1][0])*S_TO_US +trt[i][1]-trt[i-1][1];
		if(sanity_check && (diff_txrx < MINDELAY))
		  fprintf(stats_fp," <low delay?>");
	  }
	  fprintf(stats_fp,"\n");
	}
	/* IJ: Moved loop exit here to get info about offending packet */
	if (negative_delays)
	    goto no_delays;
	
	/*
	 * Is there a value?
	 * If requested, is the value sensible, within [MINDELAY,MAXDELAY]
	 *
	 */

	ul_tmp = diff_txrx;

	PKT_INFO(i,ret);
        if( ((sanity_check) && ret && (ul_tmp > MINDELAY) && (ul_tmp < MAXDELAY)) ||
          ((!sanity_check) && ret) )
        {
          del_avg += ul_tmp;
  	  del_t[i] = ul_tmp;

     	  if(ul_tmp < del_min)
	  {
	    del_min = ul_tmp;
	    del_min_n=i;
	  }
	  if((ul_tmp > del_max) && (i > 0))
	  {
	    del_max = ul_tmp;
	    del_max_n=i;
          }
	}
	else
	{
	  PKT_INFO(i,ret);
 	  if((ret) && (!no_files))
 	  {
	    fprintf(stats_fp,"Packet %d had insane delay %.3f ms\n",i,diff_txrx/1000.0);
	  }
	  else
	  {
	    if(!no_files) fprintf(stats_fp,"Packet %d was lost\n",i);
	  }
	  if(i<first_pckt)
	  errors++;
	}
    }

    if(total-errors > 0)
      del_avg = (del_avg / (total-errors));
    else
    {
    	printf("All packet delays were somehow erroneous. No stats gathered.\n");
    	return -1;
    }

    l_tmp=1; ul_tmp=0; diff_prev=0;

    /* Second pass to calculate mean deviation. We need the avg first. */

    for(i=first_pckt;i<=seq;i++)
    {
    	if((i==0) && (del_t[i] != 0))
	{
		del_mdev += abs(del_avg - del_t[i]);
		l_tmp=0;
	}
	else
	  del_mdev += abs(del_avg - del_t[i]);
    }

    del_mdev = (del_mdev / (total-l_tmp-errors));

/*
 *
 *	Calculate IPDV stats
 *
*/

    l_tmp=0; ul_tmp=0;

    for(i=first_pckt+2;i<=seq;i++)
    {
    	/* Is there info for this and previous packet? */
    	if(del_t[i] && del_t[i-1])
	{
		ul_tmp = abs(del_t[i] - del_t[i-1]);
		ipdv_avg += ul_tmp;
		if(ul_tmp < ipdv_min) ipdv_min = ul_tmp; 
		if(ul_tmp > ipdv_max) ipdv_max = ul_tmp;
		ipdv_t[i] = (del_t[i] - del_t[i-1]);
		ipdv_t_abs[i] = ul_tmp;
		l_tmp++;
        }
    }

    if(l_tmp == 0)
    {
      fprintf(stats_fp,"No IPDV can be calculated, too many lost packets!\n");    	
      no_ipdv=1;
      goto no_delays;
    }
          
    ipdv_avg = (ipdv_avg / (l_tmp));

    /* Second pass for the mean deviation */
    
    for(i=first_pckt+2;i<=seq;i++)
    {
    	if(ipdv_t[i])
		ipdv_mdev += abs(ipdv_t[i]-ipdv_avg);
    }

    ipdv_mdev = (ipdv_mdev / l_tmp);

    
/* No delay values can be calculated... */

no_delays:

/*
 *
 *	Calculate Jitter stats
 *
*/

    l_tmp=0;
    for(i=first_pckt+1;i<=seq;i++)
    {
    	/* Is there info for this and previous packet? */

	PKT_INFO(i,ret);
 	if(ret)
 	{
 	  PKT_INFO(i-1,ret);
 	  if(ret)
	  {
	  ul_tmp = (trt[i][2]-trt[i-1][2])*S_TO_US + trt[i][3]-trt[i-1][3];
          jit_avg += ul_tmp;
    	  if(ul_tmp < jit_min) { jit_min = ul_tmp; jit_min_n=i;}
    	  else if((ul_tmp > jit_max) && (ul_tmp < MAXJITTER) && (i>1)) { jit_max = ul_tmp; jit_max_n=i;}
	  jit_t[i] = ul_tmp;
	  l_tmp++;
          }
        }
    }

    if(l_tmp) jit_avg = (jit_avg / l_tmp);
    else { printf("No jitter values?\n"); }
    
    /* Second pass for the mean deviation */

    for(i=first_pckt+1;i<=seq;i++)
    {    
 	if(jit_t[i])
 	{	
    		jit_mdev += abs(jit_avg - jit_t[i]);
    	}
    }

    jit_mdev = (jit_mdev / l_tmp);

    if(!negative_delays)
      fi = ((trt[seq][2]-baseline_tx.tv_sec)*S_TO_US+trt[seq][3]-baseline_tx.tv_usec)/S_TO_USF;
    else
      fi = ((trt[seq][0]-baseline_tx.tv_sec)*S_TO_US+trt[seq][1]-baseline_tx.tv_usec)/S_TO_USF;

    if(subset) fprintf(stats_fp,"This is only a subset of [%d,%d]. Last packet actually transmitted was %d\n\n",submin,submax,subtotal);


    if(!negative_delays)    
    fprintf(stats_fp,"First packet delay was %.3f ms\n",
    ((baseline_rx.tv_sec-baseline_tx.tv_sec)*S_TO_US+baseline_rx.tv_usec-baseline_tx.tv_usec)/1000.0);

    fprintf(stats_fp,"Transmission time at the sender was %.3f seconds\n",fi);
    
    fprintf(stats_fp,"Last packet took an additional %.3f ms > %.3f seconds total time\n",
     (((trt[seq][2]-trt[seq][0])*S_TO_US+trt[seq][3]-trt[seq][1]))/1000.0,
     (((trt[seq][2]-trt[seq][0])*S_TO_US+trt[seq][3]-trt[seq][1]))/S_TO_USF + fi);

    fprintf(stats_fp,"Avg payload bit rate %.1f Kbps, with IPv4+UDP headers %.1f Kbps\n",
    ((pkt_avg*8.0) / fi)/1000.0,
    (((pkt_avg*8.0)+(total*8.0*(IP_HEADER_SIZE+UDP_HEADER_SIZE))) / fi)/1000.0);

    fprintf(stats_fp,"Avg pkt data payload size: %lu bytes (IP pkt size %lu)\n",
    pkt_avg / total,((pkt_avg/total)+IP_HEADER_SIZE+UDP_HEADER_SIZE));

    fprintf(stats_fp,"Packets %d [%d,%d] (%ld bytes), lost %d (%.2f %%)\n",
    total,first_pckt,seq,pkt_avg,(seq+1-first_pckt-total), 100.0*(seq+1-first_pckt-total)/(seq+1-first_pckt));

    if(errors>0) fprintf(stats_fp,", erroneous values %lu\nSanity range [%lu,%lu] us\n",
    errors,MINDELAY,MAXDELAY);
    else fprintf(stats_fp,"\n");
    if(duplicate_pkts>0) fprintf(stats_fp,"Duplicate packets: %lu\n",duplicate_pkts);

    if(!negative_delays)
      fprintf(stats_fp,"Delay min/max/avg/mdev:   %.3f/%.3f/%.3f/%.3f ms\n",del_min/1000.0,del_max/1000.0,del_avg/1000.0,del_mdev/1000.0);
    fprintf(stats_fp,"Jitter min/max/avg/mdev:  %.3f/%.3f/%.3f/%.3f ms\n",jit_min/1000.0,jit_max/1000.0,jit_avg/1000.0,jit_mdev/1000.0);
    if(!no_ipdv)
      fprintf(stats_fp,"IPDV min/max/avg/mdev:    %.3f/%.3f/%.3f/%.3f ms\n",ipdv_min/1000.0,ipdv_max/1000.0,ipdv_avg/1000.0,ipdv_mdev/1000.0);

    if(!negative_delays)
      fprintf(stats_fp,"\nPacket of min/max delay:  %lu / %lu\n",del_min_n,del_max_n);

    fprintf(stats_fp,"Packet of min/max jitter: %lu / %lu\n",jit_min_n,jit_max_n);


    if(no_files) return 0;
    
    if(lost > 0)
    {
    	fprintf(stats_fp,"\nPackets lost in %u bursts, average %.3f packets in a burst\n",loss_bursts,(lost*1.0/loss_bursts));
	fprintf(stats_fp,"Missing packets:\n%s\n",missing);
    }

    fi=0.0;

    fprintf(stats_fp,"\nGraph outputs in\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s\n",
    stats_fn,delay_fn,jitter_fn,ipdv_fn,delay_pdf_fn,jitter_pdf_fn,ipdv_pdf_fn,
    delay_df_fn,jitter_df_fn,ipdv_df_fn,delay_avg_fn,lost_fn);

    if(total > MOVINGAVGSMOOTH*2)
    if((del_avg_fp = fopen(delay_avg_fn,"w")) == NULL)
    {
    	perror("Error opening delay avg graph file");
    	return -1;
    }

    if((lost_fp = fopen(lost_fn,"w")) == NULL)
    {
    	perror("Error opening lost packets graph file");
    	return -1;
    }

    fprintf(lost_fp,"#Dropped packets\n");

    j=0;
    fi=0.0;k=0;ret=0;
    for(i=0;i<=seq;i++)
    {
      j=0;fi=0.0;
      PKT_INFO(i,ret);
      if(!ret)
      {
        ret++; /* used to calculate number of lost packets logged */
        j=i-1;
	
	PKT_INFO(j,ret);
        while(!ret && j>=0) {j--;PKT_INFO(j,ret);}
        k=j;
        if(k>50) for(j=k-50;j<=k;j++) fi += (del_t[j]/50.0);
        else for(j=0;j<=k;j++) fi += (del_t[j]/i);
        fi = fi/S_TO_USF; /* make from us to ms */
        j=k;
        /* estimate of when the packet was lost: */
        fi = (i-j) * fi;
        fprintf(lost_fp,"%.3f %d\n",(((trt[j][0]-baseline_tx.tv_sec)*S_TO_US+trt[j][1]-baseline_tx.tv_usec)/S_TO_USF)+fi,ret);
      }
    }
    fclose(lost_fp);

    j=0;k=0;

    if(total > MOVINGAVGSMOOTH*2)
    {
/*      moving_avg = seq / MOVINGAVGSMOOTH; */
      moving_avg = MOVINGAVGSMOOTH;
      for(i=0;i<=seq;i++)
      {
	PKT_INFO(i,ret);
        if(ret) j++;
        if(j == moving_avg) break;
      }
	
      for(i=j;i<=seq;i++)
      {
      	PKT_INFO(i,ret);
        if(ret)
        {
          j=i;
          k=0;
          fi=0.0;
	  while(k != moving_avg)
	  {
	    PKT_INFO(j,ret);
            if(ret)
            {
              fi += del_t[j];
              k++;
            }
            j--;
          }
          fi = fi / moving_avg;
          fi = fi / 1000.0;

          fprintf(del_avg_fp,"%.3f %.3f\n",((trt[i][0]-baseline_tx.tv_sec)*S_TO_US+trt[i][1]-baseline_tx.tv_usec)/S_TO_USF,fi);
        }
      }
      fclose(del_avg_fp);
    }

    if(!negative_delays)
    if((del_fp = fopen(delay_fn,"w")) == NULL)
    {
    	perror("Error opening delay graph file");
    	return -1;
    }

    if((jit_fp = fopen(jitter_fn,"w")) == NULL)
    {
    	perror("Error opening jitter graph file");
    	return -1;
    }

    if((!negative_delays) && (!no_ipdv))
    if((ipdv_fp = fopen(ipdv_fn,"w")) == NULL)
    {
    	perror("Error opening IPDV graph file");
    	return -1;
    }

    ul_tmp=0;
    j=0;

/*
 * print out the packet delay xgraph output
 * simulation time of X-axis, packet transfers time on Y-axis
 */
 
    if(!negative_delays)
    {
	ul_tmp=0;
	j=0;
	    
    for ( i = 0; i<=seq;i++)
    {
    	 if(del_t[i] > 0)
     	 {
     	 	ul_tmp+=del_t[i];
     	 	j++;
     	 	fprintf(del_fp,"%.3f %.3f\n",
     		((trt[i][0]-baseline_tx.tv_sec)*S_TO_US+trt[i][1]-baseline_tx.tv_usec)/S_TO_USF,
     		del_t[i]/1000.0);
     	 }
    }
	fclose(del_fp);
    }
/* print out the packet jitter xgraph output */

    for ( i = 1; i<=seq;i++)
     	if(jit_t[i] > 0)
     	    fprintf(jit_fp,"%.3f %.3f\n",
     	    	((trt[i][2]-baseline_rx.tv_sec)*S_TO_US+trt[i][3]-baseline_rx.tv_sec)/S_TO_USF,
     	    	jit_t[i]/1000.0);

/* print out the packet IPDV xgraph output */

    if((!negative_delays) && (!no_ipdv))
    {
      for ( i = 1; i<=seq;i++)
      {
	PKT_INFO(i,ret);
     	if(ret)
     	    fprintf(ipdv_fp,"%.3f %.3f\n",
     	    	((trt[i][0]-baseline_tx.tv_sec)*S_TO_US+trt[i][1]-baseline_tx.tv_usec)/S_TO_USF,
     	    	ipdv_t[i]/1000.0);
      }
      fclose(ipdv_fp);
    }

/* Now sort all values so that we may get the probability density functions */

    if(!negative_delays)
      qsort(&del_t[0],seq+1,sizeof(unsigned long),compulong);

    qsort(&jit_t[0],seq+1,sizeof(unsigned long),compulong);

    if((!negative_delays) && (!no_ipdv))
      qsort(&ipdv_t_abs[0],seq+1,sizeof(unsigned long),compulong);

    if((!negative_delays) && (!no_ipdv))
      qsort(&ipdv_t[0],seq+1,sizeof(long),complong);

    if(!negative_delays)
    if((del_fp = fopen(delay_pdf_fn,"w")) == NULL)
    {
    	perror("Error opening delay graph pdf file");
    	return -1;
    }

    if((jit_fp = fopen(jitter_pdf_fn,"w")) == NULL)
    {
    	perror("Error opening jitter graph pdf file");
    	return -1;
    }

    if((!negative_delays) && (!no_ipdv))
    if((ipdv_fp = fopen(ipdv_pdf_fn,"w")) == NULL)
    {
    	perror("Error opening IPDV graph pdf file");
    	return -1;
    }


/* Print out the delay pdf */

    if(!negative_delays)
    {
      ul_tmp=0;j=0;

      while(del_t[j] == 0) j++;
      step = total/DELAY_PDF_STEP;
      ul_tmp=0;
      fi = j;

      while(fi <= seq)
      {
	fprintf(del_fp,"%lu %.3f\n",ul_tmp,del_t[(int)fi]/1000.0);
	fi+=step;
	ul_tmp++;
      }
      fprintf(del_fp,"100 %.3f\n",del_t[seq]/1000.0);    
      fclose(del_fp);
    }

/* Print out the jitter pdf */

    ul_tmp=0;j=0; ul_tmp=0;
    while(jit_t[j] == 0) j++;
    fi = j;
    step = (seq-j)/JITTER_PDF_STEP;

    while(fi <= seq)
    {
	fprintf(jit_fp,"%lu %.3f\n",ul_tmp,jit_t[(int)fi]/1000.0);
	fi+=step;
	ul_tmp++;
    }

    fprintf(jit_fp,"100.1 %.3f\n",jit_t[seq]/1000.0);    
    fclose(jit_fp);

/* Print out the IPDV pdf */

    if((!negative_delays) && (!no_ipdv))
    {
      ul_tmp=0;j=0;
      ul_tmp=0;
      while(ipdv_t_abs[j] == 0) j++;
      fi = j;
      step = (seq-j)/IPDV_PDF_STEP;

      while(fi <= seq)
      {
	fprintf(ipdv_fp,"%lu %.3f\n",ul_tmp,ipdv_t_abs[(int)fi]/1000.0);
	fi+=step;
	ul_tmp++;
      }
      fprintf(ipdv_fp,"100.1 %.3f\n",ipdv_t_abs[seq]/1000.0);
      fclose(ipdv_fp);
    }

    if((jit_fp = fopen(jitter_df_fn,"w")) == NULL)
    {
    	perror("Error opening jitter graph df file");
    	return -1;
    }

    if(!negative_delays)
    {
      if((del_fp = fopen(delay_df_fn,"w")) == NULL)
      {
    	perror("Error opening delay graph df file");
    	return -1;
      }

      if(!no_ipdv)
      if((ipdv_fp = fopen(ipdv_df_fn,"w")) == NULL)
      {
    	perror("Error opening ipdv graph df file");
    	return -1;
      }

      if(!no_ipdv)
      if((ipdva_fp = fopen(ipdv_dfa_fn,"w")) == NULL)
      {
    	perror("Error opening ipdv/abs graph df file");
    	return -1;
      }
    }

/* Print out the delay density function 
 * (earlier we printed the PROBABILITY density function)
 */
 
    if(!negative_delays)
    {
      ul_tmp=0;j=0;

      while(del_t[j] == 0) j++;
      step = del_t[seq]/DELAY_DF_STEP; /* highest number */
      ul_tmp=0;

      prev=j; l_tmp=0;

      fi=del_t[j+1]+step;

      while(j<=seq)
      {
    	j=prev;
    	while((del_t[j]< fi)&&(j<=seq)) j++;
	fprintf(del_fp,"%.3f %d\n",fi/1000.0,(j-prev));
	prev=j;
	fi+=step;
      }
      fclose(del_fp);
    }
    
/* Print out the jitter df */

    ul_tmp=0;j=0;
    while(jit_t[j] == 0) j++;
    step = jit_t[seq]/JITTER_DF_STEP; /* highest number */

    prev=j; l_tmp=0;
    fi=jit_t[j+1]+step;
    while(j<=seq)
    {
    	j=prev;
    	while((jit_t[j]< fi) && (j<=seq)) j++;
	fprintf(jit_fp,"%.3f %d\n",fi/1000.0,(j-prev));
	prev=j;
	fi+=step;
    }
    fclose(jit_fp);

/* Print out the IPDV df */

    if((!negative_delays) && (!no_ipdv))
    {
      ul_tmp=0;j=0;
      step = ipdv_t[seq]/IPDV_T_STEP; /* highest number */

      prev=0;
      l_tmp=0;
      fi=ipdv_t[0];

      while(j<seq)
      {
    	j=prev;
    	while((ipdv_t[j]< fi) && (j<=seq))
    	{
    		j++; 
    		if(ipdv_t[j] == 0) 
    		l_tmp++;
    	}
	fprintf(ipdv_fp,"%.3f %ld\n",fi/1000.0,(j-prev-l_tmp));
	l_tmp = 0;
	prev=j;
	fi+=step;
	if(fi == 0) fi++;
      }    
      fclose(ipdv_fp);

/* Print out the IPDV df with absolute values */

      ul_tmp=0;j=0;
      step = ipdv_t_abs[seq]/IPDV_T_ABS_STEP; /* highest number */
      while(ipdv_t_abs[j] == 0) j++;

      prev=j;
      fi=ipdv_t_abs[j+1];

      while(j<=seq)
      {
    	j=prev;
    	while((ipdv_t_abs[j]< fi) && (j<=seq)) j++;
	fprintf(ipdva_fp,"%.3f %d\n",fi/1000.0,(j-prev));
	prev=j;
	fi+=step;
      }
      fclose(ipdva_fp);
    } 
    return 0;
}

inline int complong(const void *x, const void *y)
{
    long pp,qq;
    pp = (long)(*(long *)x);
    qq = (long)(*(long *)y);    
    if(pp<qq) return -1;
    if(pp>qq) return 1;
    return 0;
}

inline int compulong(const void *x, const void *y)
{
    unsigned long pp,qq;
    pp = (unsigned long)(*(unsigned long *)x);
    qq = (unsigned long)(*(unsigned long *)y);    
    if(pp<qq) return -1;
    if(pp>qq) return 1;
    return 0;
}

inline int wierd_value(uint index)
{
	signed long sl=0;

	sl = (trt[index][2] - trt[index][0])*S_TO_US + trt[index][3] - trt[index][1];

	if(index > 100)
	{
		if(sl < ((del_avg/index) - 3000))
			return 1;
		else if(sl < MINDELAY) return 1;
	}
	else if(sl < MINDELAY) return 1;
	return 0;
}

void usage(char *prg_name)
{
  printf("%s version %s\n",prg_name,VERSION);
  printf("Usage: %s < logfile\n",prg_name);
  printf("Parameters:\n");
  printf("  -s   make a sanity check of the values (def. no sanity check)\n");
  printf("  -m#  minimum delay considered sane in us (def: 1000 us)\n");
  printf("  -M#  maximum delay considered sane in us (def: 1000000 = 1s.)\n");
  printf("  -d#  add a delay correction of the clocks (us)\n");
  printf("  -f#  add a drift correction of the clocks (+/- us in 1 sec)\n");
  printf("  -i#  add an ID (string) to identify these files\n");
  printf("  -a#  set the moving average value of pkts for graph (def. 200)\n");
  printf("  -l   no files, just output performance numbers to screen\n");
  printf("  -n   if duplicate packets encountered, use new value (def. use first)\n");
  printf("  -N   just normalize the timestamps, no analyze\n");
  printf("  -pmin,max   only consider a subsection of packet numbers [min,max]\n");
  printf("  -R   treat all values as given by gettimeofday(), same as in jtg.\n");
  printf("  -v   verbose.\n");
  printf("  -h   this help.\n");
  printf("The identifier for the log files is used to identify tests.\n");
  printf("The delay and drift correction values are in usec\n");
  exit(0);
}
