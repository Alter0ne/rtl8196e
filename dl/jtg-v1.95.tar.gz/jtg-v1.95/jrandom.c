#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include <sys/time.h>

#include <string.h>

#include "jrandom.h"

/*
 * Distribution examples and implementation are taken from the book 
 * "Simulation Modeling & Analysis" by Law & Kelton pp. 330-350 & 496 - 512
 *
 */


/* debugging */
#ifdef RND_DEBUG
static size_t overall_count = 0;
static size_t dtype_count[RND_MAX_FUNCTIONS] = {0};
static	int rnd_inited = 0;

#define RND_STATS(x) 		  \
do {				  \
        ((rdist *)(x))->gen_count++; \
        overall_count++;	  \
        if((x)->name < RND_MAX_FUNCTIONS) dtype_count[(x)->name]++; \
} while (0)
#else
#define RND_STATS(x) do { } while (0)
#endif

/* random algorithm */
static	double	U[256];

/*
 * statistics counter functions
 */

#ifdef RND_DEBUG
size_t get_dtype_count(short name)
{
	assert(name >= RND_MAX_FUNCTIONS);
	return dtype_count[name];
}


size_t get_overall_count(void)
{
	return overall_count;
}


size_t get_dist_count(const rdist *dist)
{
	return dist->gen_count;
}

#else

size_t get_dtype_count(short name)
{
	return 0;
}


size_t get_overall_count(void)
{
	return 0;
}


size_t get_dist_count(const rdist *dist)
{
	return 0;
}

#endif /* !RND_DEBUG */


/** Initializes the random module
 *
 *  Notes: If the seed values are zero (0), the function will take seeds
 *  from current time of day.
 *
 * @param a set of seed values
 */

void setup_rnd(unsigned short seed[3])
{
	int	i;
	unsigned short *sp;

	if (seed[0] == 0 && seed[1] == 0 && seed[2] == 0)
		getseedval(seed);
	sp = seed48(seed);

	for (i = 0; i < 256; i++) 
		U[i] = drand48();

#ifdef RND_DEBUG
	rnd_inited = 1;
#endif
}


/** random function
 *
 * Returns a double value between [0.0 , 1.0]
 *
 */
 
double myrand(void)
{
	static	double	xx;
	static union {
		double ud;
		unsigned char uc[8];
	} uu;   

#ifdef RND_DEBUG
	assert(rnd_inited != 0);
#endif

	uu.ud = drand48();
	xx = U[uu.uc[6]];
	U[uu.uc[6]] = uu.ud;

	return 1.0-xx;
}


/*
 * Acquire random seed values
 * Parameter seed
 *
 */

void getseedval(unsigned short seed[3])
{
	struct timeval tv;
	
	gettimeofday(&tv, NULL);
	seed[0] = tv.tv_usec & 0xffff;
	seed[1] = tv.tv_usec >> 16;
	seed[2] = (tv.tv_sec & 0xffff) ^ (tv.tv_usec >> 16);
}


/*
 * uniform distribution
 *
 * params[0], lower limit
 * params[1], upper limit
 * 
 * Parameter: pointer to distribution
 *
 */

double uniformd(const rdist *dist)
{
	RND_STATS(dist);
	return dist->params[0]+(dist->params[1]-dist->params[0])*myrand();
}


/*
 * normal distribution
 *
 *	Parameters:	par[0], myy (or "u")
 *			par[1], lambda
 *			par[2], lower limit
 *			par[3], upper limit
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */

double normald(const rdist *dist)
{
	double U1, U2, V1, V2, Y, W=1;
	double test;
	int ok;

	do
	{
		ok = 1;
		do
		{
			U1 = myrand();
			U2 = myrand();
			V1 = 2 * U1 - 1;
			V2 = 2 * U2 - 1;
			W = (V1 * V1) + (V2 * V2);
		} while(W > 1);
	
		Y = sqrt((-2 * log(W)) / W);
		if(myrand() < 0.5) test = (V1 * Y);
		else test = (V2 * Y);

		test = dist->params[0] + dist->params[1] * test;

		if((dist->limits / 2) == 1) ok = (test <= dist->params[3]);

		if(ok)
			if((dist->limits % 2) == 1) ok = (test >= dist->params[2]);

	} while(!ok);

	RND_STATS(dist);
	return test;
}

/*
 * exponential distribution
 *
 *	Parameters: 	par[0], mean (or lambda)
 *			par[1], lower limit
 *			par[2], upper limit
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double exponentiald(const rdist *dist)
{
	double test;
	int ok;

	do
	{
		ok=1;
		test=(-dist->params[0]*log(myrand()));
		if((dist->limits / 2) == 1) ok = (test <= dist->params[2]);
		if(ok) 
			if((dist->limits % 2) == 1) ok = (test >= dist->params[1]);
	} while(!ok);
	RND_STATS(dist);
	return test;
}


/*
 * hyperexponential distribution
 *
 *	Parameters:	par[0], mean for 1. exp-funtion
 *			par[1], mean for 2. exp-funtion
 *			par[2], probability for 1. function
 *			par[3], lower limit for 1.
 *			par[4], upper limit for 1.
 *			par[5], lower limit for 2.
 *			par[6], upper limit for 2.
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double hexponentiald(const rdist *dist)
{
	double test1, test2;
	short limits;
	int ok;

	do
	{
		ok=1;
		limits = dist->limits;

		test1 = (-dist->params[0] * log(myrand()));
		test2 = (-dist->params[1] * log(myrand()));

		if((limits / 8) == 1)
		{
			ok = (test2 <= dist->params[6]);
			limits -= 8;
		}
		
		if(ok) 
		if((dist->limits / 4) == 1)
		{
 			ok = (test2 >= dist->params[5]);
			limits -= 4;
		}
		
		if(ok)
		if((dist->limits/2) == 1)
		{ 
			ok = (test1 <= dist->params[4]);
			limits -= 2;
		}
		if(ok)
			if((dist->limits % 2) == 1) ok = (test2>=dist->params[3]);
	} while(!ok);

	RND_STATS(dist);
	if(myrand() <= dist->params[2]) return test1;
	else return test2;
}


/*
 * triangular distribution
 *
 *	Parameters: 	par[0], minimun value (lower limit)
 *			par[1], Maximum values (upper limit)
 *			par[2], Highest probability (peak not(!) mean of dist.)
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double triangd(const rdist *dist)
{
        double c=0.0, U=0.0, X=0.0;

        c = (dist->params[2] - dist->params[0]) / (dist->params[1] - dist->params[0]);

        U = myrand();

        if(U <= c) X = sqrt(c*U);
        else X = 1.0 - sqrt((1.0 - c) * (1.0 - U));

	RND_STATS(dist);
        return (dist->params[0] + (dist->params[1] - dist->params[0]) * X);
}


/*
 * cauchy distribution
 *
 *	Parameters: 	par[0], mean
 *			par[1], standard deviation (or scale)
 *			par[2], lower limit
 *			par[3], upper limit
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double cauchyd(const rdist *dist)
{
	double U,test;
	int ok;	

	do
	{
		ok=1;
		U = myrand();
		test = dist->params[0] + dist->params[1] * tan(M_PI * (U - 0.5));

		if((dist->limits / 2) == 1) ok = (test <= dist->params[3]);
                if(ok) 
                	if((dist->limits % 2) == 1) ok = (test >= dist->params[2]);			
	} while(!ok);
	RND_STATS(dist);
	return test;
}


/*
 * lognormal distribution
 *
 *	Parameters:	par[0], myy
 *			par[1], lambda
 *			par[2], lower limit
 *			par[3], upper limit
 *
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */

double lognormald(const rdist *dist)
{
	rdist dist_;
	double test;
	int ok;
	double T2;

	double mean, variance;

	mean = log( (dist->params[0] * dist->params[0]) / sqrt( (dist->params[1] * dist->params[1]) + (dist->params[0] * dist->params[0]) ) );
	variance = log( ((dist->params[1] * dist->params[1]) + (dist->params[0] * dist->params[0])) / (dist->params[0] * dist->params[0]) );

	dist_ = *dist;
	dist_.params[0]=mean;
	dist_.params[1]=variance;

	do
	{
		ok=1;
		T2 = normald(&dist_);
		test = exp(T2);
		
		if((dist->limits / 2) == 1) ok = (test <= dist->params[3]);
		if(ok) if((dist->limits % 2) == 1) ok = (test >= dist->params[2]);
	} while(!ok);
	RND_STATS(dist);
	return test;
}


/*
 * gamma distribution
 *
 *	Parameters: 	par[0], shape of first distribution
 *			par[1], shape of second distribution
 *			par[2], lower limit
 *			par[3], upper limit
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */

double gammad(const rdist *dist)
{
	int ok, oktoo;
	double U1,U2,P,b,Y,a,q,O,d,V,W,Z,test;

	do
	{
	oktoo=1;
	if(dist->params[0] <= 1)
	{
		b = ((exp(1) + dist->params[0]) / exp(1));	
		do
		{
			ok=1;
			U1 = myrand();
			P = b * U1;

			if(P > 1)
			{
				Y = -log(((b-P)/dist->params[0]));
				U2 = myrand();
				ok = (U2 <= pow(Y,(dist->params[0] - 1)));
			}	
			else
			{
				Y = pow(P,(1/dist->params[0]));
				U2 = myrand();
				ok = (U2<=pow(exp(1),-Y));
			}
		} while(!ok);
	}
	else
	{	
		a = 1 / sqrt(2*dist->params[0]-1);
		b = dist->params[0] - log(4);
		q = dist->params[0] + (1/a);
		O = 4.5;
		d = 1 + log(O);
		do
		{
			ok=1;
			U1 = myrand();
			U2 = myrand();
			V = a * log( (U1 / (1-U1)) );
			Y = dist->params[0] * exp(V);
			Z = U1 * U1 * U2;
			W = b + (q*V) - Y;
			if((W + d - (O*Z))>=0) ok = 1;
			else ok = (W >= log(Z));
		}while(!ok);
	}

	test = Y * dist->params[1];
	
	if((dist->limits / 2) == 1) oktoo = ( test <= dist->params[3]);

	if(oktoo) 
		if((dist->limits % 2) == 1) oktoo = ( test >= dist->params[2]);
	} while(!oktoo);

	RND_STATS(dist);
	return test;
}


/*
 * beta distribution
 *
 *	Parameters: 	par[0], first gamma function shape
 *			par[1], second gamma function shape
 *			par[2], lower limit
 *			par[3], upper limit
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double betad(const rdist *dist)
{
	rdist dist1, dist2;
	int ok;
	double Y1,Y2;

	double test;

	dist1 = *dist;
	dist2 = *dist;

	dist1.params[1] = 1.0;

	dist2.params[0] = dist2.params[1];
	dist2.params[1] = 1.0;

	do
	{
		ok = 1;
		Y1 = gammad(&dist1);
		Y2 = gammad(&dist2);

		test =  (Y1 / (Y1 + Y2) );

		if((dist->limits / 2) == 1) ok = ( test <= dist->params[3]);
		if(ok) if((dist->limits % 2) == 1) ok = ( test >= dist->params[2]);
	} while(!ok);
	RND_STATS(dist);
	return test;
}

/*
 * poisson distribution
 *
 * params[0] is the mean value
 *
 * NOTE! Does not return a number between [0..1].
 *
 * Parameter: pointer to distribution
 * Returns integer values (casted to double, though) (!)
 *
 */
 
double poissond(const rdist *dist)
{
	double a, b, U;
	int i;

	a = exp(-dist->params[0]);
	b = 1.0;
	i = 0;

	RND_STATS(dist);

	while (1) {
		U = myrand();
		b = b * U;
		if (b < a) return (double) i;
		i++;
	}
}


/*
 * user distribution
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double userd(const rdist *dist)
{
	struct usergiven_distribution *user = dist->userdata;
	double d = user->values[user->pos++];

	if (user->pos >= user->count)
		user->pos = 0;
	RND_STATS(dist);
	return d;
}

/*
 * static distribution
 *
 * Parameter: pointer to distribution
 * Returns the same double-precision floating point number
 *
 */
 
double staticd(const rdist *dist)
{
	RND_STATS(dist);
	return dist->params[0];
}

/*
 * null distribution
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double noned(const rdist *dist)
{
	RND_STATS(dist);
	return 0.0;
}



/*
 * Two-state markov distribution
 *
 * 	Parameters: 	0, poisson parameter for state 1
 *			1, state change probability to state 2 (poisson parameter)
 *			2, poisson parameter for state 2
 *			3, state change probability to state 1 (poisson parameter)
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double markov2d(const rdist *dist)
{
	struct markov2d_dist *markov = dist->userdata;

	long state_length = !markov->state?dist->params[1]:dist->params[3];

	if (happened(add_tv(markov->time_state_entered, ms2tv(state_length)))) {
		markov->state ^= 1;
		markov->time_state_entered = cur_time_rel(0);
	}
	
	if(!markov->state)
		return dist->params[0];
	else
		return dist->params[2];
}

/*
 * markov2 distribution (old version)
 *
 * 	Parameters: 	0, poisson parameter for state 1
 *			1, state change probability to state 2 (poisson parameter)
 *			2, poisson parameter for state 2
 *			3, state change probability to state 1 (poisson parameter)
 *
 * Parameter: pointer to distribution
 * Returns a double-precision floating point number
 *
 */
 
double markov2d_old(const rdist *dist)
{
	struct markov2d_dist *markov = dist->userdata;
	double ret=0.0;
	rdist tmp;

	tmp.name=POISSON;
	
	if (!markov->iterations) {
		if(!markov->state)
			tmp.params[0] = dist->params[3];
		else
			tmp.params[0] = dist->params[1];
		markov->iterations = poissond(&tmp);
		markov->state ^= 1;
	}
	
	if(!markov->state)
		tmp.params[0] = dist->params[0];
	else
		tmp.params[0] = dist->params[2];
		
	ret = poissond(&tmp);
	markov->iterations--;
	return ret;
}

