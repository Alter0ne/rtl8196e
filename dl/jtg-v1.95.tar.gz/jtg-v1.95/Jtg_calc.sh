#!/bin/bash

export JTGCALC_PARAM=""

if [ $# -lt 1 ]; then
echo "Jtgcalc.sh - batch processing of jtg logs"
echo "Usage: Jtg_calc.sh filenames"
echo "Wildcard filenames are ok"
echo "Use JTGCALC_PARAM to define jtg_calc parameters"
exit
fi

for i in $@; do
if [ ! -e $i ]; then
echo File $i does not exist!
exit
fi
echo "-----------------------------------------------------"
echo "Calculating $i"
jtg_calc $JTGCALC_PARAM -i "$i" < $i
echo " "
done
