/* 
 *
 * 	Jugi's Traffic Generator
 *
 *	Header file
 *
 */
 
#define HAVE_INLINE 1	/* might not be needed anymore */

#define MTU 1460 /* max packet size. Affects the bandwidth calculations. */

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836

#define	EF_PHB	0x2e
#define	AF1_PHB	0x0a
#define	AF2_PHB	0x12
#define	AF3_PHB	0x1a
#define	AF4_PHB	0x22

#define IP_HEADER_SIZE  20
#define IP6_HEADER_SIZE  40
#define UDP_HEADER_SIZE 8
#define TCP_HEADER_SIZE 20

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>

#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>           /* struct timeval */
#include <time.h>		/* struct tm */
#include <math.h>
#include <sys/resource.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <setjmp.h>

#ifdef LinuxTCP
#include <sys/sysctl.h>
#define SIZE(x) sizeof(x)/sizeof(x[0])
#endif

#ifdef USE_IPV6
#include <netinet/ip6.h>
#endif

extern int errno;

#ifdef IPTOS_TOS_MASK
#undef IPTOS_TOS_MASK
#endif

#define IPTOS_TOS_MASK	0x0

#define WRITE_BUF 1000
#define READ_BUF 1500

#define TICK 100000  /* 100000us = 100ms */

#define CONTROL_MSG_LEN 4
#define CONTROL_MSG_CH 67 /* 'C' */
#define DATA_MSG_CH 68 /* 'D' */

#ifdef USE_IPV6
struct sockaddr_in6 sinme;
struct sockaddr_in6 sinhim;
struct sockaddr_in6 frominet;
struct sockaddr_in6 sock_name;
#else
struct sockaddr_in sinme;
struct sockaddr_in sinhim;
struct sockaddr_in frominet;
struct sockaddr_in sock_name;
#endif

socklen_t sockaddrlen, fromlen;
int domain;
int fd;                         /* fd of network socket */
int rfd;                         /* fd of new connection */

int buf_tmp=0;
int buflen = 540;              /* length of buffer */
unsigned long total_bytes = 0; /* total bytes sent */
char *buf;                     /* ptr to dynamic buffer */
int nbuf = 100;                /* number of buffers to send */
int packets=0;

int udp = 0;                    /* 0 = tcp, !0 = udp */
int options = 0;                /* socket options */
int one = 1;                    /* for 4.3 BSD style setsockopt() */
short port = 2000;              /* TCP/UDP dest port number */
short port_tx = 0;		/* TCP/UDP src port number */
int check_port_tx = 1;
char *host;                     /* ptr to name of host */
int trans=1;                      /* 0=receive, !0=transmit mode */
int going = 1;

int exit_flag=0;
int N_period;

FILE	*fr=NULL;			/* file to log received packets or to read values from (trans)*/

struct hostent *addr;

char stats[128];
double t;                       /* transmission time */
unsigned long nbytes_tot=0;     /* bytes on net */
unsigned long nbytes_last;
int b_flag = 0;                 /* use mread() */
char *filename=NULL;
int cont = 0;
int statistic=0;

int block = 1; /* number of pkts between two kernel ticks */
int j = 0, k = 0, m = 0, d=0;
float bit=0;
unsigned long sel_num=0;
signed long sel_err=0;
int quiet=0;

/* Initially the timer type for the delay call is open */
int BUSYWAIT=0;
int OPEN=1;
int SELECT=0;

int tick=0;
unsigned long total_tick=0;
int processing_latency = 0; /* Used to make the sending even more accurate */
int processing_latency_tick_sum = 0; /* Used to make the sending even more accurate */

/*
 * Do we know the kernel HZ value?
 * If not, estimate it to be the default 100, which is bad for us...:(
 * See the Makefile where you can give the real HZ value for the current machine
 *
 */
 
#ifndef HZ
#define HZ 100
#endif

/*
 * The accuracy of the select-call. This
 * is kernel dependent, but the usual HZ value turns to 10 ms
 *
 */
 
int select_granularity = 1000000/HZ;	/* in us */

/*
 * limit after we do select()-based waiting less than
 * this value and we are force to do busy-waiting :(
 *
 */
 
int bw_limit = (1000000/HZ) * 0.95;	/* in us */

/*
 * if the delay value is larger than 10ms by
 * this amount, round the timeout to the nearest 10ms
 *
 */
 
int select_smoothing = (1000000/HZ) * 0.1;	/* in us */

int burst_idle=TICK;
int loop_max=0;
int loop=0;
int loop_n=0;
char *loop_filename=NULL;

int cbr_bw=0; /* bps */
int ip_bw=0;  /* data bw + headers */
float pckts_per_sec=0.0;
int tcplog=0;
int verb=0;
int logverb=0;
int logverbheaderprinted=0;
int process_latency=0;
unsigned long dataa=0;
unsigned long ipdataa=0;

struct tm tm1, tm2;
struct timeval t1,t2,t_tmp;
struct timeval starttime, endtime;
struct timeval time_c, time_f, diff;

int end_receiver=0;
int yes=1;
long tx_rx_now[4];
long tx_rx_prev[4];

double cput, realt, realt_check, realt_now;   /* user, real time (seconds) */
struct timeval tx,rx,base_time;
unsigned long tx_num=0, rx_num=0;
unsigned long *pkt_time_sec=NULL, *pkt_time_usec=NULL, *pkt_num=NULL;
unsigned long *pkt_ntime_sec=NULL, *pkt_ntime_usec=NULL;
float transfer_time=0.0;

jmp_buf jmpbuffer;
int fromsigs=0;

unsigned int end_time=0;

struct sockaddr_in from;
socklen_t len=0;

#ifdef USE_IPV6
int ipv6=1;
#else
int ipv6=0;
#endif

/*
 * Added originally by Tuomas 31.01.2003
 * Use a TCP connection outside the UDP stream to inform the receiver that the
 * client is done with the UDP transfer
 */

int   a_method   = 0;                        /* 1 == use alt. address */
char  a_host[22] = {'\0'};                   /* alternative address and port */
int   a_fd       = 0;
int   a_listenfd = 0;
int   a_fd_init  = 0;
int   a_port     = 0;
char *a_pos      = NULL;
struct hostent *a_addr;

#ifdef USE_IPV6
struct sockaddr_in6 a_sinme;
struct sockaddr_in6 a_sinhim;
struct sockaddr_in6 a_frominet;
#else
struct sockaddr_in a_sinme;
struct sockaddr_in a_sinhim;
struct sockaddr_in a_frominet;
#endif

unsigned long a_addr_tmp;
socklen_t a_fromlen;

int use_delay_file=0;
int use_pckt_file=0;

char *delay_filename=NULL;
char *pckt_filename=NULL;

#define MAX_VALUES 64000
unsigned int pckt_table[MAX_VALUES];
unsigned long delay_table[MAX_VALUES];

unsigned int pckt_table_max=0;
unsigned int delay_table_max=0;

/* Variables to use for the sender to bind to specified IP-address */
int   do_bind     = 0;
char  bind_ip4[16] = {'\0'};                   /* IPv4 to bind */
char  bind_ip6[40] = {'\0'};                   /* IPv6 to bind */

/*
 * Added for the gnuplot-functionality
 *
 */

 char *gnuplot_filename="jtg.dat";
 int gnuplot=0;

/*
 * Parameters for setting the TCP options
 *
 */

enum {NOT_SET=0,USE_SETSOCKOPT,USE_SETSOCKOPTTCP,USE_PROC, USE_PROCANDRESTORE};

int tcpoptions=0; /* this many entries, calculated later exactly */
int tcpoptionsset=0; /* Are any of the options set? */

int procfd;

struct tcpopts_struct
{
  char *name;  /* name of the command line parameter */
  int namelen; /* the strings name, used for the strncmp() functions */
  int option;  /* The define of the options, for setsockopt() */
  char *proc_entry; /* The /proc/sys/ path of the parameter if available */
  int value;   /* The new value of the parameter */
  int oldvalue; /* The old value of the parameter */
  int option_use; /* How to set the option? USE_SETSOCKOPT/USE_PROC */
  int option_set; /* Is the option set? Initially NOT_SET */
};


#ifdef LinuxTCP

struct tcpopts_struct tcpopts[] = {

/* Generic socket options */

{"SNDBUF",6,SO_SNDBUF,NULL,0,0,USE_SETSOCKOPT,NOT_SET},
{"RCVBUF",6,SO_RCVBUF,NULL,0,0,USE_SETSOCKOPT,NOT_SET},
{"DEBUG",5,SO_DEBUG,NULL,0,0,USE_SETSOCKOPT,NOT_SET},

/* setsockopt() TCP-related variables */
{"MAXSEG",6,TCP_MAXSEG,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"NODELAY",7,TCP_NODELAY,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"CORK",4,TCP_CORK,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"KEEPIDLE",8,TCP_KEEPIDLE,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"KEEPINTVL",9,TCP_KEEPINTVL,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"KEEPCNT",7,TCP_KEEPCNT,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"SYNCNT",6,TCP_SYNCNT,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"LINGER2",7,TCP_LINGER2,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"DEFER_ACCEPT",12,TCP_DEFER_ACCEPT,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"WINDOW_CLAMP",12,TCP_WINDOW_CLAMP,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"QUICKACK",8,TCP_QUICKACK,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},

/* /proc variables */

{"timestamps",10,NOT_SET,"/proc/sys/net/ipv4/tcp_timestamps",0,0,USE_PROC,NOT_SET},
{"sack",4,NOT_SET,"/proc/sys/net/ipv4/tcp_sack",0,0,USE_PROC,NOT_SET},
{"dsack",5,NOT_SET,"/proc/sys/net/ipv4/tcp_dack",0,0,USE_PROC,NOT_SET},
{"fack",4,NOT_SET,"/proc/sys/net/ipv4/tcp_fack",0,0,USE_PROC,NOT_SET},
{"ecn",3,NOT_SET,"/proc/sys/net/ipv4/tcp_ecn",0,0,USE_PROC,NOT_SET},
{"frto",4,NOT_SET,"/proc/sys/net/ipv4/tcp_frto",0,0,USE_PROC,NOT_SET},
{"tw_recycle",10,NOT_SET,"/proc/sys/net/ipv4/tcp_tw_recycle",0,0,USE_PROC,NOT_SET},
{"tw_reuse",8,NOT_SET,"/proc/sys/net/ipv4/tcp_tw_reuse",0,0,USE_PROC,NOT_SET},
{"stdurg",6,NOT_SET,"/proc/sys/net/ipv4/tcp_stdurg",0,0,USE_PROC,NOT_SET},
{"window_scaling",14,NOT_SET,"/proc/sys/net/ipv4/tcp_window_scaling",0,0,USE_PROC,NOT_SET},
{"tw_reuse",8,NOT_SET,"/proc/sys/net/ipv4/tcp_tw_reuse",0,0,USE_PROC,NOT_SET},
{"app_win",7,NOT_SET,"/proc/sys/net/ipv4/tcp_app_win",0,0,USE_PROC,NOT_SET},
{"adv_win_scale",13,NOT_SET,"/proc/sys/net/ipv4/tcp_adv_win_scale",0,0,USE_PROC,NOT_SET},
{"low_latency",11,NOT_SET,"/proc/sys/net/ipv4/tcp_low_latency",0,0,USE_PROC,NOT_SET},

/* parameters used by CS projects */

{"iwtcp_iw",8,NOT_SET,"/proc/sys/net/ipv4/iwtcp_iw",0,0,USE_PROC,NOT_SET},
{"iwtcp_newreno",13,NOT_SET,"/proc/sys/net/ipv4/iwtcp_newreno",0,0,USE_PROC,NOT_SET},
{"iwtcp_quickacks",15,NOT_SET,"/proc/sys/net/ipv4/iwtcp_quickacks",0,0,USE_PROC,NOT_SET},
{"iwtcp_cbi",9,NOT_SET,"/proc/sys/net/ipv4/iwtcp_cbi",0,0,USE_PROC,NOT_SET},
{"iwtcp_srwnd_addr",16,NOT_SET,"/proc/sys/net/ipv4/iwtcp_srwnd_addr",0,0,USE_PROC,NOT_SET},
{"iwtcp_srwnd_size",16,NOT_SET,"/proc/sys/net/ipv4/iwtcp_srwnd_size",0,0,USE_PROC,NOT_SET},
{"iwtcp_rto_behaviour",19,NOT_SET,"/proc/sys/net/ipv4/iwtcp_rto_behaviour",0,0,USE_PROC,NOT_SET},

/* This must be the last entry */
 
{NULL,0,0,NULL,0,0,NOT_SET,NOT_SET}
};

#else

struct tcpopts_struct tcpopts[] = {

/* Generic socket options */

{"SNDBUF",6,SO_SNDBUF,NULL,0,0,USE_SETSOCKOPT,NOT_SET},
{"RCVBUF",6,SO_RCVBUF,NULL,0,0,USE_SETSOCKOPT,NOT_SET},
{"DEBUG",6,SO_DEBUG,NULL,0,0,USE_SETSOCKOPT,NOT_SET},

/* setsockopt() TCP-related variables */
{"KEEPALIVE",9,TCP_KEEPALIVE,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"MAXRT",5,TCP_MAXRT,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"MAXSEG",6,TCP_MAXSEG,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"NODELAY",7,TCP_NODELAY,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},
{"STDURG",6,TCP_STDURG,NULL,0,0,USE_SETSOCKOPTTCP,NOT_SET},

/* This must be the last entry! */
 
{NULL,0,0,NULL,0,0,NOT_SET,NOT_SET}
};

#endif

/*
 *
 * Forward declarations of functions
 *
 */

char* tvtoa(struct timeval tv);
void add_int2tv(struct timeval *to, int us);
char *timetoa();
char *datetoa();
void prep_timer();
void fill_array();
double read_timer();
float random_uniform ();
float random_exponential (float);

void err(char *);
void mes(char *);
void pattern(register char *, register int);
void delay(int,int);
int Nwrite(int fd, char *buf, int count );
int Nread(int fd, int afd, char *buf, int count );
int mread(int fd, register char *bufp, unsigned n);
static void sigs(int signo);
void pusage( char *name);
int parsetcpopt(char *, int);
void printtcpopts();
int settcpopts(int);
void restoretcpopts();

#define TAKE_STATS 1
#define NO_STATS 0

#define diff_tv(t1,t2) ((t1.tv_sec - t2.tv_sec)*1000000 + (t1.tv_usec - t2.tv_usec))

/*
 *
 * Simple function to print error message and exit
 *
 * If mode is true, printing is done with perror
 *
 */
 
void err_exit(char *err_msg, int mode)
{
  if(mode) perror(err_msg);
  else printf("%s\n",err_msg);
  exit(-1);
}

/*
 *
 * Returns true if msg is (most) probably a data packet.
 * Need to change this, if the structure of control packets differs.
 * This must be called, if we suspect that a small packet of size
 * CONTROL_MSG_LEN could be a control packet.
 * 
 */
 
inline int is_data_pckt(char *msg, int len)
{
  int p=0;
  if(len != CONTROL_MSG_LEN) return 1;
  for(p=0;p<CONTROL_MSG_LEN;p++)
  	if(msg[p] != DATA_MSG_CH) return 0;
  return 1;
}

/* inline */

void do_normalize()
{
  if(base_time.tv_sec > tx_rx_now[2])
  {
  	fprintf(stderr,"Receiver's clock is trailing behind sender's clock!\n");
  	fprintf(stderr,"Can't normalize! Exiting...\n");
  	exit(-1);
  }

  tx_rx_now[0] =  tx_rx_now[0] - base_time.tv_sec;
  tx_rx_now[2] =  tx_rx_now[2] - base_time.tv_sec;

  if(tx_rx_now[1] >= base_time.tv_usec)
  {
    tx_rx_now[1] -= base_time.tv_usec;
  }
  else
  {
    tx_rx_now[1] = tx_rx_now[1] + 1000000 - base_time.tv_usec;
    tx_rx_now[0]--;
  }

  if(tx_rx_now[3] >= base_time.tv_usec)
  {
    tx_rx_now[3] -= base_time.tv_usec;  	
  }
  else
  {
    tx_rx_now[3] = tx_rx_now[3] + 1000000 - base_time.tv_usec;
    tx_rx_now[2]--;
  }
  gmtime_r(&tx_rx_now[0],&tm1);
  gmtime_r(&tx_rx_now[2],&tm2);
}

/*
 *
 * And finally some external declarations needed by the main program
 *
 */

extern char *optarg;
extern int optind, opterr, optopt;
