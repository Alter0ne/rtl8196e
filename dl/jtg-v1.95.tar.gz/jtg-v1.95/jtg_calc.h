#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

#define VERSION "1.41 (28th November, 2006)"

#define TOOLOW(x) (x < (del_avg-jit_mdev))

/* returns us */
#define FROMTX(x) ((trt[x][0]-baseline_tx.tv_sec)*1000000+trt[x][1]-baseline_tx.tv_usec)
#define FROMRX(x) ((trt[x][2]-baseline_rx.tv_sec)*1000000+trt[x][3]-baseline_rx.tv_usec)

#define FROMSTART(x) ((trt[x][2]-baseline_tx.tv_sec)*1000000+trt[x][3]-baseline_tx.tv_usec)

#define IP_HEADER_SIZE  20
#define UDP_HEADER_SIZE 8

#define MAX 1000000 /* how many values can be analyzed from the log file */

#define S_TO_US  1000000

#define S_TO_USF 1000000.0

/* The following define how the graphs are formatted */
/* How many packets gathered together? */
/* These only affect the DF and PDF graphs, and how they look like */

#define IPDV_T_STEP 	100.0 
#define IPDV_T_ABS_STEP 200.0
#define JITTER_DF_STEP	100.0
#define DELAY_DF_STEP	100.0
#define IPDV_PDF_STEP	100.0
#define JITTER_PDF_STEP	100.0
#define DELAY_PDF_STEP	100.0

/* In microseconds, maximum sensible value for the delay/jitter. Values above
 * this would have a error of some kind, eg. over- or underflow
 */
 
unsigned long MAXDELAY=1000000;		/* 1 second...:) */
unsigned long MAXJITTER=500000;		/* 0.5 second */

/* This is value to find out erroneous values from the stats. The delay
 * cannot be lower than this (physical impossibility :)
 */
 
unsigned long MINDELAY=1000;		/* 1 ms ... */

   /* 
      Clock skew in us per second of simulation time
      Values between 30 and 60 work for us, sometimes up to 500
   */

long CLOCK_DRIFT=0.0;	/* in us */
long DELAY_ERROR=0;	/* in us */
long drift_error=0;
long add_trt_l=0;

int MOVINGAVGSMOOTH=200;  /* Calculate 200 pkt moving average */

/* 
 * Four hours safety margin for the midnight wrap-around.
 * This should be useless as the timestamps are in-order?
 */
 
#define WRAP_AROUND_SAFETY_MARGIN 4*3600




/* A string holding the packet numbers of all lost packets */

char missing[65536]; /* big enough? :) */


/* the table where all values from packets are stored */ 

unsigned long trt[MAX][4]; /* [0]=Tx sec, [1]=Tx us, [2]=Rx sec, [3]=Rx us */

unsigned long jit_t[MAX]; /* Jitter values table */ 
unsigned long del_t[MAX]; /* Delay values table */
signed long ipdv_t[MAX];  /* IPDV values table */

unsigned long ipdv_t_abs[MAX];
unsigned long jit_avg=0,jit_max=0,jit_min=10000000,jit_mdev=0,del_avg=0;
unsigned long jit_min_n=0, jit_max_n=0,del_min_n=0,del_max_n=0;
unsigned long del_max=0, del_min=10000000, del_mdev=0;    
unsigned long ipdv_avg=0, ipdv_max=0, ipdv_min=10000000, ipdv_mdev=0;
unsigned long ul_tmp, diff_prev=0;
unsigned long pkt_avg=0;
unsigned long errors=0;
unsigned long duplicate_pkts=0;
unsigned int seq=0, lost=0, total=0, loss_bursts=0, high_seq=0;
unsigned int tx_h,tx_m,rx_h,rx_m,size;
unsigned int tx_extra=0, rx_extra=0; /* Over mid-nights handling */
unsigned int tx_hm, rx_hm;           /* Temporaries */
unsigned int first_pckt=0;

#ifdef J_FIX
    long diff_tx=0,diff_rx=0;
#endif

signed long diff_txrx=0, l_tmp2=0;
signed long l_tmp=0;

float step=0.0, fi=0.0;
float tx_s,rx_s;

int negative_delays=0;
int sanity_check=0;
int keep_old=1;
int prev=0,ret=0,last=0, len=0;
int subset=0,submin=0,submax=MAX, subseq=0, subtotal; /* used wit the subset -p parameter */
int no_ipdv=0;
int verbose=0;
int no_files=0;
int normalize=0;
int moving_avg=0;
int op=0;
int is_filename_id=0;
int gtod_ts=0; /* Use gettimeofday-based timestamps? */

struct timeval baseline_tx={0,0}; /* TX basevalue for the first packet */
struct timeval baseline_rx={0,0}; /* RX basevalue for the first packet */
struct timeval ntv_tx, ntv_rx; /* Used for the process_normalize function */
struct timeval tx, rx; /* The timevals of latest read packet (for scanf) before storing it */



FILE *del_fp=NULL,*jit_fp=NULL,*ipdv_fp=NULL,*ipdva_fp=NULL;
FILE *del_avg_fp=NULL, *lost_fp;
FILE *stats_fp;

char filename_id[1024];

char line[1024];

/* Filenames for the different graphs */

char delay_fn[256];
char jitter_fn[256];
char ipdv_fn[256];
char delay_pdf_fn[256];
char jitter_pdf_fn[256];
char ipdv_pdf_fn[256];
char delay_df_fn[256];
char jitter_df_fn[256];
char ipdv_df_fn[256];
char ipdv_dfa_fn[256];
char delay_avg_fn[256];
char lost_fn[256];
char stats_fn[256];


/* 
 * Add us to given trt-entry.
 * "Which" must be either 1 or 3
 * "us" may be negative (!)
 *
 */

#define ADD_TO_TRT(i,which,us) {\
  if((which != 1) && (which != 3)) err_exit("bad value in ADD_TO_TRT()");\
  if((trt[i][which] == 0) && (trt[i][which-1] == 0)) exit(0);\
  if((us * -1) < trt[i][which]) trt[i][which] += us;\
  else /* else trt[i][which] would go below zero... */\
  {\
    add_trt_l = trt[i][which] + us;\
    trt[i][which-1] += (add_trt_l/1000000) - 1;\
    add_trt_l%=1000000;\
    trt[i][which] = + 1000000 + add_trt_l;\
  }\
  if(trt[i][which] > 1000000)\
  {\
  	trt[i][which] = (trt[i][which] % 1000000);\
  	trt[i][which-1] += (trt[i][which] / 1000000);\
  }\
}\

/*
 * Return true if there is information about a particular packets
 * If any value is not zero, there is info (values are zerod at program start)
 *
 */

#define PKT_INFO(i,result) \
{ \
  if(trt[i][0] > 0) result=1;\
  else if(trt[i][1] > 0) result=1;\
  else if(trt[i][2] > 0) result=1;\
  else if(trt[i][3] > 0) result=1;\
  else result=0;\
}\

/* Forward declarations */

inline int complong(const void *x, const void *y);
inline int compulong(const void *x, const void *y);
inline int wierd_value(uint index);
void usage(char *prg_name);

void err_exit(char *ee_msg)
{
  printf("%s\n",ee_msg);
  exit(0);
}


#include <stdio.h>
#include <time.h>
#include <sys/time.h>

char* timetoa()
{
        static char jep[32];
        struct timeval tv;
        struct tm tm;
        int n;
        gettimeofday(&tv,NULL);
        localtime_r(&tv.tv_sec,&tm);
        n=snprintf(&jep[0],32,"%d:%s%d:%s%d.",
        tm.tm_hour,
        (tm.tm_min>9)?"":"0",tm.tm_min,
        (tm.tm_sec>9)?"":"0",tm.tm_sec);
        if(tv.tv_usec < 100000) jep[n++]='0';
        if(tv.tv_usec < 10000) jep[n++]='0';
        if(tv.tv_usec < 1000) jep[n++]='0';
        if(tv.tv_usec < 100) jep[n++]='0';
        if(tv.tv_usec < 10) jep[n++]='0';
        sprintf(&jep[n],"%lu",tv.tv_usec);
        return &jep[0];
}

char* tvtoa(struct timeval tv)
{
        static char jep[32];
        struct tm tm;
        int n;
        gmtime_r(&tv.tv_sec,&tm);
        n=snprintf(&jep[0],32,"%d:%s%d:%s%d.",
        tm.tm_hour,
        (tm.tm_min>9)?"":"0",tm.tm_min,
        (tm.tm_sec>9)?"":"0",tm.tm_sec);
        if(tv.tv_usec < 100000) jep[n++]='0';
        if(tv.tv_usec < 10000) jep[n++]='0';
        if(tv.tv_usec < 1000) jep[n++]='0';
        if(tv.tv_usec < 100) jep[n++]='0';
        if(tv.tv_usec < 10) jep[n++]='0';
        sprintf(&jep[n],"%lu",tv.tv_usec);
        return &jep[0];
}

