#include <stdio.h>

#include "client.h"



void 
test_client(void) {

    printf("Running dummy client test.");

    printf("\n");
    printf("Client tests done.\n");
}
