void
test_server_abyss(void);
