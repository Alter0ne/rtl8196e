/****************************************************************************
 * Copyright (C) 1998 WIDE Project. All rights reserved.
 * Copyright (C) 1999,2000,2001,2002 University of Tromso. All rights reserved.
 * Copyright (C) 2002 Invenia Innovation AS. All rights reserved.
 *
 * Author: Feike W. Dillema, feico@pasta.cs.uit.no.
 *         based on newbie code by Yusuke DOI, Keio Univ. Murai Lab.
 ****************************************************************************/

/*
 * <$Id: acconfig.h,v 3.6 2002/03/04 12:34:10 dillema Exp $>
 */

@TOP@

#undef HAVE_SIN6_SCOPE_ID

#undef SHUT_RD

#undef SHUT_WR

#undef SHUT_RDWR

#undef HAVE_SA_LEN_FIELD

#undef NEEDSV4MAPPED

#undef WILDCARDONLY


