#define DBNAME "europa"
#define DBHOST "localhost"
#define DBUSER "europa"
#define DBPASSWD "APASSWD"

