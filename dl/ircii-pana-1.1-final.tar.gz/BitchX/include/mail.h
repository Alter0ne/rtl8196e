/*
 * mail.h: header for mail.c
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: mail.h,v 1.1.1.1 2003/04/11 01:09:07 dan Exp $
 */

#ifndef __mail_h_
#define __mail_h_

	char	*check_mail (void);
	int	check_mail_status (void);

#endif /* __mail_h_ */
