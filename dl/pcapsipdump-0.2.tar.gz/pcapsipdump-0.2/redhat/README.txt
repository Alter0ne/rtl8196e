To create an RPM package:

rpmbuild -tb pcapsipdump-{version}.tar.gz
