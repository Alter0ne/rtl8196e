#ifndef __CPHIDGETATTR
#define __CPHIDGETATTR

#ifndef EXTERNALPROTO
typedef struct {
	int numAxis;
} CPhidgetAccelerometerAttr;

typedef struct {
	int numMotors;
} CPhidgetAdvancedServoAttr;

typedef struct {
	int numEncoders;
	int numInputs;
} CPhidgetEncoderAttr;

typedef struct {
	int dummy;
} CPhidgetGPSAttr;

typedef struct {
	int numAxis;
} CPhidgetGyroscopeAttr;

typedef struct {
	int numSensors;
	int numInputs;
	int numOutputs;
} CPhidgetInterfaceKitAttr;

typedef struct {
	int numLEDs;
} CPhidgetLEDAttr;

typedef struct {
	int numMotors;
	int numInputs;
} CPhidgetMotorControlAttr;

typedef struct {
	int dummy;
} CPhidgetPHSensorAttr;

typedef struct {
	int numOutputs;
} CPhidgetRFIDAttr;

typedef struct {
	int numMotors;
} CPhidgetServoAttr;

typedef struct {
	int numMotors;
	int numInputs;
} CPhidgetStepperAttr;

typedef struct {
	int numTempInputs;
} CPhidgetTemperatureSensorAttr;

typedef struct {
	int numRows;
	int numColumns;
} CPhidgetTextLCDAttr;

typedef struct {
	int numRows;
	int numColumns;
} CPhidgetTextLEDAttr;

typedef struct {
	int dummy;
} CPhidgetWeightSensorAttr;

typedef struct {
	int dummy;
} CPhidgetIRAttr;

typedef struct {
	int numAccelAxes;
	int numGyroAxes;
	int numCompassAxes;
} CPhidgetSpatialAttr;

typedef struct {
	int dummy1;
	int dummy2;
	int dummy3;
} CPhidgetDummyAttr;

typedef union {
	CPhidgetDummyAttr dummy; /* field for unnamed initializers */
	CPhidgetAccelerometerAttr accelerometer;
	CPhidgetAdvancedServoAttr advancedservo;
	CPhidgetEncoderAttr encoder;
	CPhidgetGPSAttr gps;
	CPhidgetGyroscopeAttr gyroscope;
	CPhidgetInterfaceKitAttr ifkit;
	CPhidgetIRAttr ir;
	CPhidgetLEDAttr led;
	CPhidgetMotorControlAttr motorcontrol;
	CPhidgetPHSensorAttr phsensor;
	CPhidgetRFIDAttr rfid;
	CPhidgetServoAttr servo;
	CPhidgetSpatialAttr spatial;
	CPhidgetStepperAttr stepper;
	CPhidgetTemperatureSensorAttr temperaturesensor;
	CPhidgetTextLCDAttr textlcd;
	CPhidgetTextLEDAttr textled;
	CPhidgetWeightSensorAttr weightsensor;
} CPhidgetAttr;
#endif

/** \addtogroup phidconst
 * @{
 */
#ifndef EXTERNALPROTO
/* Device Class - valid class numbers start at 2, 1 is used for a 'NOTHING' device */
/* If we change the order of this list, or add to it:
 * -increment webservice protocol version (don't bother for prototypes)
 * -change name list in cphidgetconstants.c
 * -update .NET, etc.
 * -update function pointer lists in csocketevents.c (phidget21) and eventhandlers.c (webservice)
 * -update PHIDGET_DEVICE_CLASS_COUNT
 */
#endif
/**
 * Phidget device class uniquely identifies a class of Phidgets.
 */
typedef enum  {
	PHIDCLASS_NOTHING = 1,		/**< Nothing */
	PHIDCLASS_ACCELEROMETER,	/**< Phidget Accelerometer */
	PHIDCLASS_ADVANCEDSERVO,	/**< Phidget Advanced Servo */
	PHIDCLASS_ENCODER,			/**< Phidget Encoder */
	PHIDCLASS_GPS,				/**< Phidget GPS */
	PHIDCLASS_GYROSCOPE,		/**< Phidget Gyroscope */
	PHIDCLASS_INTERFACEKIT,		/**< Phidget Interface Kit */
	PHIDCLASS_LED,				/**< Phidget LED */
	PHIDCLASS_MOTORCONTROL,		/**< Phidget Motor Control */
	PHIDCLASS_PHSENSOR,			/**< Phidget PH Sensor */
	PHIDCLASS_RFID,				/**< Phidget RFID */
	PHIDCLASS_SERVO,			/**< Phidget Servo */
	PHIDCLASS_STEPPER,			/**< Phidget Stepper */
	PHIDCLASS_TEMPERATURESENSOR,/**< Phidget Temperature Sensor */
	PHIDCLASS_TEXTLCD,			/**< Phidget TextLCD */
	PHIDCLASS_TEXTLED,			/**< Phidget TextLED */
	PHIDCLASS_WEIGHTSENSOR,		/**< Phidget Weight Sensor */
#ifndef EXTERNALPROTO
	PHIDCLASS_GENERIC,
	PHIDCLASS_IR,
	PHIDCLASS_SPATIAL
#endif
} CPhidget_DeviceClass;

#ifndef EXTERNALPROTO
/* Device ID - valid id numbers start at 2, 1 is used for a 'NOTHING' device
 * This list can be re-ordered, as long as the values are not changed - we order the list alphabetically
 * Device IDs are the 1-digit interface number following by 2-digit USB PID, in hex. 
 * except for some special cases (very old phidgets)
 */
/* If we change the order of this list, or add to it:
 * -increment webservice protocol version (don't bother for prototypes)
 * -update Phid_Device_Def list
 * -update flash, .NET, etc.
 * -update PHIDGET_DEVICE_COUNT
 */
#endif
/**
 * Phidget device id uniquely identifies a specific type of Phidget.
 */
typedef enum  {

	/* These are all current devices */
	PHIDID_ACCELEROMETER_3AXIS				= 0x07E,	/**< Phidget 3-axis Accelerometer (1059) */
	PHIDID_ADVANCEDSERVO_1MOTOR				= 0x082,	/**< Phidget 1 Motor Advanced Servo (1066) */
	PHIDID_ADVANCEDSERVO_8MOTOR				= 0x03A,	/**< Phidget 8 Motor Advanced Servo (1061) */
	PHIDID_BIPOLAR_STEPPER_1MOTOR			= 0x07B,	/**< Phidget 1 Motor Bipolar Stepper Controller with 4 Digital Inputs (1063) */
	PHIDID_ENCODER_1ENCODER_1INPUT			= 0x04B,	/**< Phidget Encoder - Mechanical (1052) */
	PHIDID_ENCODER_HS_1ENCODER				= 0x080,	/**< Phidget High Speed Encoder (1057) */
	PHIDID_INTERFACEKIT_0_0_4				= 0x040,	/**< Phidget Interface Kit 0/0/4 (1014) */
	PHIDID_INTERFACEKIT_0_0_8				= 0x081,	/**< Phidget Interface Kit 0/0/8 (1017) */
	PHIDID_INTERFACEKIT_0_16_16				= 0x044,	/**< Phidget Interface Kit 0/16/16 (1012) */
	PHIDID_INTERFACEKIT_8_8_8				= 0x045,	/**< Phidget Interface Kit 8/8/8 (1013, 1018, 1019) */
	PHIDID_INTERFACEKIT_8_8_8_w_LCD			= 0x07D,	/**< Phidget Interface Kit 8/8/8 with TextLCD (1201, 1202, 1203) */
	PHIDID_LED_64							= 0x04A,	/**< Phidget LED 64 (1030) */
	PHIDID_LINEAR_TOUCH						= 0x076,	/**< Phidget Linear Touch (1015) */
	PHIDID_MOTORCONTROL_HC_2MOTOR			= 0x059,	/**< Phidget 2 Motor High Current Motor Controller (1064) */
	PHIDID_MOTORCONTROL_LV_2MOTOR_4INPUT	= 0x058,	/**< Phidget 2 Motor Low Voltage Motor Controller with 4 Digital Inputs (1060) */
	PHIDID_PHSENSOR							= 0x074,	/**< Phidget PH Sensor (1058) */
	PHIDID_RFID_2OUTPUT						= 0x031,	/**< Phidget RFID with Digital Outputs and Onboard LED (1023) */
	PHIDID_ROTARY_TOUCH						= 0x077,	/**< Phidget Rotary Touch (1016) */
	PHIDID_SERVO_1MOTOR						= 0x039,	/**< Phidget 1 Motor Servo Controller (1000) */
	PHIDID_TEMPERATURESENSOR				= 0x070,	/**< Phidget Temperature Sensor (1051) */
	PHIDID_TEXTLCD_2x20_w_8_8_8				= 0x17D,	/**< Phidget TextLCD with Interface Kit 8/8/8 (1201, 1202, 1203) */
	PHIDID_UNIPOLAR_STEPPER_4MOTOR			= 0x07A,	/**< Phidget 4 Motor Unipolar Stepper Controller (1062) */
	
	/* These are all past devices (no longer sold) */
	PHIDID_ACCELEROMETER_2AXIS				= 0x071,	/**< Phidget 2-axis Accelerometer (1053, 1054) */
	PHIDID_INTERFACEKIT_0_8_8_w_LCD			= 0x053,	/**< Phidget Interface Kit 0/8/8 with TextLCD (1219, 1220, 1221) */
	PHIDID_INTERFACEKIT_4_8_8				= 4,		/**< Phidget Interface Kit 4/8/8 */
	PHIDID_RFID								= 0x030,	/**< Phidget RFID without Digital Outputs */
	PHIDID_SERVO_1MOTOR_OLD					= 2,		/**< Phidget 1 Motor Servo Controller - Old Version */
	PHIDID_SERVO_4MOTOR						= 0x038,	/**< Phidget 4 Motor Servo Controller (1001) */
	PHIDID_SERVO_4MOTOR_OLD					= 3,		/**< Phidget 4 Motor Servo Controller - Old Version */
	PHIDID_TEXTLCD_2x20						= 0x052,	/**< Phidget TextLCD without Interface Kit (1210) */
	PHIDID_TEXTLCD_2x20_w_0_8_8				= 0x153,	/**< Phidget TextLCD with Interface Kit 0/8/8 (1219, 1220, 1221) */
	PHIDID_TEXTLED_1x8						= 0x049,	/**< Phidget TextLED 1x8 */
	PHIDID_TEXTLED_4x8						= 0x048,	/**< Phidget TextLED 4x8 (1040) */
	PHIDID_WEIGHTSENSOR						= 0x072,	/**< Phidget Weight Sensor (1050) */

#ifndef EXTERNALPROTO
	/* Nothing device */
	PHIDID_NOTHING							= 1,

	/* never released to general public */
	PHIDID_INTERFACEKIT_0_5_7				= 0x051,
	PHIDID_TEXTLCD_2x20_CUSTOM				= 0x151,
	
	/* These are unreleased or prototype devices */
	PHIDID_GPS								= 0x079,
	PHIDID_GYROSCOPE						= 0x075,
	PHIDID_LED_64_ADV						= 0x04C,	/**< Phidget LED 64 Advanced (1031) */
	PHIDID_ENCODER_HS_4ENCODER_4INPUT		= 0x04F,	/**< Phidget High Speed Encoder - 4 Encoder (1047) */
	PHIDID_TEMPERATURESENSOR_4				= 0x032,	/**< Phidget Temperature Sensor 4-input (1048) */
	PHIDID_SPATIAL_ACCEL_3AXIS				= 0x07F,	/**< Phidget Spatial 3-axis accel (1049) */
	PHIDID_IR								= 0x04D,	/**< Phidget IR Receiver Transmitter (1055) */
	PHIDID_SPATIAL_ACCEL_3_GYRO_1			= 0x04E,	/**< Phidget Spatial 3-axis accel with 1-axis gyro (1056) */
	PHIDID_SPATIAL_ACCEL_GYRO_COMPASS		= 0x033,	/**< Phidget Spatial 3/3/3 */

	/* This is for internal prototyping */
	PHIDID_GENERIC							= 0x099
#endif
} CPhidget_DeviceID;
/** @} */
#endif

