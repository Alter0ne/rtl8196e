
/******************************************************************************
**
**  Copyright (C) 2006 Brian Wotring.
**
**  This program is free software; you can redistribute it and/or
**  modify it, however, you cannot sell it.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
**
**  You should have received a copy of the license attached to the
**  use of this software.  If not, view a current copy of the license
**  file here:
**
**      http://www.hostintegrity.com/osiris/LICENSE
**
******************************************************************************/

/*****************************************************************************
**
**  File:    logging.h
**  Date:    February 17, 2002
**  
**  Author:  Brian Wotring
**  Purpose: logging routines.
**
******************************************************************************/

#ifndef LOGGING_H_
#define LOGGING_H_

void log_error( const char *message, ... );
void log_info( const char *message, ... );
void log_warning( const char *message, ... );

#endif
