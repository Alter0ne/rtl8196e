#define NOTHING
