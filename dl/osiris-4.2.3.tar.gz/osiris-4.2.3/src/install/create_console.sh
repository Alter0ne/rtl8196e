#!/bin/sh

MKDIR=`which mkdir` 
STRIP=`which strip`
SYSTEM=`uname -s`

case ${SYSTEM} in
    AIX*)
        ARCHITECTURE="aix"
        ;;
    Linux*)
        ARCH=`which arch`
	    if [ -x $ARCH ]; then
	        ARCHITECTURE=`arch`
	    else
            ARCHITECTURE=`uname -p | tr "\ " "-"`
	    fi
        ;;
    OpenBSD*)
        ARCH=`which arch`
        if [ -x $ARCH ]; then
           ARCHITECTURE=`arch -s`
        else
           ARCHITECTURE=`uname -p | tr "\ " "-"`
        fi
        ;;
    *)
        ARCHITECTURE=`uname -p`
        ;;
esac


RELEASE=`uname -r`

TAR=`which tar`
GZIP=`which gzip`

RM=`which rm`
CP=`which cp`
CHMOD=`which chmod`

VERSION=`cat version.h | grep version_string | awk '{print $3}'`

DIR_NAME="osiris-console-${VERSION}"
PACKAGE_NAME="${DIR_NAME}-${ARCHITECTURE}-${SYSTEM}-${RELEASE}.tar"
TARBALL="src/install/${PACKAGE_NAME}"

echo "-------------------------------------------------------------------------"
echo "building release tarball: ${TARBALL}.gz"

# make a temporary directory.

${MKDIR} ./${DIR_NAME}
cd ./${DIR_NAME}

# copy in version file.

${CP} ../version.h .

# copy in any pre-provisioned root cert file.

if [ -f ../osiris_root.pem ]; then
    ${CP} ../osiris_root.pem .
fi

# copy in the binaries, then strip them.

if [ -f ../../cli/osiris ]; then 
${CP} ../../cli/osiris .
${STRIP} ./osiris
fi

if [ -f ../../osirismd/osirismd ]; then
${CP} ../../osirismd/osirismd .
${STRIP} ./osirismd
fi

${CP} ../../osirisd/osirisd .
${STRIP} ./osirisd

# copy the LICENSE file.

${CP} ../../../LICENSE .

# copy in the installer script.

${CP} ../install.sh .
${CHMOD} ug+x ./install.sh

# copy configs.

${CP} -rf ../../configs .

# copy in platform specific crap.

case ${SYSTEM} in
Linux)
    ${CP} -rf ../linux .
    ;;
Darwin)
    ${CP} -rf ../darwin .
    ;;
FreeBSD)
    ${CP} -rf ../freebsd .
    ;;
NetBSD)
    ${CP} -rf ../netbsd .
    ;;
SunOS*)
    ${CP} -rf ../sunos .
    ;;
AIX*)
    ${CP} -rf ../aix .
    ;;
IRIX*)
    ${CP} -rf ../irix .
    ;;
*)
    ;;
esac


echo "installer package contents:"

ls -lA
cd ..

${TAR} cf ${PACKAGE_NAME} ${DIR_NAME}
${GZIP} ${PACKAGE_NAME}

# remove temporary directory.

${RM} -rf ${DIR_NAME}

echo "-------------------------------------------------------------------------"
echo "installer package created."
echo ""

