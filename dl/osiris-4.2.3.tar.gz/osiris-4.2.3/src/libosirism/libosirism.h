
/******************************************************************************
**
**  Copyright (C) 2006 Brian Wotring.
**
**  This program is free software; you can redistribute it and/or
**  modify it, however, you cannot sell it.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
**
**  You should have received a copy of the license attached to the
**  use of this software.  If not, view a current copy of the license
**  file here:
**
**      http://www.hostintegrity.com/osiris/LICENSE
**
******************************************************************************/

/*****************************************************************************
**
**  File:    osirism.h
**  Date:    August 18, 2002
**
**  Author:  Brian Wotring
**
**  Purpose: master include file for this library.
**
*****************************************************************************/


#ifndef LIBOSIRISM_H
#define LIBOSIRISM_H

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include <sys/types.h>
#include "utilities.h"

#include "list.h"
#include "string_list.h"

#include "scan_record.h"

#include "filter.h"
#include "configuration.h"

#include "log_brief.h"
#include "host_brief.h"
#include "config_brief.h"
#include "database_brief.h"

#include "host_config.h"
#include "management_config.h"

#include "cmp_filter.h"

#endif

