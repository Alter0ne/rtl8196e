
/* version_string 4.2.3-release */

#define OSIRIS_VERSION    "4.2.3-release"

