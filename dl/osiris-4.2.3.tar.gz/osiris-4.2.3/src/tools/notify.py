#!/usr/bin/python

import sys

f = open( 'osiris.log', 'a' )

while 1:
    try:
        line = sys.stdin.readline()

        # no more data.

        if not line:
            break

        f.write ("%s" % line )
        f.flush()

    except:
        print "error reading data."

f.close()
