
/******************************************************************************
**
**  Copyright (C) 2006 Brian Wotring.
**
**  This program is free software; you can redistribute it and/or
**  modify it, however, you cannot sell it.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
**
**  You should have received a copy of the license attached to the
**  use of this software.  If not, view a current copy of the license
**  file here:
**
**      http://www.hostintegrity.com/osiris/LICENSE
**
******************************************************************************/

/*****************************************************************************
**
**  File:    md_filter.h
**  Date:    September 17, 2003
**
**  Author:  Brian Wotring
**  Purpose: handle comparison filter operations.
**
******************************************************************************/

#ifndef MD_FILTER_H_
#define MD_FILTER_H_

osi_bool md_filter_create_database( const char *filter_db_path );

osi_bool md_filter_open_database( OSI_DB *filter_db );
osi_bool md_filter_close_database( OSI_DB *filter_db );

osi_bool md_filter_pattern( OSI_DB *filter_db, const char *pattern );

osi_bool md_filter_create_file( const char *filter_file_path );

#endif
