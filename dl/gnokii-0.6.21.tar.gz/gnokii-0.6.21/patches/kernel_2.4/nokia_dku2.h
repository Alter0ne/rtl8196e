/*
 *  Nokia DKU2 USB driver
 *
 *  Copyright (C) 2004
 *  Author: C Kemp
 *
 *  This program is largely derived from work by the linux-usb group
 *  and associated source files.  Please see the usb/serial files for
 *  individual credits and copyrights.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 */

#define NOKIA_VENDOR_ID		0x0421

#define NOKIA7600_PRODUCT_ID	0x0400
#define NOKIA6650_PRODUCT_ID	0x0401
#define NOKIA6255_PRODUCT_ID	0x0402
#define NOKIA6651_PRODUCT_ID	0x040E
#define NOKIA6230_PRODUCT_ID	0x040F
#define NOKIA6170_PRODUCT_ID	0x0416
#define NOKIA7270_PRODUCT_ID	0x0417
#define NOKIA7710_PRODUCT_ID	0x041C
#define NOKIA3230_PRODUCT_ID	0x0421
#define NOKIA6230i_PRODUCT_ID	0x0428
#define NOKIA6265_PRODUCT_ID	0x0437
#define NOKIAN70_PRODUCT_ID	0x043a
#define NOKIA6155_PRODUCT_ID	0x043c

#define NOKIA_AT_PORT	0x82
#define NOKIA_FBUS_PORT	0x86
#define NOKIA_AT_PORT2	0x87
