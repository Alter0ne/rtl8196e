extern int rotate_flag;
extern char target_logname[160];
extern char current_logfile[160];
extern char graphing_logfile[160];
