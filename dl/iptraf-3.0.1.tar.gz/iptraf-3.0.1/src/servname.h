/***

servname.h - function prototype for service lookup

***/

void servlook(int servnames,
              unsigned int port,
              unsigned int protocol, char *target, int maxlen);
