struct ifstat_brackets {
    unsigned int floor;
    unsigned int ceil;
    unsigned long count;
};
