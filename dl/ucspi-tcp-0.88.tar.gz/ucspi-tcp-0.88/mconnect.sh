exec HOME/bin/tcpclient -RHl0 -- "${1-0}" "${2-25}" HOME/bin/mconnect-io
