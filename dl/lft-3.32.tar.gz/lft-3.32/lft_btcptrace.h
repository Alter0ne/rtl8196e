#ifndef LFT_BTCPTRACE_H
#define LFT_BTCPTRACE_H

#include "lft_lib.h"

void tcp_base_trace_main_loop(lft_session_params * sess, LFT_CALLBACK err, LFT_CALLBACK evt);

#endif
