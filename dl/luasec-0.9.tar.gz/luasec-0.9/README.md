LuaSec 0.9
===============
LuaSec depends  on OpenSSL, and  integrates with LuaSocket to  make it
easy to add secure connections to any Lua applications or scripts.

Documentation: https://github.com/brunoos/luasec/wiki
