/* 
 *  $Id$
 * 
 *  This file is part of iptables-snmp - using SNMP to read data from linux
 *  iptables
 * 
 *  iptables-snmp is copyrighted software: 
 *	(c) 2003 by Peter Stamfest <peter@stamfest.at>
 * 
 *  iptables-snmp is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  iptables-snmp is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with iptables-snmp; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Note: See the file COPYING for the GNU General Public License and some
 *  extensions to it designed to protect the OID space of Peter Stamfest from
 *  becoming polluted. 
 */
#ifndef IPTABLES_SNMP_H_INCLUDED
#define IPTABLES_SNMP_H_INCLUDED

/* init function */
void init_iptables(void);

#define STAMFEST_OID		1,3,6,1,4,1,12806

/* USE_ENTERPRISE_OID may get passed on the commandline (-D) */
#ifndef USE_ENTERPRISE_OID
#  define USE_ENTERPRISE_OID	STAMFEST_OID
#endif

#define BASE_OID		USE_ENTERPRISE_OID,6,1

#define AGENT_VERSION_INDEX	1
#define IPTABLES_VERSION_INDEX	2

/* the chains table */

#define C_CHAIN_INDEX		1
#define C_TABLE_INDEX		2
#define C_CHAIN_NAME		3
#define C_TABLE_NAME		4
#define C_CHAIN_POLICY		5
#define C_CHAIN_OCTETS		6
#define C_CHAIN_PACKETS		7

/* the rules table */

#define R_RULE_INDEX		1
#define R_CHAIN_INDEX		2
#define R_TABLE_INDEX		3
#define R_CHAIN_NAME_INDEX	4
#define R_TABLE_NAME_INDEX	5
#define R_OCTETS_INDEX		6
#define R_PACKETS_INDEX		7
#define R_RULE_SHORT_INDEX	8
#define R_SRC_IPADDR_INDEX	9
#define R_SRC_MASK_INDEX	10
#define R_DST_IPADDR_INDEX	11
#define R_DST_MASK_INDEX	12

#define R_MAX			12

#endif /* IPTABLES_SNMP_H_INCLUDED */
