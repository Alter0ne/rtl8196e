/* 
 *  $Id$
 * 
 *  This file is part of iptables-snmp - using SNMP to read data from linux
 *  iptables
 * 
 *  iptables-snmp is copyrighted software: 
 *	(c) 2003 by Peter Stamfest <peter@stamfest.at>
 *      (c) 2005 by Nigel Roberts <nigel@nobiscuit.com>
 * 
 *  iptables-snmp is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  iptables-snmp is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with iptables-snmp; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Note: See the file COPYING for the GNU General Public License and some
 *  extensions to it designed to protect the OID space of Peter Stamfest from
 *  becoming polluted. 
 */

#include <errno.h>
#include <arpa/inet.h>

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include "iptables-snmp.h"

#include "libiptc/libiptc.h"

static oid agent_version_oid[] = {
    BASE_OID, 1, 0, AGENT_VERSION_INDEX
};
static oid iptables_version_oid[] = {
    BASE_OID, 1, 0, IPTABLES_VERSION_INDEX
};
static oid iptables_names_oid[] = {
    BASE_OID, 1, 1
};
static oid iptables_chains_oid[] = {
    BASE_OID, 1, 2
};
static oid iptables_rules_oid[] = {
    BASE_OID, 1, 3
};

static Netsnmp_Node_Handler iptables_names_handler;

#define PROCFILE "/proc/net/ip_tables_names"
#define MAXTIME 1

typedef struct _iptables_data {
    time_t loaded;
    char **tables;
    iptc_handle_t *t;
} iptables_data;

/* char *xx[2] = { "filter", NULL } ; */
/* iptc_handle_t tt[2] = { NULL, NULL }; */

static iptables_data ipt = { 0, NULL };
/* static iptables_data ipt = { 0, xx, tt }; */


static void free_data(iptables_data *data) {
    if (!data) return;
    if (data->tables) {
	int i;

	for (i = 0 ; data->tables[i] ; i++) {
	    free(data->tables[i]);
	    
	    if (data->t[i] != NULL) {
	      iptc_free(&(data->t[i]));
	    }
	}
	free(data->tables);
	free(data->t);
	data->tables = NULL;
	data->t = NULL;
    }
    data->loaded = 0; /* just to make sure */
}


static iptables_data *get_data() {
    time_t now = time(NULL);
    FILE *fp;
    int N = 0, num = 0;
    char line[1024];
    char **c;
    iptc_handle_t *t;

/*     if (tt[0]) free(tt[0]); */
/*     tt[0] = iptc_init(xx[0]); */

/*     return &ipt; */

    if (now - ipt.loaded < MAXTIME && ipt.tables) {
	return &ipt;
    }
    free_data(&ipt);

    fp = fopen(PROCFILE, "r");
    
    if (fp == NULL) {
	/** error - bail out */
	snmp_log(LOG_ERR,
		 "Cannot open iptables table file %s: %s",  
		 PROCFILE, strerror(errno));
	return NULL;
    }


    while (fgets(line, sizeof(line), fp)) {
	int n = strlen(line);
	if (n == 0) continue;
	if (line[n-1] == '\n') line[n-1] = 0;
	
	if (num >= N - 2) {
	    N += 10;
	    ipt.tables = realloc(ipt.tables, N * sizeof(char*));
	    if (ipt.tables == NULL) {
		snmp_log(LOG_ERR,
			 "Cannot allocate memory: %s", strerror(errno));
		goto done;
	    }
	}
	ipt.tables[num] = strdup(line);
	if (ipt.tables[num] == NULL) {
	    snmp_log(LOG_ERR,
		     "Cannot allocate memory: %s", strerror(errno));
	    goto done;
	}
	num++;
	ipt.tables[num] = NULL;
    }

    ipt.loaded = now;

    ipt.t = (iptc_handle_t*)calloc(N, sizeof(iptc_handle_t));
    for (c = ipt.tables, t = ipt.t ; *c ; c++, t++) {
      *t = iptc_init(*c);
      if (*t == NULL) {
	snmp_log(LOG_ERR,
		 "Could not init iptables, insufficient privileges?");
	free_data(&ipt);
	fclose(fp);
	return NULL;
      }
    }
    
 done:
    fclose(fp);

    return &ipt;
}



/* static void get_tables() { */

/* } */

struct tables_iter {
    int i;
    iptables_data *ctx;
};



static netsnmp_variable_list *
store_names(void **my_loop_context, void **my_data_context,
	    netsnmp_variable_list * put_index_data,
	    netsnmp_iterator_info *iinfo)
{
    struct tables_iter *ti = (struct tables_iter *) *my_loop_context;
    iptables_data *data = (iptables_data *) ti->ctx;
/*     char **tables = (char**) *my_data_context; */
    netsnmp_variable_list *vars;


    if (data == NULL || 
	data->tables == NULL || 
	data->tables[ti->i] == NULL) return NULL;

/*     printf("store %d\n", ti->i); */
    
    vars = put_index_data;
    snmp_set_var_typed_value(vars, ASN_INTEGER,
			     (void*)&(ti->i), sizeof(ti->i));

    *my_data_context = data;
    
    return vars;
}


/** returns the first data point within the table data.

    Set the my_loop_context variable to the first data point structure
    of your choice (from which you can find the next one).  This could
    be anything from the first node in a linked list, to an integer
    pointer containing the beginning of an array variable.

    Set the my_data_context variable to something to be returned to
    you later that will provide you with the data to return in a given
    row.  This could be the same pointer as what my_loop_context is
    set to, or something different.

    The put_index_data variable contains a list of snmp variable
    bindings, one for each index in your table.  Set the values of
    each appropriately according to the data matching the first row
    and return the put_index_data variable at the end of the function.
*/

static netsnmp_variable_list *
get_first_names(void **my_loop_context, void **my_data_context,
		netsnmp_variable_list * put_index_data,
		netsnmp_iterator_info *iinfo)
{
    struct tables_iter *ti;

    ti = malloc(sizeof(struct tables_iter));
    if (ti == NULL) {
	snmp_log(LOG_ERR, "Cannot allocate memory\n");
	return NULL;
    }
    ti->i = 0;
    ti->ctx = get_data();

    *my_loop_context = ti;

    return store_names(my_loop_context, my_data_context,
		       put_index_data, iinfo);
}

/** functionally the same as get_first_data_point, but
   my_loop_context has already been set to a previous value and should
   be updated to the next in the list.  For example, if it was a
   linked list, you might want to cast it and the return
   my_loop_context->next.  The my_data_context pointer should be set
   to something you need later and the indexes in put_index_data
   updated again. */
static netsnmp_variable_list *
get_next_names(void **my_loop_context,
	       void **my_data_context,
	       netsnmp_variable_list *put_index_data,
	       netsnmp_iterator_info *iinfo)
{   
    struct tables_iter *ti = *my_loop_context;

    if (!my_loop_context || !*my_loop_context)
        return NULL;

    (ti->i)++;
    return store_names(my_loop_context, my_data_context,
		       put_index_data, iinfo);
}


static void free_loop_context_at_end(void *my_loop_context, 
				     netsnmp_iterator_info *iinfo)
{
    if (my_loop_context) free(my_loop_context);
/*     printf("free_loop_context_at_end\n"); */
}


static int
iptables_names_handler(netsnmp_mib_handler *handler,
		       netsnmp_handler_registration *reginfo,
		       netsnmp_agent_request_info *reqinfo,
		       netsnmp_request_info *requests)
{
    netsnmp_table_request_info *table_info;
    netsnmp_request_info *request;
    int index = 0;
    iptables_data *ctx;


    for (request = requests; request; request = request->next) {
        netsnmp_variable_list *var = request->requestvb;
        table_info = netsnmp_extract_table_info(request);

        if (request->processed != 0)
            continue;

        switch (reqinfo->mode) {
        case MODE_GET:
 	    ctx = (iptables_data *) netsnmp_extract_iterator_context(request);
	    index = var->name[var->name_length - 1];

            switch (table_info->colnum) {
            case 1: {
		snmp_set_var_typed_value(var, ASN_INTEGER,
					 (void*) &index, sizeof(index));
                break;
	    }
            case 2: {
		snmp_set_var_typed_value(var, ASN_OCTET_STR,
					 (unsigned char *)ctx->tables[index], 
					 strlen(ctx->tables[index]));
                break;
	    }
            default:
                /* We shouldn't get here */
                snmp_log(LOG_ERR,
                         "problem encountered in iptables_handler: unknown column %d\n", table_info->colnum);
            }

            break;

        default:
            /*
             * We should never get here, getnext already have been
             * handled by the table_iterator and we're read_only 
             */
            snmp_log(LOG_ERR,
                     "table accessed as mode=%d.  We're improperly registered!",
                     reqinfo->mode);
            break;
        }
    }

    return SNMP_ERR_NOERROR;
}

/* chains table */







typedef struct _chains_iter {
    int table;
    int chain;

    iptables_data *ctx;
    const char *chainname;
} chains_iter;

typedef struct _chains_data {
    iptables_data *ctx;
} chains_data;

static netsnmp_variable_list *
store_chains(void **my_loop_context,
	     void **my_data_context,
	     netsnmp_variable_list *put_index_data,
	     netsnmp_iterator_info *iinfo,
	     int incr)
{    
    chains_iter *c = (chains_iter *) *my_loop_context;
    netsnmp_variable_list *var = put_index_data;

    if (c->ctx == NULL) return NULL;

    if (c->ctx->tables[c->table] == NULL) return NULL;

    /* next chain */
    do {
	if (c->chainname == NULL) {
	    /* next table */
	    c->table++;
	    if (c->ctx->tables[c->table] == NULL) return NULL;
	    
	    c->chainname = iptc_first_chain(&(c->ctx->t[c->table]));
	    c->chain = 0;
	} else {
	    c->chainname = iptc_next_chain(&(c->ctx->t[c->table]));
	    c->chain++;
	}
    } while (c->chainname == NULL);

    /* redundant */
    if (c->ctx->tables[c->table] == NULL) return NULL;

    snmp_set_var_typed_value(var, ASN_INTEGER,
			     (void*)&(c->table), sizeof(c->table));

    var = var->next_variable;
    snmp_set_var_typed_value(var, ASN_INTEGER,
			     (void*)&(c->chain), sizeof(c->table));


    return put_index_data;
}

void *
chains_make_data_context(void *loop_context,
			 netsnmp_iterator_info *iinfo)
{
  chains_iter *c = loop_context;
  chains_data *data = SNMP_MALLOC_TYPEDEF(chains_data);
  if (data == NULL) {
    snmp_log(LOG_ERR, "Cannot allocate memory\n");
    return NULL;
  }
  data->ctx = c->ctx;
  return data;
}

static netsnmp_variable_list *
chains_get_first_names(void **my_loop_context, void **my_data_context,
		       netsnmp_variable_list * put_index_data,
		       netsnmp_iterator_info *iinfo)
{
    chains_iter *c = (chains_iter *) malloc(sizeof(chains_iter));
    if (c == NULL) {
	snmp_log(LOG_ERR,
		 "Cannot allocate memory: %s", strerror(errno));
	return NULL;
    }
    c->ctx = get_data();
    c->table = c->chain = -1;
    c->chainname = NULL;

    *my_loop_context = c;
    *my_data_context = NULL;

    return store_chains(my_loop_context, my_data_context,
			put_index_data, iinfo, 0);
}

/** functionally the same as get_first_data_point, but
   my_loop_context has already been set to a previous value and should
   be updated to the next in the list.  For example, if it was a
   linked list, you might want to cast it and the return
   my_loop_context->next.  The my_data_context pointer should be set
   to something you need later and the indexes in put_index_data
   updated again. */
static netsnmp_variable_list *
chains_get_next_names(void **my_loop_context,
		      void **my_data_context,
		      netsnmp_variable_list *put_index_data,
		      netsnmp_iterator_info *iinfo)
{   
    return store_chains(my_loop_context, my_data_context,
			put_index_data, iinfo, 1);
}

static void chains_free_loop_context_at_end(void *my_loop_context, 
					    netsnmp_iterator_info *iinfo)
{
    if (my_loop_context) free(my_loop_context);
}

static void chains_free_data_context(void *my_data_context, 
				     netsnmp_iterator_info *iinfo)
{
    if (my_data_context) free(my_data_context);
}

static int
iptables_chains_handler(netsnmp_mib_handler *handler,
			netsnmp_handler_registration *reginfo,
			netsnmp_agent_request_info *reqinfo,
			netsnmp_request_info *requests)
{
    netsnmp_table_request_info *table_info;
    netsnmp_request_info *request;
/*     char **ctx; */
/*     int index; */

    int table, chain;
/*     char buf[50]; */
    iptables_data *ctx;
    chains_data *data;

    for (request = requests ; request ; request = request->next) {
        netsnmp_variable_list *var = request->requestvb;
        table_info = netsnmp_extract_table_info(request);

        if (request->processed != 0)
	  continue;

	data = (chains_data *) netsnmp_extract_iterator_context(request);

	if (data == NULL) 
	  continue;

	ctx = data->ctx;

	chain = var->name[var->name_length - 1];
	table = var->name[var->name_length - 2];
	
/* 	sprintf(buf, "%d_%d_%d", table, chain, rule); */
/* 	snmp_set_var_typed_value(var, ASN_OCTET_STR, buf, strlen(buf)); */

	
        switch (reqinfo->mode) {
        case MODE_GET:
            switch (table_info->colnum) {
            case C_CHAIN_INDEX: {
		snmp_set_var_typed_value(var, ASN_INTEGER,
					 (void*) &chain, sizeof(chain));
                break;
	    }
            case C_TABLE_INDEX: {
		snmp_set_var_typed_value(var, ASN_INTEGER,
					 (void*) &table, sizeof(table));
                break;
	    }
            case C_CHAIN_NAME:
            case C_CHAIN_POLICY: 
            case C_CHAIN_OCTETS: 
            case C_CHAIN_PACKETS: { /* bad style follows ... */
		
		const char *cn;
		int i;
		for (cn = iptc_first_chain(&(ctx->t[table])), i=0 ; cn ;
		     cn = iptc_next_chain(&(ctx->t[table])), i++) {
		    if (i == chain) {
			if (table_info->colnum == C_CHAIN_NAME) {
			    snmp_set_var_typed_value(var, ASN_OCTET_STR,
						     (unsigned char *) cn, 
						     strlen(cn));
			} else {
			    struct counter64 c64;
			    struct ipt_counters cnt;
			    unsigned int isbuiltin = 1;
			    
			    const char *pol = 
			      iptc_get_policy(cn, &cnt, &(ctx->t[table]));
			    
			    if (!pol) {
			      isbuiltin = 0;
			    }

			    switch (table_info->colnum) {
			    case C_CHAIN_POLICY:
			        if (!pol) {
 			          // this is not a built in chain, there is no policy
				  break;
				}
			        snmp_set_var_typed_value(var, ASN_OCTET_STR,
							 (unsigned char *) pol, 
							 strlen(pol));
				break;
			    case C_CHAIN_OCTETS:
			        if (isbuiltin) {
                                  // this is a built in chain, display
                                  // counter
				  
				  c64.low = 0xffffffff & cnt.bcnt;
				  c64.high = 0xffffffff & (cnt.bcnt >> 32);
  				  snmp_set_var_typed_value(var, ASN_COUNTER64,
					  		   (void*) &(c64),
						  	   sizeof(c64));
				  
				}
				break;
			    case C_CHAIN_PACKETS:
			        if (isbuiltin) {
                                    // this is a built in chain, display
                                    // counter
				  
				  c64.low = 0xffffffff & cnt.pcnt;
				  c64.high = 0xffffffff & (cnt.pcnt >> 32);
				  snmp_set_var_typed_value(var, ASN_COUNTER64,
							   (void*) &(c64),
							   sizeof(c64));

				}
				break;
			    }
			}
			break;
		    }
		}
                break;
	    }
	    case C_TABLE_NAME: 
		snmp_set_var_typed_value(var, ASN_OCTET_STR,
					 (unsigned char *) ctx->tables[table], 
					 strlen(ctx->tables[table])); 
		break;
            default:
                /* We shouldn't get here */
                snmp_log(LOG_ERR,
                         "problem encountered in iptables_chains_handler: unknown column %d\n", table_info->colnum);
            }

            break;

        default:
            /*
             * We should never get here, getnext already have been
             * handled by the table_iterator and we're read_only 
             */
            snmp_log(LOG_ERR,
                     "table accessed as mode=%d.  We're improperly registered!",
                     reqinfo->mode);
            break;
	}

        if (request->processed != 0)
            continue;
    }

    return SNMP_ERR_NOERROR;
}

/* rules table */

typedef struct _rules_iter {
    int table;
    int chain;
    int rule;

    iptables_data *ctx;
    const char *chainname;
    const struct ipt_entry *e;
} rules_iter;

typedef struct _rules_data {
    iptables_data *ctx;
    const struct ipt_entry *e;
} rules_data;

static netsnmp_variable_list *
store_rules(void **my_loop_context,
	     void **my_data_context,
	     netsnmp_variable_list *put_index_data,
	     netsnmp_iterator_info *iinfo,
	     int incr)
{    
    rules_iter *c = (rules_iter *) *my_loop_context;
    netsnmp_variable_list *var = put_index_data;

    if (c->ctx == NULL) return NULL;
    if (c->ctx->tables[c->table] == NULL) return NULL;

    do {
	if (c->e == NULL) {
	    /* next chain */
	    do {
		if (c->chainname == NULL) {
		    /* next table */
		    c->table++;
		    if (c->ctx->tables[c->table] == NULL) return NULL;

		    c->chainname = iptc_first_chain(&(c->ctx->t[c->table]));
		    c->chain = 0;
		} else {
		    c->chainname = iptc_next_chain(&(c->ctx->t[c->table]));
		    c->chain++;
		}
	    } while (c->chainname == NULL);

	    c->e = iptc_first_rule(c->chainname, &(c->ctx->t[c->table]));
	    c->rule = 0;
	} else {
	    c->e = iptc_next_rule(c->e, &(c->ctx->t[c->table]));
	    c->rule++;
	}
    } while (c->e == NULL);

    /* redundant */
    if (c->ctx->tables[c->table] == NULL) return NULL;

    snmp_set_var_typed_value(var, ASN_INTEGER,
			     (void*)&(c->table), sizeof(c->table));

    var = var->next_variable;
    snmp_set_var_typed_value(var, ASN_INTEGER,
			     (void*)&(c->chain), sizeof(c->table));

    var = var->next_variable;
    snmp_set_var_typed_value(var, ASN_INTEGER,
			     (void*)&(c->rule), sizeof(c->rule));

    return put_index_data;

}

void *
rules_make_data_context(void *loop_context,
			netsnmp_iterator_info *iinfo)
{
  rules_iter *c = loop_context;
  rules_data *data = SNMP_MALLOC_TYPEDEF(rules_data);
  if (data == NULL) {
    snmp_log(LOG_ERR, "Cannot allocate memory\n");
    return NULL;
  }
  data->ctx = c->ctx;
  data->e = c->e;
  return data;
}

static netsnmp_variable_list *
rules_get_first_names(void **my_loop_context, void **my_data_context,
		       netsnmp_variable_list * put_index_data,
		       netsnmp_iterator_info *iinfo)
{
    rules_iter *c = (rules_iter *) malloc(sizeof(rules_iter));
    if (c == NULL) {
	snmp_log(LOG_ERR,
		 "Cannot allocate memory");
	return NULL;
    }

    c->ctx = get_data();
    c->table = c->chain = c->rule = -1;
    c->chainname = NULL;
    c->e = NULL;

    *my_loop_context = c;
    *my_data_context = NULL;

    return store_rules(my_loop_context, my_data_context,
			put_index_data, iinfo, 0);
}

/** functionally the same as get_first_data_point, but
   my_loop_context has already been set to a previous value and should
   be updated to the next in the list.  For example, if it was a
   linked list, you might want to cast it and the return
   my_loop_context->next.  The my_data_context pointer should be set
   to something you need later and the indexes in put_index_data
   updated again. */
static netsnmp_variable_list *
rules_get_next_names(void **my_loop_context,
		      void **my_data_context,
		      netsnmp_variable_list *put_index_data,
		      netsnmp_iterator_info *iinfo)
{   
/*     rules_iter *c = (rules_iter *) *my_loop_context; */

/*     c->chain++; */
/*     if (c->chain >= 2 * c->table) { */
/* 	c->table++; */
/* 	c->chain = 1; */
/*     } */
/*     if (c->table == 4) return NULL; */

    return store_rules(my_loop_context, my_data_context,
			put_index_data, iinfo, 1);
}

static void rules_free_loop_context_at_end(void *my_loop_context, 
					    netsnmp_iterator_info *iinfo)
{
    if (my_loop_context) free(my_loop_context);
}

static void rules_free_data_context(void *my_data_context, 
				     netsnmp_iterator_info *iinfo)
{
    if (my_data_context) free(my_data_context);
/*     printf("free  data_context %08lx\n", (long) my_data_context); */
}


static int short_ip(const char *prefix,
		    u_int32_t ip, u_int32_t mask,
		    int inv,
		    char *buf, int sz)
{
    int n = sz;
    int i;


    if (!ip && !mask) {
	return 0;
    }

    i = snprintf(buf, n, ";%s=%s", prefix, inv ? "!" : "");
    n -= i;
    if (n <= 0) return sz;
    buf += i;
    
    inet_ntop(AF_INET, &ip, buf, n);
    i = strlen(buf);
    n -= i;
    if (n <= 0) return sz;
    buf += i;

    mask = ntohl(mask);
    if (mask != 0xffffffffUL) {
	int b = 32;
	mask = ~mask;
	while (mask & 1) {
	    b--;
	    mask /= 2; 
	}

	i = snprintf(buf, n, "/%d", b);
	n -= i;
	if (n <= 0) return sz;
	buf += i;
    }
    
    return sz - n;
}

static int
iptables_rules_handler(netsnmp_mib_handler *handler,
		       netsnmp_handler_registration *reginfo,
		       netsnmp_agent_request_info *reqinfo,
		       netsnmp_request_info *requests)
{
    netsnmp_table_request_info *table_info;
    netsnmp_request_info *request;
/*     char **ctx; */
/*     int index; */

    int table, chain, rule;
/*     char buf[50]; */
    iptables_data *ctx;
    rules_data *data;

    for (request = requests ; request ; request = request->next) {
        netsnmp_variable_list *var = request->requestvb;
        table_info = netsnmp_extract_table_info(request);

        if (request->processed != 0)
	  continue;
	
	data = (rules_data *) netsnmp_extract_iterator_context(request);
	
	if (data == NULL || data->ctx == NULL) continue;
	
	ctx = data->ctx;

	rule  = var->name[var->name_length - 1];
	chain = var->name[var->name_length - 2];
	table = var->name[var->name_length - 3];
	
/* 	sprintf(buf, "%d_%d_%d\n", table, chain, rule); */
/* 	snmp_set_var_typed_value(var, ASN_OCTET_STR, buf, strlen(buf)); */

	
        switch (reqinfo->mode) {
        case MODE_GET:
            switch (table_info->colnum) {
            case R_RULE_INDEX: {
		snmp_set_var_typed_value(var, ASN_INTEGER,
					 (void*) &rule, sizeof(rule));
                break;
	    }
            case R_CHAIN_INDEX: {
		snmp_set_var_typed_value(var, ASN_INTEGER,
					 (void*) &chain, sizeof(chain));
                break;
	    }
            case R_TABLE_INDEX: {
		snmp_set_var_typed_value(var, ASN_INTEGER,
					 (void*) &table, sizeof(table));
                break;
	    }
            case R_CHAIN_NAME_INDEX: {
		const char *cn;
		int i;
		for (cn = iptc_first_chain(&(ctx->t[table])), i=0 ; cn ;
		     cn = iptc_next_chain(&(ctx->t[table])), i++) {
		    if (i == chain) {
			snmp_set_var_typed_value(var, ASN_OCTET_STR,
						 (unsigned char *) cn, 
						 strlen(cn));
			break;
		    }
		}
                break;
	    }
            case R_TABLE_NAME_INDEX: {
		snmp_set_var_typed_value(var, ASN_OCTET_STR,
					 (unsigned char *) ctx->tables[table], 
					 strlen(ctx->tables[table]));
                break;
	    }
	    case R_OCTETS_INDEX: 
	    case R_PACKETS_INDEX: {
		const char *cn;
		int i;

		for (cn = iptc_first_chain(&(ctx->t[table])), i=0 ; cn ;
		     cn = iptc_next_chain(&(ctx->t[table])), i++) {
/* 		    printf("%d %d\n", i, chain); */
		    if (i == chain) {
			struct ipt_counters *cnt = 
			  iptc_read_counter(cn, rule+1, &(ctx->t[table]));
			struct counter64 c64;


/* 			snmp_set_var_typed_value(var, ASN_INTEGER64, */
/* 						 (void*) &(cnt->bcnt),  */
/* 						 sizeof(cnt->bcnt)); */

		    /* cnt->bcnt is a u_int64_t variable, but
		       ASN_COUNTER64 awaits a struct counter64: */
			
			if (table_info->colnum == R_OCTETS_INDEX) {
			    c64.low = 0xffffffff & cnt->bcnt;
			    c64.high = 0xffffffff & (cnt->bcnt >> 32);
			} else {
			    c64.low = 0xffffffff & cnt->pcnt;
			    c64.high = 0xffffffff & (cnt->pcnt >> 32);
			}

			snmp_set_var_typed_value(var, ASN_COUNTER64,
						 (void*) &(c64),
						 sizeof(c64));

			break;
		    }
		}
                break;
	    }
	    case R_RULE_SHORT_INDEX: {
		char buf[512] = "";
		int n = sizeof(buf);
		int i;
		const struct ipt_entry *e = data->e;
		const char *target_name;

		if (data->e->ip.proto) {
		    i = snprintf(buf + sizeof(buf) - n, n,
				 ";p=%s%d", 
				 data->e->ip.invflags & IPT_INV_PROTO ? "!":"",
				 data->e->ip.proto);
		    n -= i;
		} 


		i = short_ip("s", e->ip.src.s_addr, e->ip.smsk.s_addr,
			     e->ip.invflags & IPT_INV_SRCIP,
			     buf + sizeof(buf) - n, n);
		n -= i;

		i = short_ip("d", e->ip.dst.s_addr, e->ip.dmsk.s_addr,
			     e->ip.invflags & IPT_INV_DSTIP,
			     buf + sizeof(buf) - n, n);
		n -= i;

		/* Print target name */ 
		target_name = iptc_get_target(e, &(ctx->t[table]));

		if (target_name && *target_name) {
		    i = snprintf(buf + sizeof(buf) - n, n,
				 ";j=%s", target_name); 
		    n -= i;
		}



		
		snmp_set_var_typed_value(var, ASN_OCTET_STR,
					 (unsigned char *) buf, strlen(buf));
		break;
	    }
	    case R_SRC_IPADDR_INDEX:
		snmp_set_var_typed_value(var, ASN_IPADDRESS,
					 (void*) &(data->e->ip.src.s_addr), 
					 sizeof(data->e->ip.src.s_addr));
		break;
	    case R_SRC_MASK_INDEX:
		snmp_set_var_typed_value(var, ASN_IPADDRESS,
					 (void*) &(data->e->ip.smsk.s_addr), 
					 sizeof(data->e->ip.smsk.s_addr));
		break;
	    case R_DST_IPADDR_INDEX:
		snmp_set_var_typed_value(var, ASN_IPADDRESS,
					 (void*) &(data->e->ip.dst.s_addr), 
					 sizeof(data->e->ip.dst.s_addr));
		break;
	    case R_DST_MASK_INDEX:
		snmp_set_var_typed_value(var, ASN_IPADDRESS,
					 (void*) &(data->e->ip.dmsk.s_addr), 
					 sizeof(data->e->ip.dmsk.s_addr));
		break;
            default:
                /* We shouldn't get here */
                snmp_log(LOG_ERR,
                         "problem encountered in iptables_handler: unknown column %d\n", table_info->colnum);
            }

            break;

        default:
            /*
             * We should never get here, getnext already have been
             * handled by the table_iterator and we're read_only 
             */
            snmp_log(LOG_ERR,
                     "table accessed as mode=%d.  We're improperly registered!",
                     reqinfo->mode);
            break;
	}

        if (request->processed != 0)
            continue;
    }

    return SNMP_ERR_NOERROR;
}









static int
info_handler(netsnmp_mib_handler *handler,
	     netsnmp_handler_registration *reginfo,
	     netsnmp_agent_request_info *reqinfo,
	     netsnmp_request_info *requests)
{
    netsnmp_request_info *request;

    for (request = requests ; request ; request = request->next) {
        netsnmp_variable_list *var = request->requestvb;
	int index = var->name[var->name_length - 1];

        if (request->processed != 0)
            continue;

        switch (reqinfo->mode) {
        case MODE_GET:
	    switch (index) {
	    case AGENT_VERSION_INDEX:
		snmp_set_var_typed_value(var, ASN_OCTET_STR,
					 (unsigned char *) AGENT_VERSION, 
					 strlen(AGENT_VERSION));
		break;
	    case IPTABLES_VERSION_INDEX:
		snmp_set_var_typed_value(var, ASN_OCTET_STR,
					 (unsigned char *) IPTABLES_VERSION, 
					 strlen(IPTABLES_VERSION));
		break;
	    }
	    break;
        default:
            /*
             * We should never get here, getnext already have been
             * handled by the table_iterator and we're read_only 
             */
            snmp_log(LOG_ERR,
                     "variable accessed as mode=%d. We're improperly registered!",
                     reqinfo->mode);
            break;
        }
    }
    return SNMP_ERR_NOERROR;
}

/** Initializes the iptableNamesEntry module */
void
init_iptables(void)
{
    /*
     * here we initialize all the tables we're planning on supporting 
     */
    netsnmp_handler_registration *my_handler;
    netsnmp_table_registration_info *table_info;
    netsnmp_iterator_info *iinfo;

    my_handler = 
	netsnmp_create_handler_registration("agent_version",
					    info_handler,
					    agent_version_oid,
					    OID_LENGTH(agent_version_oid),
					    HANDLER_CAN_RONLY);

    if (!my_handler)
        return;

    netsnmp_register_read_only_instance(my_handler);

    my_handler = 
	netsnmp_create_handler_registration("agent_version",
					    info_handler,
					    iptables_version_oid,
					    OID_LENGTH(iptables_version_oid),
					    HANDLER_CAN_RONLY);

    if (!my_handler)
        return;

    netsnmp_register_read_only_instance(my_handler);




    /** */

    my_handler = netsnmp_create_handler_registration("iptables_names",
                                                     iptables_names_handler,
                                                     iptables_names_oid,
                                                     sizeof
                                                     (iptables_names_oid) /
                                                     sizeof(oid),
                                                     HANDLER_CAN_RONLY);

    if (!my_handler)
        return;

    table_info = SNMP_MALLOC_TYPEDEF(netsnmp_table_registration_info);
    iinfo = SNMP_MALLOC_TYPEDEF(netsnmp_iterator_info);

    if (!table_info || !iinfo) {
	snmp_log(LOG_ERR,
		 "problem registring handler: cannot allocate memory\n");
        return;
    }

    netsnmp_table_helper_add_index(table_info, ASN_INTEGER);

    table_info->min_column = 1;
    table_info->max_column = 2;
    iinfo->get_first_data_point = get_first_names;
    iinfo->get_next_data_point  = get_next_names;
    iinfo->free_loop_context_at_end = free_loop_context_at_end;
    iinfo->table_reginfo = table_info;
    netsnmp_register_table_iterator(my_handler, iinfo);

    /** chains table */

    my_handler = 
	netsnmp_create_handler_registration("iptables_chains",
					    iptables_chains_handler,
					    iptables_chains_oid,
					    OID_LENGTH(iptables_chains_oid),
					    HANDLER_CAN_RONLY);
    
    if (!my_handler)
        return;

    table_info	= SNMP_MALLOC_TYPEDEF(netsnmp_table_registration_info);
    iinfo	= SNMP_MALLOC_TYPEDEF(netsnmp_iterator_info);

    if (!table_info || !iinfo) {
	snmp_log(LOG_ERR,
		 "problem registring handler: cannot allocate memory\n");
        return;
    }

    netsnmp_table_helper_add_index(table_info, ASN_INTEGER); /* table index */
    netsnmp_table_helper_add_index(table_info, ASN_INTEGER); /* chain index */

    table_info->min_column = 1;
    table_info->max_column = 7;
    iinfo->get_first_data_point = chains_get_first_names;
    iinfo->get_next_data_point  = chains_get_next_names;
    iinfo->free_loop_context_at_end = chains_free_loop_context_at_end;
    iinfo->free_data_context = chains_free_data_context;

    iinfo->table_reginfo = table_info;
    netsnmp_register_table_iterator(my_handler, iinfo);

    /** rules table */

    my_handler = 
	netsnmp_create_handler_registration("iptables_rules",
					    iptables_rules_handler,
					    iptables_rules_oid,
					    sizeof(iptables_rules_oid) / sizeof(oid),
					    HANDLER_CAN_RONLY);
    
    if (!my_handler)
        return;

    table_info	= SNMP_MALLOC_TYPEDEF(netsnmp_table_registration_info);
    iinfo	= SNMP_MALLOC_TYPEDEF(netsnmp_iterator_info);

    if (!table_info || !iinfo) {
	snmp_log(LOG_ERR,
		 "problem registring handler: cannot allocate memory\n");
        return;
    }

    netsnmp_table_helper_add_index(table_info, ASN_INTEGER); /* table index */
    netsnmp_table_helper_add_index(table_info, ASN_INTEGER); /* chain index */
    netsnmp_table_helper_add_index(table_info, ASN_INTEGER); /* rule  index */

    table_info->min_column = 1;
    table_info->max_column = R_MAX;
    iinfo->make_data_context = rules_make_data_context;
    iinfo->get_first_data_point = rules_get_first_names;
    iinfo->get_next_data_point  = rules_get_next_names;
    iinfo->free_loop_context_at_end = rules_free_loop_context_at_end;
    iinfo->free_data_context = rules_free_data_context;

    iinfo->table_reginfo = table_info;
    netsnmp_register_table_iterator(my_handler, iinfo);

}
