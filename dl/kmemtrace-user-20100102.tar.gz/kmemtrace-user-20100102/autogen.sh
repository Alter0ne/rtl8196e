#!/bin/bash

autoreconf -f -i

