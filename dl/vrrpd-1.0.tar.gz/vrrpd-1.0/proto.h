/*=========================[ (c) POIPOI SOFT ]==================================

FILE        : [protodef.h]

DATE        : 95/11/10 22:44:23

WHO         : poipoi@hwi.resi.insa-lyon.fr Linux 1.2.13

REMARK      : 

================================================================================

==============================================================================*/

#ifndef __PROTODEF_H__
#define __PROTODEF_H__
#ifndef PROTO
#if __STDC__ 
#	define PROTO(x) x
#else
#	define PROTO(x) ()
#endif
#endif

#endif	/* __PROTODEF_H__ */

