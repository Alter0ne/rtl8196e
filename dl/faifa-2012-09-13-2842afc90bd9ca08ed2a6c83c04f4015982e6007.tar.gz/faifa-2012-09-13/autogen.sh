#!/bin/sh -xe
autoheader
autoconf
rm -rf autom4te.cache
