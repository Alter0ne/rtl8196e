# =XMPP4R - XMPP Library for Ruby
# License:: Ruby's license (see the LICENSE file) or GNU GPL, at your option.
# Website::http://home.gna.org/xmpp4r/

require 'xmpp4r/version/helper/responder.rb'
require 'xmpp4r/version/helper/simpleresponder.rb'
require 'xmpp4r/version/iq/version.rb'
