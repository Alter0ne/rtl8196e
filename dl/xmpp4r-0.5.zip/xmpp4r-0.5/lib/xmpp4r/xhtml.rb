require 'xmpp4r/xhtml/html'
