require 'xmpp4r/rpc/helper/client'
require 'xmpp4r/rpc/helper/server'
