require 'xmpp4r/location/location'
require 'xmpp4r/location/helper/helper'
