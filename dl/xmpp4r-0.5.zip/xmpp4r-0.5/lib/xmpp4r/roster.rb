# =XMPP4R - XMPP Library for Ruby
# License:: Ruby's license (see the LICENSE file) or GNU GPL, at your option.
# Website::http://home.gna.org/xmpp4r/

require 'xmpp4r/roster/iq/roster.rb'
require 'xmpp4r/roster/helper/roster.rb'
require 'xmpp4r/roster/x/roster.rb'
