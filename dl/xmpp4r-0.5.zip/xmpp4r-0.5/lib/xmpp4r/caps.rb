require 'xmpp4r/caps/helper/helper'
