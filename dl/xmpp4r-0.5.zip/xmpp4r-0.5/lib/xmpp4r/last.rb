require 'xmpp4r/last/iq/last'
require 'xmpp4r/last/helper/helper'
