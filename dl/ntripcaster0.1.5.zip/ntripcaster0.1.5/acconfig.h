/* Whether to use crypted passwords */
#undef USE_CRYPT

/* Whether to use tcp_wrappers */
#undef HAVE_LIBWRAP

/* User want readline */
#undef HAVE_LIBREADLINE

/* Some systems have sys/syslog.h */
#undef NEED_SYS_SYSLOG_H

/* Any threads around? */
#undef HAVE_PTHREAD_H

/* Some systems don't have assert.h */
#undef HAVE_ASSERT_H

/* Or here? */
#undef HAVE_PTHREAD_NP_H

/* We might be the silly hpux */
#undef hpux

/* Are we sysv? */
#undef SYSV

/* Fucked up IRIX */
#undef IRIX

/* Or svr4 perhaps? */
#undef SVR4

/* Some kind of Linux */
#undef LINUX

/* Or perhaps some bsd variant? */
#undef __SOMEBSD__

/* UNIX98 and others want socklen_t */
#undef HAVE_SOCKLEN_T

/* The complete version of ntripcaster */
#undef VERSION

/* Definately Solaris */
#undef SOLARIS

/* directories that we use... blah blah blah */
#undef ICECAST_ETCDIR
#undef ICECAST_LOGDIR
#undef ICECAST_TEMPLATEDIR

/* What the hell is this? */
#undef PACKAGE

/* DAMN I HATE HATE HATE AUTOCONF */
#undef HAVE_SOCKET
#undef HAVE_CONNECT
#undef HAVE_GETHOSTBYNAME
#undef HAVE_NANOSLEEP
#undef HAVE_YP_GET_DEFAULT_DOMAIN
