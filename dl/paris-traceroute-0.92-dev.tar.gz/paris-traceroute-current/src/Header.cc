#include "Header.h"

#include <stdio.h>

Header::Header ()
{
	printf("new header\n");
}

/*Header::~Header ()
{
	printf("delete header\n");
}*/
