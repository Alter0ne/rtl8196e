#include "DestinationList.h"

DestinationList::DestinationList () {
}

void
DestinationList::setFile(char *file) {
}

void
DestinationList::setAddress(char *addr) {
}

bool next () {
}
