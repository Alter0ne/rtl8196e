/*
 * rarpd - monitor/respond to RARP requests
 */
#include <stdio.h>
#include <stdlib.h>
#ifdef HAVE_STRING_H
#include <string.h>
#else
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#endif
#include <unistd.h>
#include <sys/types.h>
#include <sys/param.h>
#ifdef HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#include <signal.h>
#ifdef HAVE_PATHS_H
#include <paths.h>
#endif
#include <syslog.h>

#include <netinet/in.h>
#ifdef HAVE_NET_IF_ARP_H
/* For SIOCSARP */
#include <net/if_arp.h>
#endif
#ifdef HAVE_NET_IF_ETHER_H
#include <net/if_ether.h>
#endif
#include <pcap.h>
#include <libnet.h>
#ifdef HAVE_CTYPE_H
#include <ctype.h>
#endif
#include <netdb.h>
#ifdef HAVE_PCAP_NAMEDB_H
#include <pcap-namedb.h>
#endif
#include <sys/ioctl.h>
#ifdef HAVE_SYS_SOCKIO_H
#include <sys/sockio.h>
#endif
#include <errno.h>
#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 256
#endif

#ifdef HAVE_SIGSET
#define SIGNALFUNC sigset
#else
#define SIGNALFUNC signal
#endif

#ifndef _PATH_ETHERS
#define _PATH_ETHERS "/etc/ethers"
#endif

#define EXTRACT_16BITS(p) ((u_short)ntohs(*(u_short *)(p)))

#define ETHERADDRLEN      (ETHER_ADDR_LEN)
#define IPADDRLEN         (4)
#define ETHERSTRLEN       sizeof("00:00:00:00:00:00")
#define IPSTRLEN          sizeof(".xxx.xxx.xxx.xxx")

#ifdef NEW_LIBNET_INTERFACE
#define open_link_interface libnet_open_link_interface
#define link_int libnet_link_int 
#define build_arp libnet_build_arp 
#define get_ipaddr libnet_get_ipaddr
#define get_hwaddr libnet_get_hwaddr
#define build_ethernet libnet_build_ethernet
#define write_link_layer libnet_write_link_layer

/* Temporary workaround */
#define ARP_H LIBNET_ARP_H
#endif

extern char pcap_version[];
extern int optind;
extern int opterr;
extern char *optarg;

static int dflag;                      /* debugging output */
static int vflag;                      /* be verbose */
static char *program_name;

static pcap_t *pd;
static struct link_int *ln;
static char *device, *ethers;
struct in_addr my_ipaddr;
static u_char my_hwaddr[ETHERADDRLEN];


/* Convert an ethernet address to printable form in the provided buffer */
static char hex[] = "0123456789abcdef";
void etheraddr_string(register const u_char *ep, char *cp)
{
  register u_int i, j;

  if ((j = *ep >> 4) != 0)
    *cp++ = hex[j];
  *cp++ = hex[*ep++ & 0xf];
  for (i = 5; (int)--i >= 0;) {
    *cp++ = ':';
    if ((j = *ep >> 4) != 0)
      *cp++ = hex[j];
    *cp++ = hex[*ep++ & 0xf];
  }
  *cp = '\0';
}


/* Convert an IP address to printable form in the provided buffer */
char *ipaddr_string(struct in_addr *ipaddr, char *cp)
{
  unsigned int addr, byte, i;

  addr = ntohl(ipaddr->s_addr);
  cp += IPSTRLEN;
  *--cp = '\0';

  for (i = 0; i < 4; i++) {
    byte = addr & 0xff;
    *--cp = byte % 10 + '0';
    byte /= 10;
    if (byte > 0) {
      *--cp = byte % 10 + '0';
      byte /= 10;
      if (byte > 0)
        *--cp = byte + '0';
    }
    *--cp = '.';
    addr >>= 8;
  }

  return cp + 1;
}


/* Parse an IP address in printable form.  Return 1 iff it is valid. */
int ipaddr_parse(char *cp, struct in_addr *ipaddr)
{
  unsigned int addr;
  int a[4], i;

  a[0] = a[1] = a[2] = a[3] = i = 0;
  if (!*cp || *cp == '.') return 0;
  while (*cp) {
    if (isdigit(*cp)) {
      a[i] = a[i] * 10 + (*cp++ - '0');
      if (a[i] > 255) return 0;
    } else if (*cp++ == '.') {
      if (!*cp || *cp == '.') return 0;
      if (++i > 3) return 0;
    } else {
      return 0;
    }
  }
  if (i < 3) return 0;

  addr = (a[0] << 24) | (a[1] << 16) | (a[2] << 8) | a[3];
  memset(ipaddr, 0, sizeof(*ipaddr));
  ipaddr->s_addr = htonl(addr);
  return 1;
}


/* Parse the contents of a line in /etc/ethers
 * Borrowed from ether_ntohost.c:
 * * Written by Roland McGrath  10/14/93.
 * * Public domain.
 */
int ether_line(char *l, unsigned char *e, char *hostname)
{
  unsigned int i[6];

  if (sscanf(l, " %x:%x:%x:%x:%x:%x %s\n", &i[0], &i[1],
      &i[2], &i[3], &i[4], &i[5], hostname) < 7
  ||  i[0] > 255 || i[1] > 255 || i[2] > 255
  ||  i[3] > 255 || i[4] > 255 || i[5] > 255) {
    errno = EINVAL;
    return -1;
  }

  e[0] = (unsigned char)i[0];
  e[1] = (unsigned char)i[1];
  e[2] = (unsigned char)i[2];
  e[3] = (unsigned char)i[3];
  e[4] = (unsigned char)i[4];
  e[5] = (unsigned char)i[5];
  return 0;
}


/* Look up an address in the /etc/ethers file.
 * Borrowed from ether_ntohost.c:
 * * Written by Roland McGrath  10/14/93.
 * * Public domain.
 */
int my_ether_ntohost(char *hostname, unsigned char *e)
{
  static unsigned char try[ETHERADDRLEN];
  static char buf[BUFSIZ];
  FILE *f;

  /* XXX: consider caching? */

  if (dflag) fprintf(stderr, "Scanning %s...\n", ethers);
  if (!(f = fopen(ethers, "r"))) return -1;

  while (fgets(buf, sizeof buf, f)) {
    if (dflag) fprintf(stderr, ">> %s", buf);

#ifdef YP
    /* A + in the file means try YP now.  */
    if (!strncmp(buf, "+\n", sizeof buf)) {
      static char ebuf[ETHERSTRLEN];
      char *ypbuf, *ypdom;
      int ypbuflen;

      etheraddr_string(e, ebuf);
      if (yp_get_default_domain(&ypdom)) continue;
      if (yp_match(ypdom, "ethers.byaddr", ebuf,
                   strlen(ebuf), &ypbuf, &ypbuflen))
        continue;
      if (ether_line(ypbuf, try, hostname) == 0) {
        free(ypbuf);
        fclose(f);
        return 0;
      }
      free(ypbuf);
      continue;
    }
#endif
    if (ether_line(buf, try, hostname) == 0
    &&  !memcmp(try, e, ETHERADDRLEN)) {
      if (dflag) fprintf(stderr, "Found %s...\n", hostname);
      fclose(f);
      return 0;
    }
  }

  fclose(f);
  if (dflag) fprintf(stderr, "Not found\n", hostname);
  errno = ENOENT;
  return -1;
}



/* Set a local ARP cache entry */
void set_arp(struct in_addr *herip, unsigned char *herhwaddr) 
{
  int fd;
  struct arpreq ar;
  struct sockaddr_in *si;

  memset(&ar, 0, sizeof(ar));
  si = (struct sockaddr_in *)&ar.arp_pa;
#ifdef linux
  strncpy(ar.arp_dev,device,15);
#endif
  memcpy(ar.arp_ha.sa_data, (char *)herhwaddr, ETHERADDRLEN);
  memcpy((char *) &si->sin_addr, herip, IPADDRLEN);

  si->sin_family = AF_INET;
  ar.arp_flags = 0;

  if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
      return;

  ioctl(fd, SIOCDARP, (caddr_t)&ar); 

  ioctl(fd, SIOCSARP, (caddr_t)&ar);

  close(fd);
  return;
}


/* Construct and transmit an RARP reply */
void send_rarpreply(unsigned char *dest_hwaddr,
                    unsigned char *her_hwaddr, struct in_addr *her_ipaddr)
{
  char ebuf[PCAP_ERRBUF_SIZE];
  u_char buf[ARP_H+ETH_H];

  memset(buf, 0, ARP_H + ETH_H);

  /* Ethernet header */
  build_ethernet(dest_hwaddr, my_hwaddr, ETHERTYPE_REVARP, NULL, 0, buf);

  /* ARP header */
  build_arp(ARPHRD_ETHER, ETHERTYPE_IP,
            ETHERADDRLEN, IPADDRLEN,
            ARPOP_REVREPLY,
            my_hwaddr, (u_char *)&(my_ipaddr.s_addr),
            her_hwaddr, (u_char *)&(her_ipaddr->s_addr),
            NULL, 0, buf + ETH_H);

  write_link_layer(ln, (const u_char *)device, buf, ARP_H + ETH_H);
}


void process_arp(u_char *user, const struct pcap_pkthdr *h, const u_char *bp)
{
  static char sebuf[ETHERSTRLEN], tebuf[ETHERSTRLEN];
  static char ipbuf[IPSTRLEN], toret[1024];
  unsigned char *sha, *spa, *tha, *tpa;
  unsigned int ipaddr;
  unsigned short pro, hrd, op;
  struct in_addr her_ipaddr;
  struct libnet_arp_hdr *ap;
  struct hostent *hp;
  char *ipp;

  bp += sizeof(struct libnet_ethernet_hdr);
  ap = (struct libnet_arp_hdr *)bp;

  pro = EXTRACT_16BITS (&ap->ar_pro);
  hrd = EXTRACT_16BITS (&ap->ar_hrd);
  op  = EXTRACT_16BITS (&ap->ar_op);

  /* We presently support only 10/100 Mbps Ethernet and IPv4 */
  if (hrd != ARPHRD_ETHER || pro != ETHERTYPE_IP) return;
  if (ap->ar_hln != ETHERADDRLEN || ap->ar_pln != IPADDRLEN) return;

  /* We only answer RARP requests */
  if (op != ARPOP_REVREQUEST) return;

  sha = ap->ar_sha;
  spa = ap->ar_spa;
  tha = ap->ar_tha;
  tpa = ap->ar_tpa;

  if (my_ether_ntohost(toret, tha)) {
    if (vflag) {
      etheraddr_string(tha, tebuf);
      etheraddr_string(sha, sebuf);
      syslog(LOG_NOTICE, "rarp who-is %s tell %s not found", tebuf, sebuf);
    }
    return;
  }

#ifdef ALLOW_IPADDRS
  if (pro == ETHERTYPE_IP && ipaddr_parse(toret, &ipaddr)) {
    memset(&her_ipaddr, 0, sizeof(her_ipaddr));
    her_ipaddr.s_addr = ipaddr;
  } else
#endif

  if ((hp = gethostbyname(toret))) {
    if (hp->h_addrtype == AF_INET && hp->h_length == IPADDRLEN) {
      memcpy((char *)&her_ipaddr, hp->h_addr, IPADDRLEN);
    } else {
      etheraddr_string(tha, tebuf);
      etheraddr_string(sha, sebuf);
      syslog(LOG_WARNING, "rarp who-is %s tell %s non-IP addr", tebuf, sebuf);
      return;
    }
  } else {
    etheraddr_string(tha, tebuf);
    etheraddr_string(sha, sebuf);
    syslog(LOG_WARNING, "rarp who-is %s tell %s unknown host", tebuf, sebuf);
    return;
  }

  if (vflag) {
    etheraddr_string(tha, tebuf);
    etheraddr_string(sha, sebuf);
    ipp = ipaddr_string(&her_ipaddr, ipbuf);
    syslog(LOG_NOTICE, "rarp who-is %s tell %s answer %s", tebuf, sebuf, ipp);
  }

  set_arp(&her_ipaddr, tha);
  send_rarpreply(sha, tha, &her_ipaddr);
  return;
}


void usage(void)
{
  fprintf(stderr, "Usage: %s [options]\n", program_name);
  fprintf(stderr, "libpcap version %s\n", pcap_version);
  fprintf(stderr, "  -e path    Use specified 'ethers' file\n");
  fprintf(stderr, "  -i path    Listen on specified network interface\n");
  fprintf(stderr, "  -n         Don't run in the background\n");
  fprintf(stderr, "  -v         Verbose output\n");
  fprintf(stderr, "  -d         Debugging output\n");
  exit(-1);
}


int main(int argc, char **argv)
{
  int nofork, op, pid, syslogflags;
  bpf_u_int32 localnet, netmask;
  char ebuf[PCAP_ERRBUF_SIZE];
  char *cmdbuf;
  struct bpf_program fcode;

  nofork = vflag = dflag = 0;
  device = ethers = 0;

  program_name = strrchr(argv[0], '/');
  if (program_name) program_name++;
  else program_name = argv[0];

  opterr = 0;
  while ((op = getopt(argc, argv, "de:i:nv")) != EOF) {
    switch (op) {
      case 'e': ethers = optarg; continue;
      case 'i': device = optarg; continue;
      case 'n': ++nofork;        continue;
      case 'v': ++vflag;         continue;
      case 'd': ++dflag;         continue;
      default:  usage();
    }
  }

#ifdef LOG_PERROR
  syslogflags = dflag ? LOG_PID | LOG_PERROR : LOG_PID;
#else
  syslogflags = LOG_PID;
#endif
  openlog(program_name, syslogflags, LOG_LOCAL1);

  if (!nofork) {
    pid = fork();
    if (pid > 0) exit(0);
    if (pid < 0) {
      syslog(LOG_ERR, "%s: fork failed: %s", program_name, strerror(errno));
      exit(1);
    }
  }

  if (ethers == NULL) ethers = _PATH_ETHERS;
  if (device == NULL) {
    device = pcap_lookupdev(ebuf);
    if (device == NULL) {
      syslog(LOG_ERR, "%s: %s", program_name, ebuf);
      exit(1);
    }
  }

  ln = open_link_interface(device, ebuf);
  if (ln == NULL) {
    syslog(LOG_ERR, "%s: %s", program_name, ebuf);
    exit(1);
  }

  pd = pcap_open_live(device, 68, 0, 1000, ebuf);
  if (pd == NULL) {
    syslog(LOG_ERR, "%s: %s", program_name, ebuf);
    exit(1);
  }

  pcap_snapshot(pd);
  if (pcap_lookupnet(device, &localnet, &netmask, ebuf) < 0) {
    localnet = 0;
    netmask = 0;
  }

  memset(&my_ipaddr, 0, sizeof(my_ipaddr));
  my_ipaddr.s_addr = htonl(get_ipaddr(ln, device, ebuf));
  memcpy(my_hwaddr, (char *)get_hwaddr(ln, device, ebuf), ETHERADDRLEN);

  setuid(getuid());

  cmdbuf = strdup("rarp or arp");
  if (pcap_compile(pd, &fcode, cmdbuf, 1, netmask) < 0) {
    syslog(LOG_ERR, "%s: %s", program_name, pcap_geterr(pd));
    exit(1);
  }

  if (pcap_setfilter(pd, &fcode) < 0) {
    syslog(LOG_ERR, "%s: %s", program_name, pcap_geterr(pd));
    exit(1);
  }

  if (vflag) {
    syslog(LOG_INFO, "%s: listening on %s", program_name, device);
    fflush(stderr);
  }

  if (pcap_loop(pd, -1, process_arp, 0) < 0) {
    syslog(LOG_ERR, "%s: pcap_loop: %s", program_name, pcap_geterr(pd));
    exit(1);
  }

  pcap_close(pd);
  exit(0);
}
