# Defaults for rtpproxy initscript
# sourced by /etc/init.d/rtpproxy
# installed at /etc/default/rtpproxy by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
