#
# Regular cron jobs for the rtpproxy package
#
0 4	* * *	root	rtpproxy_maintenance
