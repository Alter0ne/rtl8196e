?package(rtpproxy):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="rtpproxy" command="/usr/bin/rtpproxy"
