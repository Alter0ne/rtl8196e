#!/bin/sh
echo "1..1"
echo "ok 1 - source_args.sh $1"
