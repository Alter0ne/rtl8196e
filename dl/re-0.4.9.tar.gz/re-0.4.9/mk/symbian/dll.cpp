#include <e32def.h>
#include <e32std.h>


#ifndef EKA2
GLDEF_C TInt E32Dll(TDllReason /*aReason*/)
{
	return KErrNone;
}
#endif
