struct DHCP_MESSAGE * create_solicit_message (char *);
struct OPTIONS * add_ia_option (struct interface *);
struct OPTIONS * add_ia_addr_option (struct interface *);
struct DUID * add_duid (u_int16_t *, struct interface *);
struct OPTIONS * add_client_id_option (struct interface *);
