#define INITIALIZE_SOCKADDR(x){                                  \
  bzero((char *) &(x), sizeof((x)));                             \
  (x).sin6_family   = AF_INET6;                                  \
  (x).sin6_flowinfo = htonl(0);                                  \
  (x).sin6_scope_id = 0;                                         \
}
