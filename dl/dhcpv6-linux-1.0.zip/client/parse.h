void read_config_file (char **, char *);
void skip_whitespace (char **);
int move_across_substring (char **, char *);
void read_token (char **, char **);
struct interface * get_interface_details (char *);
void print_interface_details (struct interface *);
