struct DHCP_MESSAGE * create_renew_message (struct DHCP_MESSAGE *, char *);
