struct DHCP_MESSAGE * create_request_message (struct DHCP_MESSAGE *, char *);
struct OPTIONS * copy_message_option (struct DHCP_MESSAGE *, int);
