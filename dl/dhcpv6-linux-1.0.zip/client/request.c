#include "stdhead.h"
#include "request.h"
#include "clilib.h"

// This function creates a REQUEST message from the ADCVERTISE message and 
// returns a pointer to the REQUEST message
struct DHCP_MESSAGE * create_request_message (struct DHCP_MESSAGE *advertise_message, char *interface_name)
{
    // Allocate memory fot the REPLY message
    struct DHCP_MESSAGE *dhcp_message_ptr = (struct DHCP_MESSAGE *) malloc (sizeof (struct DHCP_MESSAGE));
    struct OPTIONS *options_ptr;
    struct DUID * duid_ptr;
    struct IA * ia_ptr;
    struct IA_ADDRESS * iaaddr_ptr;
    
    // Assign the message type as REQUEST
    dhcp_message_ptr -> u_msg_type.msg_type = REQUEST;
    // Generate the Transaction Id
    generate_trans_id (&dhcp_message_ptr -> u_trans_id.trans_id);
    // Copy and paste the Client Id option from the ADVERTISE message into 
    // the REQUEST message
    dhcp_message_ptr -> opt = copy_message_option (advertise_message, OPTION_CLIENTID);
    // Move onto to the next (option) next (duid) node
    duid_ptr = (struct DUID *) dhcp_message_ptr -> opt -> opt_data;
    // Copy and Paste the Server Id option from the ADVERTISE message into the
    // REQUEST message
    duid_ptr -> opt = copy_message_option (advertise_message, OPTION_SERVERID);
    // Move onto to the next (option) next (duid) node
    duid_ptr = (struct DUID *) duid_ptr -> opt -> opt_data;
    // Copy and Paste the IA option from the ADVERTISE message into the
    // REQUEST message
    duid_ptr -> opt = copy_message_option (advertise_message, OPTION_IA);
    // Move onto to the next (option) next (ia) node
    ia_ptr = (struct IA *) duid_ptr -> opt -> opt_data;
    // Copy and Paste the IA_ADDRESS option from the ADVERTISE message into the
    // REQUEST message
    ia_ptr -> opt = copy_message_option (advertise_message, OPTION_IAADDR);
    // Move onto to the next (option) next (ia_address) node
    iaaddr_ptr = (struct IA_ADDRESS *) ia_ptr -> opt -> opt_data;
    // Assign the next option pointer as zero
    iaaddr_ptr -> opt = 0;
    return dhcp_message_ptr;
}    
