struct DHCP_MESSAGE * create_rebind_message (struct DHCP_MESSAGE *, char *);
