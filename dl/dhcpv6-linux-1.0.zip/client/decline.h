struct DHCP_MESSAGE * create_decline_message (struct DHCP_MESSAGE *, char *);
