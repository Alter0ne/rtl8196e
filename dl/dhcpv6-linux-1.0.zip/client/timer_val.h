// Solicit timer values
#define MIN_SOL_DELAY 	1
#define MAX_SOL_DELAY 	5
#define SOL_TIMEOUT 	0.5
#define SOL_IRT 	SOL_TIMEOUT
#define SOL_MAX_RT 	30
#define SOL_MRC		0		// Change this value for limited solicitize
#define SOL_MRD 	0

// Request timer values
#define REQ_TIMEOUT 	0.25
#define REQ_MAX_RT	30
#define REQ_MAX_RC	10
#define REQ_MAX_RD	0
#define REQ_IRT		REQ_TIMEOUT
#define REQ_MRT		REQ_MAX_RT
#define REQ_MRC		REQ_MAX_RC
#define REQ_MRD		REQ_MAX_RD

// Decline timer values
#define DEC_TIMEOUT	0.25
#define DEC_MAX_RT	1
#define DEC_MAX_RC	5
#define DEC_MAX_RD	0
#define DEC_IRT		DEC_TIMEOUT
#define DEC_MRT		DEC_MAX_RT
#define DEC_MRC		DEC_MAX_RC
#define DEC_MRD		DEC_MAX_RD

// Renewal timer values
#define REN_TIMEOUT	10
#define REN_MAX_RT	600
#define REN_MAX_RC 	0
#define REN_MAX_RD	0
#define REN_IRT		REN_TIMEOUT
#define REN_MRT		REN_MAX_RT
#define REN_MRC		REN_MAX_RC
#define REN_MRD		REN_MAX_RD

// Rebind timer values
#define REB_TIMEOUT 	10
#define REB_MAX_RT	600
#define REB_MAX_RC	0
#define REB_MAX_RD	0
#define REB_IRT		REB_TIMEOUT
#define REB_MRT		REB_MAX_RT
#define REB_MRC		REB_MAX_RC
#define REB_MRD		REB_MAX_RD



// Release timer values
#define REL_TIMEOUT 	0.25
#define REL_MAX_RT	1
#define REL_MAX_RC	5
#define REL_MAX_RD	0
#define REL_IRT		REL_TIMEOUT
#define REL_MRT		REL_MAX_RT
#define REL_MRC		REL_MAX_RC
#define REL_MRD		REL_MAX_RD
