#define INIT 1
#define SELECTING 2
#define REQUESTING 3
#define CHECKING 4
#define BOUND 5
#define RENEWING 6
#define REBINDING 7
#define END 8
