struct DHCP_MESSAGE * create_release_message (struct DHCP_MESSAGE *, char *);
