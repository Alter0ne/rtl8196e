struct OPTIONS * copy_client_id (struct DHCP_MESSAGE *, struct OPTIONS *);
struct OPTIONS * add_ia_option (struct DHCP_MESSAGE *, struct addr_details *, struct OPTIONS *);
struct OPTIONS * add_preference_option (int, struct OPTIONS *);
void add_iaaddr_option (struct DHCP_MESSAGE *, struct addr_details *, struct OPTIONS *);
struct DHCP_MESSAGE * create_advertise_message (struct DHCP_MESSAGE *, struct addr_details *);
