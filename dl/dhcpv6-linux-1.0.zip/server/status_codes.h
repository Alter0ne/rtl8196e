// Generic status codes
#define Success 		0
#define UnspecFail	16
#define AuthFailed	17
#define PoorlyFormed	18
#define AddrUnavail	19
#define OptionUnavail	20

// Server specific status codes
#define NoBinding		32
#define ConfNoMatch	33
#define RenwNoMatch	34
#define RebdNoMatch	35
#define InvalidSource	36
#define NoPrefixMatch	37
