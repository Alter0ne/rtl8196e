void read_config_file (char *);
void skip_whitespace (void);
int move_across_substring (char *);
int Move_across_substring (char *);
void read_token (void);
int find_if_s1_before_s2 (char *, char *);
struct config_head ** parse_and_assign (char *, int *, int);
void print_config_list_contents (struct config_head *);
void print_server_duid (void);
