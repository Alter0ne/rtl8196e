#define ALL_DHCP_AGENTS "ff02::1:2"
#define ALL_DHCP_SERVERS "ff05::1:3"
#define CLIENT_PORT 546
#define AGENT_PORT 547

#define DEFAULT_CONFIG_FILE "dhcpd6.conf"
#define DEFAULT_EVENT_LOG_FILE "event.log"
#define LEASES_FILE "leases6.conf"
#define PARTIAL_LEASES_FILE "partial_leases6.conf"

#define MIN_MESSAGE_SIZE 576
#define DEBUG 2				// Debug level = 1 or 2

#define NO_NODE 0
#define RANGE_NODE 1
#define USER_NODE 2

#define FIVE_MINUTES 300		// 300 secs = 5 minutes
