struct OPTIONS * copy_ia_option (struct DHCP_MESSAGE *, struct OPTIONS *);
void copy_iaaddr_option (struct DHCP_MESSAGE *, struct OPTIONS *);
struct DHCP_MESSAGE * create_reply_message (struct DHCP_MESSAGE *);
struct DHCP_MESSAGE * create_dummy_reply_message (struct DHCP_MESSAGE *);
struct DHCP_MESSAGE * create_reply_message_for_decline (struct DHCP_MESSAGE *);
struct DHCP_MESSAGE * create_reply_message_for_release (struct DHCP_MESSAGE *);
