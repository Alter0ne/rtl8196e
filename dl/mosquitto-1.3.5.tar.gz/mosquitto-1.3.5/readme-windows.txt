Mosquitto is now installed as a Windows service. You can start/stop it from
the control panel as well as running it as a normal executable.

When running as a service, the configuration in mosquitto.conf in the
installation directory is used so modify this to your needs.


This product includes software developed by the OpenSSL Project for use in the
OpenSSL Toolkit. (http://www.openssl.org/)
This product includes cryptographic software written by Eric Young
(eay@cryptsoft.com)
This product includes software written by Tim Hudson (tjh@cryptsoft.com)
