#include <stdio.h>

#include "mgetty.h"

int main _P2((argc, argv),  int argc, char ** argv )
{
    fprintf( stderr, "ct: not yet implemented\n" );
    return 1;
}
