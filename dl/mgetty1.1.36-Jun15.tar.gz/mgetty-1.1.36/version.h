char * mgetty_version = "interim release 1.1.36-Jun15";
