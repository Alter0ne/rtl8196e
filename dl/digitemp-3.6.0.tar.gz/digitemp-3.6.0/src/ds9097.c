const char dtlib[] = "DS9097";
