const char dtlib[] = "DS2490";
