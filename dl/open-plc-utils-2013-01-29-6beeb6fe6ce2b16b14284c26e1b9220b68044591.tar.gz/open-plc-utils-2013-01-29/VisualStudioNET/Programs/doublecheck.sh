#!/bin/sh
# =
#
# -
diff -ru 2003 2010 | grep -v manifest
