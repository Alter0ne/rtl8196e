var structtransapi__file__callbacks =
[
    [ "callbacks", "de/df8/structtransapi__file__callbacks.html#af315aee2dd9c7f04ef44d3dc4f1565d9", null ],
    [ "callbacks_count", "de/df8/structtransapi__file__callbacks.html#a853d73f0f495147dba4842e9f860d1f0", null ],
    [ "func", "de/df8/structtransapi__file__callbacks.html#a9c1038ab827316debf4109f49818519f", null ],
    [ "path", "de/df8/structtransapi__file__callbacks.html#a3b02c6de5c049804444a246f7fdf46b4", null ]
];