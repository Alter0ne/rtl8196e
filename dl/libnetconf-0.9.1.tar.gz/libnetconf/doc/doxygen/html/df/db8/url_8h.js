var url_8h =
[
    [ "NC_URL_PROTOCOLS", "d5/d7d/group__url.html#gaeecc86d0808c9098b6a8694e88925ccd", [
      [ "NC_URL_UNKNOWN", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccda25a2594eef86bcfc593a9256f943a38a", null ],
      [ "NC_URL_SCP", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccda41ef284c88ec1d6e7e46b2ce5d867572", null ],
      [ "NC_URL_HTTP", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccda5977de49ac0680ca80381aeb77aa40e6", null ],
      [ "NC_URL_HTTPS", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccdac4845180d4dc7ffc3a482b9009917f4b", null ],
      [ "NC_URL_FTP", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccdababa68c3eb86c395a6115e8c9d34f0e2", null ],
      [ "NC_URL_SFTP", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccda195e44921173a9182565b7e3181ce20e", null ],
      [ "NC_URL_FTPS", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccdaaa0ce2cbe471bbf25e1f3070b46d588f", null ],
      [ "NC_URL_FILE", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccda68d344995eae71ef85e07bb4a97c13e1", null ],
      [ "NC_URL_ALL", "d5/d7d/group__url.html#ggaeecc86d0808c9098b6a8694e88925ccda120f1a8076bbafe4bddd026d27ac54dd", null ]
    ] ],
    [ "nc_url_disable", "d5/d7d/group__url.html#gadf6c3370da661ab29b0834086a0dfbfe", null ],
    [ "nc_url_enable", "d5/d7d/group__url.html#gafd033a4d3cafcd3f6af307dacaa18e50", null ],
    [ "nc_url_set_protocols", "d5/d7d/group__url.html#ga61d005676d5582665a473229fc2180f7", null ]
];