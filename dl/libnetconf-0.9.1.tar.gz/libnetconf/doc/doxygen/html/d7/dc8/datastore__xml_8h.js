var datastore__xml_8h =
[
    [ "ncds_add_augment_transapi_static", "d8/d55/group__transapi.html#ga7f6f5af711045d8598f283ec09b9167a", null ],
    [ "ncds_new2", "db/d67/group__store.html#ga18655a18464191a4aab1ef0b7d8ba5df", null ],
    [ "ncds_new_transapi_static", "d8/d55/group__transapi.html#gaaf4e4daa7fa8be965ded41eb006a6713", null ],
    [ "ncds_set_validation2", "db/d67/group__store.html#ga31c6fa81cf4c62c32561c1047903477f", null ]
];