var group__reply =
[
    [ "nc_reply", "d0/de2/group__reply.html#ga40338a1274759a932a7c2c7b8ed0121d", null ],
    [ "NC_REPLY_TYPE", "d0/de2/group__reply.html#gad31ee5df47d5671ebdf1b06f785e6c29", [
      [ "NC_REPLY_UNKNOWN", "d0/de2/group__reply.html#ggad31ee5df47d5671ebdf1b06f785e6c29aa4e871d4592173b6fff7a8d4815c8e29", null ],
      [ "NC_REPLY_HELLO", "d0/de2/group__reply.html#ggad31ee5df47d5671ebdf1b06f785e6c29a6d190ad4c3f0ecbaab7956227e606d27", null ],
      [ "NC_REPLY_OK", "d0/de2/group__reply.html#ggad31ee5df47d5671ebdf1b06f785e6c29ac65f86e9af3940dc910231afd07a70cf", null ],
      [ "NC_REPLY_ERROR", "d0/de2/group__reply.html#ggad31ee5df47d5671ebdf1b06f785e6c29aa47af543410586d8da28f02f099abce0", null ],
      [ "NC_REPLY_DATA", "d0/de2/group__reply.html#ggad31ee5df47d5671ebdf1b06f785e6c29acf47a744ed6a6b613d63f4a77aa7135e", null ]
    ] ],
    [ "nc_callback_error_reply", "d0/de2/group__reply.html#ga771a110143440bcd3b7d4c0e98388e80", null ],
    [ "nc_reply_build", "d0/de2/group__reply.html#ga78b032942cee08721d51ea97acff68b5", null ],
    [ "nc_reply_data", "d0/de2/group__reply.html#ga4543351c89208bb06fa895be334d59ad", null ],
    [ "nc_reply_data_ns", "d0/de2/group__reply.html#ga8c365a22efcaab4f1c29b3f51f254aea", null ],
    [ "nc_reply_dump", "d0/de2/group__reply.html#ga279c8b48bfdf590c15a043b7d385dfb8", null ],
    [ "nc_reply_dup", "d0/de2/group__reply.html#gaeb66eff28fdf195f564cb3d997d65b65", null ],
    [ "nc_reply_error", "d0/de2/group__reply.html#ga12fd89263289491b84398279e0e449fd", null ],
    [ "nc_reply_error_add", "d0/de2/group__reply.html#gafb04a6695650d05a07b571ac1410a681", null ],
    [ "nc_reply_free", "d0/de2/group__reply.html#ga17aa9f38d7b75dec1a57b478b0b39710", null ],
    [ "nc_reply_get_data", "d0/de2/group__reply.html#gaac62fb3d427985311cf71a2c3ab8d424", null ],
    [ "nc_reply_get_data_ns", "d0/de2/group__reply.html#ga4a5c880080d3044f1564192cd3780534", null ],
    [ "nc_reply_get_errormsg", "d0/de2/group__reply.html#ga121d66d8f7437d87a995b82187e7e7ff", null ],
    [ "nc_reply_get_msgid", "d0/de2/group__reply.html#gad6ed5b3e0b7d8fbeb81e80bc0a326d6c", null ],
    [ "nc_reply_get_type", "d0/de2/group__reply.html#gab12cdef82337060c425348dada7fe983", null ],
    [ "nc_reply_merge", "d0/de2/group__reply.html#gab1f7b7f9be8153758e5b047fe70fd48d", null ],
    [ "nc_reply_ok", "d0/de2/group__reply.html#ga047f565bb3671ec4016fef5461e8f67e", null ],
    [ "nc_session_recv_reply", "d0/de2/group__reply.html#ga1b8c8ca9516003938e8f647bd870beaa", null ],
    [ "nc_session_send_reply", "d0/de2/group__reply.html#ga0b344811af933d80615f0874650938cc", null ]
];