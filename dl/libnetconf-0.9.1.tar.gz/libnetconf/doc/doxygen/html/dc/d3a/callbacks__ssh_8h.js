var callbacks__ssh_8h =
[
    [ "nc_callback_ssh_host_authenticity_check", "db/d52/group__session.html#gaacafd4dbd19385fc395f965deaff0c86", null ],
    [ "nc_callback_sshauth_interactive", "db/d52/group__session.html#gacb6042fe2f3cfe5d79e01de599c546eb", null ],
    [ "nc_callback_sshauth_passphrase", "db/d52/group__session.html#ga81ef9b1c1949bbffd86cbfd9aa159726", null ],
    [ "nc_callback_sshauth_password", "db/d52/group__session.html#ga28299d575ef4e234ed96bad5c4f086fb", null ],
    [ "nc_set_keypair_path", "db/d52/group__session.html#gaf3ce5316ea11c2f0359db16c2828ad6f", null ]
];