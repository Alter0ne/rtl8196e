var searchData=
[
  ['callbacks',['callbacks',['../d6/dcb/structtransapi__data__callbacks.html#a37c3f849c79cfe4991c6d0a6526b12d7',1,'transapi_data_callbacks::callbacks()'],['../d0/df8/structtransapi__rpc__callbacks.html#a0ad28c1d0d3518ca0b3d631a20eaf48d',1,'transapi_rpc_callbacks::callbacks()'],['../de/df8/structtransapi__file__callbacks.html#af315aee2dd9c7f04ef44d3dc4f1565d9',1,'transapi_file_callbacks::callbacks()']]],
  ['callbacks_5fcount',['callbacks_count',['../d6/dcb/structtransapi__data__callbacks.html#a853d73f0f495147dba4842e9f860d1f0',1,'transapi_data_callbacks::callbacks_count()'],['../d0/df8/structtransapi__rpc__callbacks.html#a853d73f0f495147dba4842e9f860d1f0',1,'transapi_rpc_callbacks::callbacks_count()'],['../de/df8/structtransapi__file__callbacks.html#a853d73f0f495147dba4842e9f860d1f0',1,'transapi_file_callbacks::callbacks_count()']]],
  ['clbks_5forder',['clbks_order',['../d9/dc0/structtransapi.html#a9da1a4a7373fb09e2f82fb7f1a81f9b2',1,'transapi']]],
  ['close',['close',['../d9/dc0/structtransapi.html#a414e48f893be7474f64d2c61a9c012b9',1,'transapi']]],
  ['config_5fmodified',['config_modified',['../d9/dc0/structtransapi.html#aa234e35582e991cd6e5c43047e315528',1,'transapi']]],
  ['copyconfig',['copyconfig',['../d0/d28/structncds__custom__funcs.html#ae0d54e97fa9abaafbf3b234c365a09b6',1,'ncds_custom_funcs']]]
];
