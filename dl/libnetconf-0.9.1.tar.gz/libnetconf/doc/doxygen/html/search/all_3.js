var searchData=
[
  ['editconfig',['editconfig',['../d0/d28/structncds__custom__funcs.html#a218bd52cfd25ead58364f2d058dd737f',1,'ncds_custom_funcs']]],
  ['erropt',['erropt',['../d9/dc0/structtransapi.html#acb50180a0bc032bef4b6af94d8596528',1,'transapi']]],
  ['error_2eh',['error.h',['../da/d41/error_8h.html',1,'']]],
  ['error_5farea',['error_area',['../d9/db6/datastore_8h.html#a9d81ebfeff55fd595fb20a0804107b9b',1,'datastore.h']]]
];
