var searchData=
[
  ['data',['data',['../d6/dcb/structtransapi__data__callbacks.html#a735984d41155bc1032e09bece8f8d66d',1,'transapi_data_callbacks']]],
  ['data_5fclbks',['data_clbks',['../d9/dc0/structtransapi.html#a44e5e883d6586faf97047d23c7bcebf7',1,'transapi']]],
  ['deleteconfig',['deleteconfig',['../d0/d28/structncds__custom__funcs.html#a6318498a2d647313bf272303228ee4dc',1,'ncds_custom_funcs']]]
];
