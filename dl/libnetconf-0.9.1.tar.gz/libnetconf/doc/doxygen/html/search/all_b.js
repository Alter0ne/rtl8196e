var searchData=
[
  ['path',['path',['../d0/dd1/structclbk.html#a44196e6a5696d10442c29e639437196e',1,'clbk::path()'],['../de/df8/structtransapi__file__callbacks.html#a3b02c6de5c049804444a246f7fdf46b4',1,'transapi_file_callbacks::path()']]],
  ['prefix',['prefix',['../d0/d77/structns__pair.html#a5b41c5ae4505891e6c53e26df197e02b',1,'ns_pair']]]
];
