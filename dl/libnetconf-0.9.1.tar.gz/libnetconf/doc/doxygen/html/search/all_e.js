var searchData=
[
  ['todo_20list',['Todo List',['../dd/da0/todo.html',1,'']]],
  ['transapi',['transapi',['../d9/dc0/structtransapi.html',1,'transapi'],['../d8/d55/group__transapi.html',1,'(Global Namespace)'],['../d9/d25/transapi.html',1,'(Global Namespace)']]],
  ['transapi_2eh',['transapi.h',['../d0/db0/transapi_8h.html',1,'']]],
  ['transapi_5fclbcks_5fleaf_5fto_5froot',['TRANSAPI_CLBCKS_LEAF_TO_ROOT',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1ba0f850d99d45a329c625ae93ce7c34f31',1,'transapi.h']]],
  ['transapi_5fclbcks_5forder_5fdefault',['TRANSAPI_CLBCKS_ORDER_DEFAULT',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1ba4b7a2346cc5ffc5a23df0b4bb064ed17',1,'transapi.h']]],
  ['transapi_5fclbcks_5forder_5ftype',['TRANSAPI_CLBCKS_ORDER_TYPE',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1b',1,'transapi.h']]],
  ['transapi_5fclbcks_5froot_5fto_5fleaf',['TRANSAPI_CLBCKS_ROOT_TO_LEAF',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1ba773c1f494da420b279aa7754c1f06a05',1,'transapi.h']]],
  ['transapi_5fdata_5fcallbacks',['transapi_data_callbacks',['../d6/dcb/structtransapi__data__callbacks.html',1,'']]],
  ['transapi_5ffile_5fcallbacks',['transapi_file_callbacks',['../de/df8/structtransapi__file__callbacks.html',1,'']]],
  ['transapi_5frpc_5fcallbacks',['transapi_rpc_callbacks',['../d0/df8/structtransapi__rpc__callbacks.html',1,'']]],
  ['transapi_5fversion',['TRANSAPI_VERSION',['../d0/db0/transapi_8h.html#ab6b46fdad05fdb764492fcdea3cdeaba',1,'transapi.h']]],
  ['transport_20protocol',['Transport Protocol',['../d4/d76/transport.html',1,'usage']]],
  ['transport_2eh',['transport.h',['../d2/d02/transport_8h.html',1,'']]],
  ['troubleshooting',['Troubleshooting',['../d7/dc8/troubles.html',1,'usage']]]
];
