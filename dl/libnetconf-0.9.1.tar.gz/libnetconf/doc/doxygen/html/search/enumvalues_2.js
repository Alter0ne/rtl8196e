var searchData=
[
  ['transapi_5fclbcks_5fleaf_5fto_5froot',['TRANSAPI_CLBCKS_LEAF_TO_ROOT',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1ba0f850d99d45a329c625ae93ce7c34f31',1,'transapi.h']]],
  ['transapi_5fclbcks_5forder_5fdefault',['TRANSAPI_CLBCKS_ORDER_DEFAULT',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1ba4b7a2346cc5ffc5a23df0b4bb064ed17',1,'transapi.h']]],
  ['transapi_5fclbcks_5froot_5fto_5fleaf',['TRANSAPI_CLBCKS_ROOT_TO_LEAF',['../d0/db0/transapi_8h.html#aabe5b9de9828673d65438e3476f97a1ba773c1f494da420b279aa7754c1f06a05',1,'transapi.h']]]
];
