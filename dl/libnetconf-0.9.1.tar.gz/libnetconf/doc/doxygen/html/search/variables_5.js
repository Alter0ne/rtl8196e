var searchData=
[
  ['get_5fstate',['get_state',['../d9/dc0/structtransapi.html#a6c403c3ae7c1ca5654fdaf60b60ba16b',1,'transapi']]],
  ['getconfig',['getconfig',['../d0/d28/structncds__custom__funcs.html#a7e5c2e2b2abdd48a249f02526e04ceca',1,'ncds_custom_funcs']]]
];
