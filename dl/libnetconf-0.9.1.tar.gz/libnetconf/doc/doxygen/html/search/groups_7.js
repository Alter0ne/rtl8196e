var searchData=
[
  ['with_2ddefaults_20capability',['With-defaults capability',['../d1/df7/group__withdefaults.html',1,'']]]
];
