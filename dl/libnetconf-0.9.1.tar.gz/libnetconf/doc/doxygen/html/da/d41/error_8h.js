var error_8h =
[
    [ "NC_ERR", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2", [
      [ "NC_ERR_EMPTY", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a8c95848f31f6070e013f2ac38f6f22bd", null ],
      [ "NC_ERR_IN_USE", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a522dd14186af3542f42060929abf7ef3", null ],
      [ "NC_ERR_INVALID_VALUE", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a16aa01743fdf87211ee0ae76597700fe", null ],
      [ "NC_ERR_TOO_BIG", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2ae1f3c4815841a901ad647befff7843ad", null ],
      [ "NC_ERR_MISSING_ATTR", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a93fa8dd8448bb3198a7d343bd6ede7aa", null ],
      [ "NC_ERR_BAD_ATTR", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a36939dd04c4fb762eada65f57a62ea7c", null ],
      [ "NC_ERR_UNKNOWN_ATTR", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a299125a3243d51fae70b486f83ace750", null ],
      [ "NC_ERR_MISSING_ELEM", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2add388aa140f644d38615e27af0c9f5f4", null ],
      [ "NC_ERR_BAD_ELEM", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2ac4edd4c3e1d76082085e2a90b5eb66a1", null ],
      [ "NC_ERR_UNKNOWN_ELEM", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a571f6dfaa6f3408e05cb1997f4fa6c52", null ],
      [ "NC_ERR_UNKNOWN_NS", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a91d62d72802133159ffdc111a771bf06", null ],
      [ "NC_ERR_ACCESS_DENIED", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a6f707606a5cd4b97137a88dd4ed82ae5", null ],
      [ "NC_ERR_LOCK_DENIED", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a98ef57c7191057ac7ad9650f95109d50", null ],
      [ "NC_ERR_RES_DENIED", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a105abd229ceb04cf9a60595866c8b094", null ],
      [ "NC_ERR_ROLLBACK_FAILED", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a227b3f5d6a5e952a9b62e7c354ad55dd", null ],
      [ "NC_ERR_DATA_EXISTS", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a4bb9c38fcc7be1245963548be3c9ba8b", null ],
      [ "NC_ERR_DATA_MISSING", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2aba1253902aea9c5c38547a82546f880c", null ],
      [ "NC_ERR_OP_NOT_SUPPORTED", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2a8ed360b1189a365d70c5cb25417a18a0", null ],
      [ "NC_ERR_OP_FAILED", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2ae9d2e7a938b0fb4583b961a7079aabe3", null ],
      [ "NC_ERR_MALFORMED_MSG", "da/d41/error_8h.html#a170ed93037b65394a05e074400848eb2ab9ef7fd6f3d0a5649f42e2ba0dda9d26", null ]
    ] ],
    [ "nc_err_dup", "d3/d35/group__gen_a_p_i.html#ga316faef1140f1b48a2ed1de6d84d2bef", null ],
    [ "nc_err_free", "d3/d35/group__gen_a_p_i.html#gac4bd51febe24b517d1952d1c1d8f6b07", null ],
    [ "nc_err_get", "d3/d35/group__gen_a_p_i.html#ga3d7714f1f56ac7203a80c61aea4344f8", null ],
    [ "nc_err_new", "d3/d35/group__gen_a_p_i.html#ga057524ba5256c428b6bf88710f000e0c", null ],
    [ "nc_err_set", "d3/d35/group__gen_a_p_i.html#gab28d881eeebd79d485391ae1ffc97299", null ]
];