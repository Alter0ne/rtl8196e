var searchData=
[
  ['id',['id',['../classnetconf_1_1_session.html#acf2488b95c97e0378c9bf49de3b50f28',1,'netconf::Session']]],
  ['isactive',['isActive',['../classnetconf_1_1_session.html#a293f6f53f6a9c7ee4f2682a82dbadd70',1,'netconf::Session']]]
];
