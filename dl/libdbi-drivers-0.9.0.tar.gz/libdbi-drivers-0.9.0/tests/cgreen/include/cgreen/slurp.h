#ifndef SLURP_HEADER
#define SLURP_HEADER

#ifdef __cplusplus
  extern "C" {
#endif

char *slurp(const char *file_name, int gulp);

#ifdef __cplusplus
    }
#endif


#endif
