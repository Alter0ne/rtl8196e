#include <sys/types.h>

size_t strlcat(char *dst, const char *src, size_t size);
