/*
 * <arpa/inet.h>
 *
 * obs�uga sieci.
 *
 * $Id: inet.h,v 1.2 2002-08-07 14:37:07 wojtekka Exp $
 */

#include <winsock2.h>
