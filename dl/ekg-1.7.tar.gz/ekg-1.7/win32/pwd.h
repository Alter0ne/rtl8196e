/*
 * <pwd.h>
 *
 * nie mam poj�cia do czego potrzebny. widocznie jaka� architektura go
 * wymaga, wi�c zostawiam.
 * 
 * $Id: pwd.h,v 1.2 2002-08-07 14:37:06 wojtekka Exp $
 */
