/*
 * <netdb.h>
 *
 * inkludowany dla funkcji gethostbyname()
 *
 * $Id: netdb.h,v 1.2 2002-08-07 14:37:06 wojtekka Exp $
 */

#include <winsock2.h>
