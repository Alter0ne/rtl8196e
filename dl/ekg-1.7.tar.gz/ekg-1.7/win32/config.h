/*
 * <config.h>
 * 
 * zast�puje plik generowany przez skrypt ./configure.
 *
 * $Id: config.h,v 1.2 2002-08-07 14:37:06 wojtekka Exp $
 */
