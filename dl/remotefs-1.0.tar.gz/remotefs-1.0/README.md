* Project site: [http://remotefs.sourceforge.net/](http://remotefs.sourceforge.net/)
* Source code: ``git clone http://git.code.sf.net/p/remotefs/git remotefs``
* Downloads: [http://sourceforge.net/projects/remotefs/files/](http://sourceforge.net/projects/remotefs/files/)
* Wiki: [http://sourceforge.net/apps/mediawiki/remotefs/index.php?title=Main_Page](http://sourceforge.net/apps/mediawiki/remotefs/index.php?title=Main_Page)
* Issue tracker: [http://sourceforge.net/p/remotefs/bugs/](http://sourceforge.net/p/remotefs/bugs/)
* Mailing lists: [http://sourceforge.net/p/remotefs/mailman/](http://sourceforge.net/p/remotefs/mailman/)

For build options see BUILD, for authors information see AUTHORS,
for license see LICENSE.
