#ifdef __cplusplus
extern "C" {
#endif

#ifndef GET_OPTS
#define GET_OPTS

extern char getOpts(char *optString, int argc, char **argv, char **opt, int *idx);

#endif

#ifdef __cplusplus
}
#endif

