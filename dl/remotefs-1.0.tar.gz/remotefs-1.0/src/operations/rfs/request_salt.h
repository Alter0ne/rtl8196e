/*
remotefs file system
See the file AUTHORS for copyright information.
	
This program can be distributed under the terms of the GNU GPL.
See the file LICENSE.
*/

#ifndef OPERATIONS_RFS_REQUEST_SALT_H
#define OPERATIONS_RFS_REQUEST_SALT_H

/** rfs_request_salt */

struct rfs_instance;
int rfs_request_salt(struct rfs_instance *instance);

#endif /* OPERATIONS_RFS_REQUEST_SALT_H */
