
#include "stub/framework.hpp"
#include "framework_test.hpp"

void FrameworkTest::setUp()
{
    Stub::Framework::reset();
}

void FrameworkTest::tearDown()
{
    Stub::Framework::reset();
}

