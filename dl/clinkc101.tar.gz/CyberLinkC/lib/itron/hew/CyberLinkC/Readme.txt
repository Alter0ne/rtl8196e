-------- PROJECT GENERATOR --------
PROJECT NAME :	CyberLinkC
PROJECT DIRECTORY :	C:\src\CyberLinkC\lib\itron\hew\CyberLinkC
CPU SERIES :	SH2-DSP
TOOLCHAIN NAME :	Hitachi SuperH RISC engine Standard Toolchain
TOOLCHAIN VERSION :	8.0.1.0

DATE & TIME : 2005/03/13 23:05:50
