#include <basic.h>
#include <bstdlib.h>
#include <bstdio.h>
#include <bstring.h>
#include <errcode.h>
#include <tstring.h>
#include <tcode.h>
#include <btron/btron.h>
#include <btron/dp.h>
#include <btron/hmi.h>
#include <btron/vobj.h>
#include <btron/libapp.h>
#include <bsyslog.h>
#include <typedef.h>
#include <net/sock_com.h>
#include <btron/bsocket.h>

//#define ASSERT(e)       ((e) ? (void)0 : syslog(LOG_DEBUG, "%s(%d) %s"__FILE__, __LINE__, #e))
#define ASSERT(e)       ((e) ? (void)0 : syslog(LOG_DEBUG, "%s(%d)"__FILE__, __LINE__))

//////////////////////////////////////////////////
// MAIN
//////////////////////////////////////////////////

extern "C" {
EXPORT W MAIN(MESSAGE *msg);
}

EXPORT W MAIN(MESSAGE *msg)
{
	setlogmask(LOG_UPTO(LOG_DEBUG));

	while (true) {
		slp_tsk(1000);
	}

	return 0;
}
