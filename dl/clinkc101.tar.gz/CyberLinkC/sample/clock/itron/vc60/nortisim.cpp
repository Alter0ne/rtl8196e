//---------------------------------------------------------------------------
// NORTi simulator GUI Main Entry
//
// File name : nortisim.cpp
// Copyright (c) 2003 MiSPO Co., Ltd.  All rights reserved.
//
// 01/Feb/2003 new Release                                            MiSPO
//---------------------------------------------------------------------------
#include <afxwin.h>
#include "nosimapi.h"

class CDlgMain;
class CDlgLed7Seg;
class CDlgSwBox8;

CDlgLed7Seg *gvdLed7Seg = 0;
CDlgSwBox8  *gvdSwBox8  = 0;

extern "C" NOSIMAPI CDlgMain* sim_create_mfc_dialog_main( void );
extern "C" NOSIMAPI CDlgLed7Seg* sim_create_mfc_dialog_led7seg( void );
extern "C" NOSIMAPI CDlgSwBox8* sim_create_mfc_dialog_swbox8( void );

extern "C" int simulation_main( void );
extern NOSIMAPI void *gpv_simulation_main;


class CAppSim : public CWinApp
{
public:
  virtual BOOL CAppSim::InitInstance()
  {
    gpv_simulation_main = simulation_main;

    m_pMainWnd = (CWnd *)sim_create_mfc_dialog_main();
    gvdLed7Seg = sim_create_mfc_dialog_led7seg();
    gvdSwBox8 = sim_create_mfc_dialog_swbox8();
    return( TRUE );
  }

}  theApp;
