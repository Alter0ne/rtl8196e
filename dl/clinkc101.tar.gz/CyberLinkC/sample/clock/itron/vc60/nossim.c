/******************************************************************************
* NORTiSIM �V���A�����o�̓h���C�o                                             *
*                                                                             *
*  File name : nos16550.c                                                     *
*  Copyright (c)  2003, MiSPO Co., Ltd.                                       *
*  All rights reserved.                                                       *
*                                                                             *
* 04/Feb/2003 Created                                                     k2x *
******************************************************************************/

#include <string.h>
#include "kernel.h"

#include "nosio.h"
#include "noswin.h"

#define IP          7

extern T_SIO SIO[];

/*****************************************************************************
* �V���A�������݃n���h����M�����i�����֐��j
*
******************************************************************************/

static void rx_int( INT ch )
{
  int tid;
  com_clr_imr_flag( ch, IMR_PRX );
 if ( (tid = SIO[ch].rxtid) != 0 )
   iwup_tsk(tid);
}


/*****************************************************************************
* �V���A�������݃n���h�����M�����i�����֐��j
*
******************************************************************************/

static void tx_int( INT ch )
{
  int tid;
  com_clr_imr_flag( ch, IMR_PTX|IMR_TXF );
  if ( (tid = SIO[ch].tetid) != 0 )
    iwup_tsk(tid);          /* ���M�I���҂����� */
  if ( (tid = SIO[ch].txtid) != 0)
    iwup_tsk(tid);          /* ���M�҂����� */
}

/*****************************************************************************
* �V���A�������݃n���h���{�́i�����֐��j
*
******************************************************************************/

static void int_sio_body( INT ch )
{
  UINT isrf;
  com_dis_int( ch );
  rx_int( ch );
  tx_int( ch );
  com_ena_int( ch );
}

/*****************************************************************************
* �V���A�������݃n���h��
*
******************************************************************************/

INTHDR int_sio0(void)  {  ent_int();  int_sio_body(0);  ret_int();  }
#if ( chS > 1 )
INTHDR int_sio1(void)  {  ent_int();  int_sio_body(1);  ret_int();  }
#endif
#if ( chS > 2 )
INTHDR int_sio2(void)  {  ent_int();  int_sio_body(2);  ret_int();  }
#endif
#if ( chS > 3 )
INTHDR int_sio3(void)  {  ent_int();  int_sio_body(3);  ret_int();  }
#endif
#if ( chS > 4 )
INTHDR int_sio4(void)  {  ent_int();  int_sio_body(4);  ret_int();  }
#endif
#if ( chS > 5 )
INTHDR int_sio5(void)  {  ent_int();  int_sio_body(5);  ret_int();  }
#endif
#if ( chS > 6 )
INTHDR int_sio6(void)  {  ent_int();  int_sio_body(6);  ret_int();  }
#endif
#if ( chS > 7 )
INTHDR int_sio7(void)  {  ent_int();  int_sio_body(7);  ret_int();  }
#endif

static const T_DINH dinh_sios[] = {
  {  TA_HLNG, int_sio0, IP  }
#if ( chS > 1 )
 ,{  TA_HLNG, int_sio1, IP  }
#endif
#if ( chS > 2 )
 ,{  TA_HLNG, int_sio2, IP  }
#endif
#if ( chS > 3 )
 ,{  TA_HLNG, int_sio3, IP  }
#endif
#if ( chS > 4 )
 ,{  TA_HLNG, int_sio4, IP  }
#endif
#if ( chS > 5 )
 ,{  TA_HLNG, int_sio5, IP  }
#endif
#if ( chS > 6 )
 ,{  TA_HLNG, int_sio6, IP  }
#endif
#if ( chS > 7 )
 ,{  TA_HLNG, int_sio7, IP  }
#endif
};

/*****************************************************************************
* �������p�����[�^��́i�����֐��j
*
******************************************************************************/

static BOOL mod_param( DCB *pdcb, const char *cs )
{
  char c, *s, *sTok;
  UB y;
  s = strdup( cs );
  strupr( s );
  for ( sTok = strtok( s, " " ); sTok; sTok = strtok( 0, " " ) )
  {
    /* Baud-Rate */
    c = *sTok;
    if ( (c >= '1')&&(c <= '9') )
    {
      UINT dBR = strtoul( sTok, 0, 0 );
      DWORD dwBR;
      switch ( dBR )
      {
        case 110:  dwBR = CBR_110;  break;
        case 300:  dwBR = CBR_300;  break;
        case 600:  dwBR = CBR_600;  break;
        case 1200:  dwBR = CBR_1200;  break;
        case 2400:  dwBR = CBR_2400;  break;
        case 4800:  dwBR = CBR_4800;  break;
        case 9600:  dwBR = CBR_9600;  break;
        case 14400:  dwBR = CBR_14400;  break;
        case 19200:  dwBR = CBR_19200;  break;
        case 38400:  dwBR = CBR_38400;  break;
        case 56000:  dwBR = CBR_56000;  break;
        case 57600:  dwBR = CBR_57600;  break;
        case 115200:  dwBR = CBR_115200;  break;
        case 128000:  dwBR = CBR_128000;  break;
        case 256000:  dwBR = CBR_256000;  break;
        default:  return( FALSE );
      }
      pdcb->BaudRate = dwBR;
    }

    c = *(sTok +1);
    switch ( *sTok )
    {
      case 'B':  /* Character-Length */
        if ( (c < '4')||(c > '8') )  return( FALSE );
        pdcb->ByteSize = (UB)(c - '4') +4;
        break;

      case 'P':  /* Parity */
        switch ( c )
        {
          case 'N':  y = NOPARITY;  break;  // no
          case 'O':  y = ODDPARITY;  break;  // odd
          case 'E':  y = EVENPARITY;  break;  // even
          case 'M':  y = MARKPARITY;  break;  // mark
          case 'S':  y = SPACEPARITY;  break;  // space
          default:   return( FALSE );
        }
        pdcb->Parity = y;
        pdcb->fParity = y  ?  TRUE : FALSE;
        break;

      case 'S':  /* Sop-Bits */
        switch ( c )
        {
          case '1':
            if ( ! strcmp( (sTok +1), "1.5" ) )
              y = ONE5STOPBITS;
            else  y = ONESTOPBIT;
            break;

          case '2':  y = TWOSTOPBITS;  break;
          default:   return( FALSE );
        }
        pdcb->StopBits = y;
        break;

      default:  ;
    }
  }

  /* About Flow-Control */
  if ( strstr( cs, "XON" ) )  pdcb->fOutX = pdcb->fInX = TRUE;
  if ( strstr( cs, "DTR" ) )  pdcb->fDtrControl = DTR_CONTROL_HANDSHAKE;
  if ( strstr( cs, "RTS" ) )  pdcb->fRtsControl = RTS_CONTROL_HANDSHAKE;
  return( TRUE );
}

/*****************************************************************************
* �V���A�����o�͏�����
*
* Sim.�ł́A�����Ń|�[�g���I�[�v������葱�����s���B
* ch: 0 1 2..., COM(Win): 1 2 3 ...
*
* ! �t���[����ɂ��āD�D�D(Sep-02)
*   param of nosio  |  Member of DCB
*         XON       |  fOutX & fInX
*         DTR       |  fDtrControl  (on:HANDSHAKE, off:DISABLE)
*         RTS       |  fRtsControl  (on:HANDSHAKE, off:DISABLE)
*   // DCB�ɂ͑��ɂ���R�̃t���[����Ɋւ��郁���o�[������B
*   // ���݁A��L�Ɏ��������o�[�̂��������B
*
******************************************************************************/

ER ini_sio_com(INT ch, const B *param)
{
  DCB *pdcb;
  if ( ! com_setup( ch ) )  return( -1 );

  /* �悸�A"nosio"����߂�f�t�H���g�l���Z�b�g�D�D�DRefer to "nosio.txt" */
  /* DEFAULT: "9600 B8 PN S1" <No-FlowCtrl> */
    pdcb = com_inq_dcb( ch );
    pdcb->BaudRate = CBR_9600;
    pdcb->ByteSize = 8;
    pdcb->Parity = NOPARITY;
    pdcb->fParity = FALSE;
    pdcb->StopBits = ONESTOPBIT;
    pdcb->fOutX = pdcb->fInX = FALSE;
    pdcb->fDtrControl = DTR_CONTROL_DISABLE;
    pdcb->fRtsControl = RTS_CONTROL_DISABLE;

  if ( ! mod_param( pdcb, param ) )  return E_PAR;
  com_mod_dcb( ch );


  /* �����݃n���h���̒�` */

    if (!(SIO[ch].flag & TSF_INIT))
        def_inh( INT_SIO( ch ), &dinh_sios[ch] );

    SIO[ch].flag |= TSF_INIT;       /* �������ς݃Z�b�g */
    com_ena_int( ch );
    return E_OK;
}


/*****************************************************************************
* �V���A�����o�͏I��
*
******************************************************************************/

void ext_sio_com( INT ch )
{
    com_dis_int( ch );
    if (!(SIO[ch].flag & TSF_INIT))     /* ���������Ȃ牽�����Ȃ� */
        return;

    /* �����ݒ�`�������� */

    def_inh( INT_SIO( ch ), (T_DINH *)NADR);
    SIO[ch].flag &= ~TSF_INIT;          /* �������ς݃t���O�N���A */
    
  com_cleanup( ch );
}


/*****************************************************************************
* �V���A���P��������
*
******************************************************************************/


ER get_sio_com( INT ch, UB *c, TMO tmout)
{
    ER err;
    INT sts;

    for (;;)
    {
        /* ��M�o�b�t�@����P�������� */

        sts = com_read_char( ch, c );

        if ( sts )   /*�b��*//* ��M�����������ꍇ */
        {
            /* ��M�G���[���� */
            err = E_OK;
            return err;
        }

        /* ��M�����ݑ҂� */

        SIO[ch].rxtid = vget_tid();
        com_dis_int( ch );
        com_set_imr_flag( ch, IMR_PRX );
        com_ena_int( ch );
        err = tslp_tsk(tmout);
        SIO[ch].rxtid = 0;
        vcan_wup();                 /* ������ iwup_tsk ���ꂽ�ꍇ�̑΍� */
        if (err)
            return err;             /* �^�C���A�E�g�I�� */
    }
}


/*****************************************************************************
* �V���A���P�����o��
*
******************************************************************************/

ER put_sio_com( INT ch, UB c, TMO tmout)
{
    ER err;

    for (;;)
    {
        /* ���M�o�b�t�@�ւP�����i�[ */

        if ( com_write_char( ch, c ) )           /* ���M�ł����ꍇ */
            return E_OK;            /* ����I�� */

        /* ���M�����ݑ҂� */
        
        SIO[ch].txtid = vget_tid();
        com_dis_int( ch );
        com_set_imr_flag( ch, IMR_PTX );
        com_ena_int( ch );
        err = tslp_tsk(tmout);
        SIO[ch].txtid = 0;
        vcan_wup();                 /* ������ iwup_tsk ���ꂽ�ꍇ�̑΍� */
        if (err)
            return err;             /* �^�C���A�E�g�I�� */
    }
}


/*****************************************************************************
* �V���A�����o�͐���
*
* ! Sim.
*   TSIO_RXE, RXD,       // �~: CreateFile��R/W�������g���D�D�D�H
*        TXE, TXD        //     �I�[�v���������K�v������B
*   TSIO_RTSON, RTSOFF,  // ��: ini_sio�ŁA"DTR","RTS" �t���[����w��̏ꍇ�A
*        DTRON, DTROFF   //     �G���[�ƂȂ�B
*   TSIO_RXCLR, TXCLR    // ��:
*   TSIO_SBON, SBOFF     // ��: ���M��ؒf��Ԃɂ��邩�ǂ����Ƃ������ƂȂ�
*
******************************************************************************/

ER ctl_sio_com(INT ch, UH fncd)
{
    if ( fncd & TSIO_RTSON )   com_control_rts( ch, TRUE );
    if ( fncd & TSIO_RTSOFF )  com_control_rts( ch, FALSE );
    if ( fncd & TSIO_DTRON )   com_control_dtr( ch, TRUE );
    if ( fncd & TSIO_DTROFF )  com_control_dtr( ch, FALSE );
    if ( fncd & TSIO_RXCLR )   com_purge( ch, PURGE_RXCLEAR );
    if ( fncd & TSIO_TXCLR )   com_purge( ch, PURGE_TXCLEAR );
    if ( fncd & TSIO_SBON )    com_break_tx( ch, TRUE );
    if ( fncd & TSIO_SBOFF )   com_break_tx( ch, FALSE );
    return E_OK;
}


/*****************************************************************************
* �V���A�����o�͏�ԎQ��
*
* ! Sim.
*   T_SIOS::siostat
*           TSIO_CD, CTS, DSR    // �� :
*           TSIO_TXEMP           // �� :
*           TSIO_PE, OE, FE, BD  // �� :
*         ::rxchr                // �~ : Always Zero, DD-Level
*         ::rxlen                // �� :
*         ::frbufsz              // �� :
*         ::eotcnt               // �~ : Always Zero, DD-Level
*
******************************************************************************/

ER ref_sio_com(INT ch, T_SIOS *pk_sios)
{
    UB stat;
    const COMSTAT *cpcs;
    const COMMPROP *cpcp;
    UINT derr;
    
    com_ren_status( ch );
    cpcs = com_ref_status( ch );
    cpcp = com_inq_properties( ch );
    derr = com_get_errors( ch );
    stat = 0x00;
    if ( cpcs->fRlsdHold )  stat |= TSIO_CD;
    if ( cpcs->fCtsHold )   stat |= TSIO_CTS;
    if ( cpcs->fDsrHold )   stat |= TSIO_DSR;
    if ( cpcs->cbOutQue == 0 )  stat |= TSIO_TXEMP;
    if ( derr & CE_RXPARITY )  stat |= TSIO_PE;
    if ( derr & CE_OVERRUN )   stat |= TSIO_OE;
    if ( derr & CE_FRAME )     stat |= TSIO_FE;
    if ( derr & CE_BREAK )     stat |= TSIO_BD;
    pk_sios->siostat = stat;
    pk_sios->rxchr   = 0x00;
    pk_sios->rxlen   = (UH)cpcs->cbInQue;
    pk_sios->frbufsz = (UH)(cpcp->dwCurrentTxQueue -cpcs->cbOutQue );
    pk_sios->eotcnt  = 0x00;

    return E_OK;
}

/*****************************************************************************
* �V���A�����M�o�b�t�@��t���b�V��
*
******************************************************************************/

ER fls_sio_com(INT ch, TMO tmout)
{
    ER err;

    SIO[ch].tetid = vget_tid();
    com_dis_int( ch );
    com_set_imr_flag( ch, IMR_TXF );
    com_ena_int( ch );
    err = tslp_tsk(tmout);
    SIO[ch].tetid = 0;
    vcan_wup();                     /* ������ iwup_tsk ���ꂽ�ꍇ�̑΍� */
    return err;                     /* �^�C���A�E�g�I�� */
}

/* ---- */
ER ini_sio0(const B *param)   {  return( ini_sio_com( 0, param ) );  }
ER get_sio0(UB *c, TMO tmout) {  return( get_sio_com( 0, c, tmout ) );  }
void ext_sio0( void )         {  ext_sio_com( 0 );  }
ER put_sio0(UB c, TMO tmout)  {  return( put_sio_com( 0, c, tmout ) );  }
ER ctl_sio0(UH fncd)          {  return( ctl_sio_com( 0, fncd ) );  }
ER ref_sio0(T_SIOS *pk_sios)  {  return( ref_sio_com( 0, pk_sios ) );  }
ER fls_sio0(TMO tmout)        {  return ( fls_sio_com( 0, tmout ) );  }
#if ( CHS > 1 )
ER ini_sio1(const B *param)   {  return( ini_sio_com( 1, param ) );  }
ER get_sio1(UB *c, TMO tmout) {  return( get_sio_com( 1, c, tmout ) );  }
void ext_sio1( void )         {  ext_sio_com( 0 );  }
ER put_sio1(UB c, TMO tmout)  {  return( put_sio_com( 1, c, tmout ) );  }
ER ctl_sio1(UH fncd)          {  return( ctl_sio_com( 1, fncd ) );  }
ER ref_sio1(T_SIOS *pk_sios)  {  return( ref_sio_com( 1, pk_sios ) );  }
ER fls_sio1(TMO tmout)        {  return ( fls_sio_com( 1, tmout ) );  }
#endif
#if ( CHS > 2 )
ER ini_sio2(const B *param)   {  return( ini_sio_com( 2, param ) );  }
ER get_sio2(UB *c, TMO tmout) {  return( get_sio_com( 2, c, tmout ) );  }
void ext_sio2( void )         {  ext_sio_com( 0 );  }
ER put_sio2(UB c, TMO tmout)  {  return( put_sio_com( 2, c, tmout ) );  }
ER ctl_sio2(UH fncd)          {  return( ctl_sio_com( 2, fncd ) );  }
ER ref_sio2(T_SIOS *pk_sios)  {  return( ref_sio_com( 2, pk_sios ) );  }
ER fls_sio2(TMO tmout)        {  return ( fls_sio_com( 2, tmout ) );  }
#endif
#if ( CHS > 3 )
ER ini_sio3(const B *param)   {  return( ini_sio_com( 3, param ) );  }
ER get_sio3(UB *c, TMO tmout) {  return( get_sio_com( 3, c, tmout ) );  }
void ext_sio3( void )         {  ext_sio_com( 0 );  }
ER put_sio3(UB c, TMO tmout)  {  return( put_sio_com( 3, c, tmout ) );  }
ER ctl_sio3(UH fncd)          {  return( ctl_sio_com( 3, fncd ) );  }
ER ref_sio3(T_SIOS *pk_sios)  {  return( ref_sio_com( 3, pk_sios ) );  }
ER fls_sio3(TMO tmout)        {  return ( fls_sio_com( 3, tmout ) );  }
#endif
#if ( CHS > 4 )
ER ini_sio4(const B *param)   {  return( ini_sio_com( 4, param ) );  }
ER get_sio4(UB *c, TMO tmout) {  return( get_sio_com( 4, c, tmout ) );  }
void ext_sio4( void )         {  ext_sio_com( 4 );  }
ER put_sio4(UB c, TMO tmout)  {  return( put_sio_com( 4, c, tmout ) );  }
ER ctl_sio4(UH fncd)          {  return( ctl_sio_com( 4, fncd ) );  }
ER ref_sio4(T_SIOS *pk_sios)  {  return( ref_sio_com( 4, pk_sios ) );  }
ER fls_sio4(TMO tmout)        {  return ( fls_sio_com( 4, tmout ) );  }
#endif
#if ( CHS > 5 )
ER ini_sio5(const B *param)   {  return( ini_sio_com( 5, param ) );  }
ER get_sio5(UB *c, TMO tmout) {  return( get_sio_com( 5, c, tmout ) );  }
void ext_sio5( void )         {  ext_sio_com( 5 );  }
ER put_sio5(UB c, TMO tmout)  {  return( put_sio_com( 5, c, tmout ) );  }
ER ctl_sio5(UH fncd)          {  return( ctl_sio_com( 5, fncd ) );  }
ER ref_sio5(T_SIOS *pk_sios)  {  return( ref_sio_com( 5, pk_sios ) );  }
ER fls_sio5(TMO tmout)        {  return ( fls_sio_com( 5, tmout ) );  }
#endif
#if ( CHS > 6 )
ER ini_sio6(const B *param)   {  return( ini_sio_com( 6, param ) );  }
ER get_sio6(UB *c, TMO tmout) {  return( get_sio_com( 6, c, tmout ) );  }
void ext_sio6( void )         {  ext_sio_com( 6 );  }
ER put_sio6(UB c, TMO tmout)  {  return( put_sio_com( 6, c, tmout ) );  }
ER ctl_sio6(UH fncd)          {  return( ctl_sio_com( 6, fncd ) );  }
ER ref_sio6(T_SIOS *pk_sios)  {  return( ref_sio_com( 6, pk_sios ) );  }
ER fls_sio6(TMO tmout)        {  return ( fls_sio_com( 6, tmout ) );  }
#endif
#if ( CHS > 7 )
ER ini_sio7(const B *param)   {  return( ini_sio_com( 7, param ) );  }
ER get_sio7(UB *c, TMO tmout) {  return( get_sio_com( 7, c, tmout ) );  }
void ext_sio7( void )         {  ext_sio_com( 7 );  }
ER put_sio7(UB c, TMO tmout)  {  return( put_sio_com( 7, c, tmout ) );  }
ER ctl_sio7(UH fncd)          {  return( ctl_sio_com( 7, fncd ) );  }
ER ref_sio7(T_SIOS *pk_sios)  {  return( ref_sio_com( 7, pk_sios ) );  }
ER fls_sio7(TMO tmout)        {  return ( fls_sio_com( 7, tmout ) );  }
#endif



/* end */
