/******************************************************************************
* NORTi  Network LAN Controller Dependecies                                   *
* for NORTiSIM (Windows)                                                      *
*                                                                             *
*  File name : nonethw.c                                                      *
*  Copyright (c)  2003, MiSPO Co., Ltd.                                       *
*  All rights reserved.                                                       *
*                                                                             *
* 30/Jan/2003 Created                                                     k2x *
******************************************************************************/

#include "norti3.h"
#include "nonet.h"
#include "nonets.h"

#include "nosimapi.h"
#include "nonwin.h"

/*****************************************************************************
*
* Interrupt handler for LAN controller
*
******************************************************************************/

INTHDR lan_int(void)
{
    ent_int();
    lan_intr();
    ret_int();
}  const T_DINT dint_lan = { TA_HLNG, lan_int };

