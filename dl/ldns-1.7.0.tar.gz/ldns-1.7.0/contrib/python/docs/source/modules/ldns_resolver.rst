Class ldns_resolver
================================

..	automodule:: ldns

Class ldns_resolver
------------------------------
.. autoclass:: ldns_resolver
	:members:
	:undoc-members:



