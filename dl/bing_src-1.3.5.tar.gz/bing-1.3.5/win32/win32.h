/* $Id: win32.h,v 1.3 1999/10/11 05:25:19 fgouget Exp $ */

#ifndef bing_win32_h_
#define bing_win32_h_

#define WIN32_LEAN_AND_MEAN
#define NOSERVICE
#define NOMCX
#define NOIME
#include <windows.h>

#endif	/* End of File */
