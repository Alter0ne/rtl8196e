/*	$OpenBSD: pathnames.h,v 1.1 2012/06/18 07:14:55 jasper Exp $	*/

/* This file is in the public domain. */

/*
 *	standard path names
 */

#define	_PATH_MG_DIR		"~/.mg.d"
#define	_PATH_MG_STARTUP	"%s/.mg"
#define	_PATH_MG_TERM		"%s/.mg-%s"
