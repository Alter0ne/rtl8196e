/*
 * NetBSD-specific support.
 */

#include <time.h>
