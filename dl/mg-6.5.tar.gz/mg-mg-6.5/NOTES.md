NOTES

* On some Linux distributions, the backspace key doesn't work
  correctly. This can be fixed with `bsmap-mode`; this should probably
  be placed in the user's `$HOME/.mg` file.
