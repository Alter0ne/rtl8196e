/*
 * FreeBSD-specific support.
 */

#include <sys/param.h>
#include <time.h>
