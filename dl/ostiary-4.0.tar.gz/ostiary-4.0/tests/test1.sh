#!/bin/sh

echo "Test1 run," $1 >> /tmp/ostiary/ostcmds.log
echo `date` >> /tmp/ostiary/ostcmds.log
