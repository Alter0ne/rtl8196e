# Defaults for ostiary initscript
# sourced by /etc/init.d/ostiary
# installed at /etc/default/ostiary by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
