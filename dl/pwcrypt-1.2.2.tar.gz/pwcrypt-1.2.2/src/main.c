/* 
   crypt -- take a soon-to-be password from the command line, and output
	    it in it's crypted form.  This is probably not the best
	    implementation ever done. :)

   Copyright (C) 2000 A.L.Lambert.
   
   Version 1.1 by Joachim Fenkes <dojoe@gmx.net> - added MD5 support.
   Version 1.2 - fixes a bug introduced by A.L.Lambert in the argv[] handling.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  
*/


#include "include.h"

/* yee ole main; short and sweet */
int main(int argc, char **argv) {
	/* note: in the functions below which are checked for errors, it is
	 * assumed that the called function prints any error the user, not the
	 * calling function (ie: we don't bother reporting errors here :) */
	
	/* get our options and such - if not return 1 */
	if(cr_getopt(argc, argv) == -1) return 1;
	/* get some randomness - if not return 2 */
	if(cr_random() == -1) return 2;
	/* crypt the password - if not return 3 */
	if(cr_crypt() == -1) return 3;

	/* if we made it this far, print out the password */
	printf("%s", encrypted_pass);	
	/* return no error */
	return (0);
	/* all done :) */
}


