/*
 * WARNING/NOTE/PAY ATTENTION: edit config.h.in and re-run ./configure! 
 * If you edit config.h directly, it will get overwritten next time you
 * have to run configure, and you will be sad!!!
 */

#define VERSION		"1.2.2"
