/* 
   crypt -- take a soon-to-be password from the command line, and output
	    it in it's crypted form.  This is probably not the best
	    implementation ever done. :)

   Copyright (C) 2000 A.L.Lambert.
   
   Version 1.1 by Joachim Fenkes <dojoe@gmx.net> - added MD5 support.
   Version 1.2 - fixes a bug introduced by A.L.Lambert in the argv[] handling.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  
*/

/* first, include our ./configure generated config */
#include "../config.h"

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<crypt.h>

#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


/* ugly ifdef hack for systems that don't include getopt.h */
#ifdef HAVE_GETOPT_H
  #include<getopt.h>
#else
  #include "../missing/getopt.h"
#endif

/* our local include */
#include "cli-crypt.h"
#include "config.h"
