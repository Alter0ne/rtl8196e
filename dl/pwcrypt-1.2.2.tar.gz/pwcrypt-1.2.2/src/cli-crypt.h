/* 
   crypt -- take a soon-to-be password from the command line, and output
	    it in it's crypted form.  This is probably not the best
	    implementation ever done. :)

   Copyright (C) 2000 A.L.Lambert.
   
   Version 1.1 by Joachim Fenkes <dojoe@gmx.net> - added MD5 support.
   Version 1.2 - fixes a bug introduced by A.L.Lambert in the argv[] handling.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  
*/

/* our #define's and such */
#define LSIZE	1024	/* our standard buffer size for static memory */

/* our global variables */
char cleartext_pass[LSIZE];	/* where do we store the initial cleartext of the password */
char encrypted_pass[LSIZE];	/* where we stuff our password once it's encrypted */
char salt_src[LSIZE];		/* a place we can store text to scramble to get our salt */
char salt[LSIZE];		/* the actual salt we end up with using in our call to crypt(); */

/* flags we use to determine how we're doing things */
short int md5;		/* we doing md5 passwords */
short int quiet;	/* are we to be quiet */
short int debug;	/* do we print debug info? */
short int do_salt;	/* do we need to provide a salt? */


/* from main.c */
int main(int argc, char **argv);

/* from getopt.c */
short int cr_getopt(int argc, char **argv);

/* from random.c */
short int cr_random();

/* from crypt.c */
short int cr_crypt();
