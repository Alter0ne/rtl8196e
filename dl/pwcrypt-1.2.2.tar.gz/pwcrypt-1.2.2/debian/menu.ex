?package(cli-crypt):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="cli-crypt" command="/usr/bin/cli-crypt"
