#:OTHER:
cli-crypt	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/cli-crypt
