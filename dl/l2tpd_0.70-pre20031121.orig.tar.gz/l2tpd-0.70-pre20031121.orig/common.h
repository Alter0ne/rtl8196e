/*
 * $Id$
 *
 * Layer 2 Tunnelling Protocol Daemon
 * Copyright (C) 2002 Jeff McAdams
 *
 * This software is distributed under the terms of the GPL, which you
 * should have receivede along with this source.
 *
 * Defines common to several different files
 */

#ifndef _COMMON_H_
typedef unsigned short _u16;
typedef unsigned long long _u64;
int rand_source;
#define _COMMON_H_
#endif
