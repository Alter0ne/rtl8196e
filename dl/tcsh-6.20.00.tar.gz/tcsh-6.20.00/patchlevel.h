/* $Header: /p/tcsh/cvsroot/tcsh/patchlevel.h,v 3.187 2016/11/24 15:04:52 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 20
#define PATCHLEVEL 00
#define DATE "2016-11-24"

#endif /* _h_patchlevel */
