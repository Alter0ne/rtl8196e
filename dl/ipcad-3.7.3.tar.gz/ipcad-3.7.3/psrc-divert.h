#ifndef	__PSRC_DIVERT__
#define	__PSRC_DIVERT__

int init_packet_source_divert(packet_source_t *ps);

void *process_divert(void *);

void print_stats_divert(FILE *, packet_source_t *ps);

#endif	/* __PSRC_DIVERT__ */
