/* A Bison parser, made from cshell.y, by GNU bison 1.75.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_STRING = 258,
     ERROR = 259,
     C_DUMP = 260,
     C_IMPORT = 261,
     C_RESTORE = 262,
     C_IP = 263,
     C_ACCOUNTING = 264,
     C_SHOW = 265,
     C_CHECKPOINT = 266,
     C_CLEAR = 267,
     C_STAT = 268,
     C_HELP = 269,
     C_SHUTDOWN = 270,
     C_INTERFACE = 271,
     C_VERSION = 272,
     C_CACHE = 273,
     C_FLOW = 274
   };
#endif
#define TOK_STRING 258
#define ERROR 259
#define C_DUMP 260
#define C_IMPORT 261
#define C_RESTORE 262
#define C_IP 263
#define C_ACCOUNTING 264
#define C_SHOW 265
#define C_CHECKPOINT 266
#define C_CLEAR 267
#define C_STAT 268
#define C_HELP 269
#define C_SHUTDOWN 270
#define C_INTERFACE 271
#define C_VERSION 272
#define C_CACHE 273
#define C_FLOW 274




#ifndef YYSTYPE
#line 19 "cshell.y"
typedef union {
	int tv_int;
	char *tv_char;
} yystype;
/* Line 1281 of /usr/local/share/bison/yacc.c.  */
#line 83 "y.tab.h"
# define YYSTYPE yystype
#endif

extern YYSTYPE CSlval;


#endif /* not BISON_Y_TAB_H */

