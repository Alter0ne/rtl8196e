#ifndef	__PSRC_IPQ__
#define	__PSRC_IPQ__

int init_packet_source_ipq(packet_source_t *ps, int retry_mode);

void *process_ipq(void *);

void print_stats_ipq(FILE *, packet_source_t *ps);

#endif	/* __PSRC_IPQ__ */
