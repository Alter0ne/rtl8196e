#ifndef	__PSRC_FILE__
#define	__PSRC_FILE__

int init_packet_source_file(packet_source_t *ps);

void *process_file(void *);

void print_stats_file(FILE *, packet_source_t *ps);

#endif	/* __PSRC_FILE__ */
