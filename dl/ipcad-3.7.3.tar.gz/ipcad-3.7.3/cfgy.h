typedef union {
	int tv_int;
	char *tv_char;
	struct in_addr tv_ip;
	struct { 
		int is_ip_aggr;
		char *s1;
		char *s2;
		char *s3;
	} tv_aggr;
} YYSTYPE;
#define	TOK_STRING	257
#define	TOK_INTEGER	258
#define	ERROR	259
#define	EQ	260
#define	AT	261
#define	SEMICOLON	262
#define	SLASH	263
#define	IFACE	264
#define	IFILE	265
#define	IPQ	266
#define	ULOG	267
#define	GROUP	268
#define	DIVERT	269
#define	TEE	270
#define	PORT	271
#define	INONLY	272
#define	PROMISC	273
#define	NETFLOW_SAMPLED	274
#define	NETFLOW_DISABLE	275
#define	FILTER	276
#define	CAPTURE_PORTS	277
#define	MEMSIZE	278
#define	BUFFERS	279
#define	RSH	280
#define	DUMP	281
#define	CHROOT	282
#define	UID	283
#define	GID	284
#define	AGGR	285
#define	STRIP	286
#define	INTO	287
#define	DENY	288
#define	ALLOW	289
#define	TIMEOUT	290
#define	TTL	291
#define	PIDFILE	292
#define	ADMIN	293
#define	BACKUP	294
#define	DEFAULT	295
#define	VIEW_ONLY	296
#define	NETFLOW	297
#define	EXPORT	298
#define	DESTINATION	299
#define	VERSION	300
#define	ACTIVE	301
#define	INACTIVE	302
#define	ENGINE_TYPE	303
#define	ENGINE_ID	304
#define	SAMPLING_MODE	305
#define	PACKET_INTERVAL	306
#define	IFCLASS	307
#define	MAPTO	308


extern YYSTYPE ipcacfglval;
