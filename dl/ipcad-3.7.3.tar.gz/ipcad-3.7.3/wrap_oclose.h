#ifndef	__WRAP_OCLOSE_H__
#define	__WRAP_OCLOSE_H__

extern pthread_mutex_t fd_pool_mutex;

#endif	/* __WRAP_OCLOSE_H__ */
