#ifndef	__IFS_LIST_H__
#define	__IFS_LIST_H__

#include "sf_lite.h"

svect *get_interface_names(void);

#endif	/* __IFS_LIST_H__ */
