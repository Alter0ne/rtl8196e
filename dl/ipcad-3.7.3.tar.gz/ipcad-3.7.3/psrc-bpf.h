#ifndef	__PSRC_BPF__
#define	__PSRC_BPF__

int init_packet_source_bpf(packet_source_t *ps, int retry_mode);

void *process_bpf(void *);

void print_stats_bpf(FILE *, packet_source_t *ps);

#endif	/* __PSRC_BPF__ */
