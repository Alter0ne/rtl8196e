#ifndef	__PSRC_ULOG__
#define	__PSRC_ULOG__

int init_packet_source_ulog(packet_source_t *ps, int retry_mode);

void *process_ulog(void *);

void print_stats_ulog(FILE *, packet_source_t *ps);

#endif	/* __PSRC_ULOG__ */
