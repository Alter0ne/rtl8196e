In this directory you can 
build the installer with
the nsis compiler.

First, run nsis20.exe to install
the compiler, templates and all
the required building tools.

Files required by tspc:

"tspc.exe"
"tspc.conf"
"README-WINDOWS.txt"
"template\windows.bat"
"template\win-ver.exe"
"GPL_LICENSE.txt"
"tunv6\tunv6.sys"
"tunv6\tunv6.inf"
"tunv6\devcon.exe"

I use the graphical nsis
interface and just drag
and drop tspc.nsi to it.

This generate an executable
which is the installer itself.

