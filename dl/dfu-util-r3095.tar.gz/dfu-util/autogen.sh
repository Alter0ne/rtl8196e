#! /bin/sh
AUTOMAKE="automake --foreign --add-missing --copy"
export AUTOMAKE
autoreconf
