/* pcre_config.h, created to embed PCRE in bahamut */

#include "setup.h"

#define EBCDIC 0
#define EXPORT
#define NEWLINE '\n'
#define LINK_SIZE   2
#define POSIX_MALLOC_THRESHOLD 10
#define MATCH_LIMIT 1000

