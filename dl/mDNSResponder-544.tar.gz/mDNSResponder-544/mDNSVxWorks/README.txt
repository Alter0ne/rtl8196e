These are the platform support files for running mDNSCore on VxWorks.

Please note, most of the developers working on the mDNSResponder code do
not have access to a VxWorks development environment, so they are not able
to personally verify that the VxWorks compiles and runs successfully after
every single change to the mDNSCore code. We do try to take care not to
make careless changes that would break the VxWorks build, but if you do
find that something is broken, let us know and we'll fix it.
