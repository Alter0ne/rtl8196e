int base64_decode(char* in, char* out);
