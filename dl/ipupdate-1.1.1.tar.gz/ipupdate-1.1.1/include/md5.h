void md5(char*, char*, int);
void hmac_md5(char*, int, char*, int, char[16]);
