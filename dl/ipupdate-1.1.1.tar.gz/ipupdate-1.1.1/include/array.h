#include <string.h>
#include <stdlib.h>

char** split(char*, const char*, int*);
int splice(void**, int, int, int);
