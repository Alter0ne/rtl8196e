#include <windows.h>
#include <stdio.h>

int ipc_read(char*,char*,int);
