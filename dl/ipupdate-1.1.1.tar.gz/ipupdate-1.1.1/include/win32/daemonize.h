#include <windows.h>
#include <io.h>

#define STDIN  0
#define STDOUT 1
#define STDERR 2

int daemonize(void);
