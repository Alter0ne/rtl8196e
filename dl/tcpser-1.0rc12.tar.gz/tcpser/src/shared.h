#ifndef SHARED_H
#define SHARED_H 1

int sh_init_config(modem_config *cfg);

#endif

