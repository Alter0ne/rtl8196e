/* $Id: unsupported.c,v 1.2 2003/02/23 17:26:02 hscholz Exp $ */

/******************************************************************************
 *
 * get_stat()
 *
 * stub function for all unsupported operating systems
 *
 *****************************************************************************/

int get_stat(void)
{
    return 0;
}
