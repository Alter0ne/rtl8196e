#ifndef _HPUX_H_
#define _HPUX_H_
extern int checkinterface(void);
extern int get_stat(void);
#endif
