#ifndef __OSCAR_BOS_H__
#define __OSCAR_BOS_H__

#define AIM_CB_FAM_BOS 0x0009

/*
 * SNAC Family: Misc BOS Services.
 */ 
#define AIM_CB_BOS_ERROR 0x0001
#define AIM_CB_BOS_RIGHTSQUERY 0x0002
#define AIM_CB_BOS_RIGHTS 0x0003
#define AIM_CB_BOS_DEFAULT 0xffff

#endif /* __OSCAR_BOS_H__ */
