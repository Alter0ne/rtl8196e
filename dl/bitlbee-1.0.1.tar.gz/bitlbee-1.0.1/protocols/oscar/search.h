#ifndef __OSCAR_SEARCH_H__
#define __OSCAR_SEARCH_H__

int aim_usersearch_address(aim_session_t *, aim_conn_t *, const char *);

#endif /* __OSCAR_SEARCH_H__ */
