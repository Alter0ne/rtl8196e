#ifndef _NDYNDNS_H_
#define _NDYNDNS_H_

void cfg_set_pidfile(char *pidfname);
void cfg_set_user(char *username);
void cfg_set_group(char *groupname);
void cfg_set_interface(char *interface);

#endif /* _NDYNDNS_H_ */
