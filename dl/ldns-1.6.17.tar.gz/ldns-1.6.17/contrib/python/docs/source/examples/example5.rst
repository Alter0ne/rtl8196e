Examine the results
===============================

This example shows how to go through the obtained results

.. literalinclude:: ../../../examples/ldns-mx2.py
   :language: python

This snippet of code prints::

   nic.cz.   1761   IN   MX   20 mx.cznic.org.
   nic.cz.   1761   IN   MX   10 mail.nic.cz.
   nic.cz.   1761   IN   MX   15 mail4.nic.cz.

