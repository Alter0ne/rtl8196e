#!/bin/sh

set -e

export DOCDIR="./doxygen-output"

rm -rf $DOCDIR
