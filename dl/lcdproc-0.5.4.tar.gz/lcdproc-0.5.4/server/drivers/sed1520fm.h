#ifndef SED1520FM_H
#define SED1520FM_H

unsigned char fontmap[256][8];
unsigned char *fontbignum[10][24];
unsigned char *fontbigdp[24];

#endif
