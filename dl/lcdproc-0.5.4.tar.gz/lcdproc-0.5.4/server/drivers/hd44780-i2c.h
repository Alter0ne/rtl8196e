#ifndef HD_I2C_H
#define HD_I2C_H

#include "lcd.h"					  /* for Driver */

// initialise this particular driver
int hd_init_i2c(Driver *drvthis);

#endif
