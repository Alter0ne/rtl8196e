#ifndef I2500VFDFM_H
#define I2500VFDFM_H

unsigned char i2500vfd_fontmap[256][8];

#endif
