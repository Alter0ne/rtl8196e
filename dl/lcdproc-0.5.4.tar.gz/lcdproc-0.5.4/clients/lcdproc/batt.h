#ifndef BATT_H
#define BATT_H

int battery_screen(int rep, int display, int *flags_ptr);

#endif
