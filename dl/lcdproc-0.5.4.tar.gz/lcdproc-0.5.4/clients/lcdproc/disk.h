#ifndef DISK_H
#define DISK_H

int disk_screen(int rep, int display, int *flags_ptr);

#endif
