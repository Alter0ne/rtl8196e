#ifndef LOAD_H
#define LOAD_H

#ifndef LOAD_MAX
#define LOAD_MAX 1.3
#endif
#ifndef LOAD_MIN
#define LOAD_MIN 0.05
#endif

int xload_screen(int rep, int display, int *flags_ptr);

#endif
