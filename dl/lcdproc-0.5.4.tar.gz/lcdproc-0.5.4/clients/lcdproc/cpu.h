#ifndef CPU_H
#define CPU_H

int cpu_screen(int rep, int display, int *flags_ptr);
int cpu_graph_screen(int rep, int display, int *flags_ptr);

#endif
