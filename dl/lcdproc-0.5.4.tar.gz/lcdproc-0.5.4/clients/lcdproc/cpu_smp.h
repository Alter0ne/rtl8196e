#ifndef CPU_SMP_H
#define CPU_SMP_H

int cpu_smp_screen(int rep, int display, int *flags_ptr);

#endif
