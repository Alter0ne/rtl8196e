#ifndef CTRL_H
#define CTRL_H

int eyebox_screen(char display, int init);
void eyebox_clear(void);

#endif
