#ifndef CHRONO_H
#define CHRONO_H

int clock_screen(int rep, int display, int *flags_ptr);
int uptime_screen(int rep, int display, int *flags_ptr);
int time_screen(int rep, int display, int *flags_ptr);
int big_clock_screen(int rep, int display, int *flags_ptr);
int mini_clock_screen(int rep, int display, int *flags_ptr);

#endif
