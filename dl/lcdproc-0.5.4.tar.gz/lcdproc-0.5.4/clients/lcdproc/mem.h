#ifndef MEM_H
#define MEM_H

int mem_screen(int rep, int display, int *flags_ptr);
int mem_top_screen(int rep, int display, int *flags_ptr);

#endif
