#define RELEASE "net-tools 1.60"
