/** \file shared/str.h
 * Commmand / argument parsing functions (for use in clients).
 */

#ifndef STR_H
#define STR_H

int get_args (char **argv, char *str, int max_args);

#endif
