<?
define("DFLT_WIDTH", 900);
define("DFLT_HEIGHT", 256);
define("DFLT_INTERVAL", INT_DAILY);

$db_connect_string = "sqlite:/var/www/bandwidthd/stats.db";
