#define HOWTO_PLUGIN "bmx_howto_plugin"
