#include "string.h"

char*
string_get(struct string* s)
{
	return s->s;
}

