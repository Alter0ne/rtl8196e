#include "string.h"

void
string_clear(struct string*s)
{
	s->length = 0;
}
