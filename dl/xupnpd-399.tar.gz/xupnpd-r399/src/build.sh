#!/bin/bash

make clean; make bcm947xx_ddwrt

make clean; make bcm947xx

make clean; make ar71xx

make clean; make ar231x

make clean
