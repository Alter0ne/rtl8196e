/* SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileCopyrightText: 2009-2019, Marek Lindner <mareklindner@neomailbox.ch>
 */

#ifndef __AP51_FLASH_COMMANDLINE_H__
#define __AP51_FLASH_COMMANDLINE_H__

int main(int argc, char* argv[]);

#endif /* __AP51_FLASH_COMMANDLINE_H__ */
