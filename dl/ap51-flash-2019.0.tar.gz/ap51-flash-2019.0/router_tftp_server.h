/* SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileCopyrightText: 2009-2019, Marek Lindner <mareklindner@neomailbox.ch>
 */

#ifndef __AP51_FLASH_ROUTER_TFTP_SERVER_H__
#define __AP51_FLASH_ROUTER_TFTP_SERVER_H__

extern const struct router_type ubnt;

#endif /* __AP51_FLASH_ROUTER_TFTP_SERVER_H__ */
