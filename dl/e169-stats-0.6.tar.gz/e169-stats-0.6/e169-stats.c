#include <stdio.h>
#include <curses.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <errno.h>
#include <sys/select.h>
#include <sys/time.h>
#include <unistd.h>
#include <err.h>
#include <sys/stat.h>

typedef const char * const string;
#define	LENGTH(x)	(sizeof(x) / sizeof(x[0]))

static WINDOW *mainwindow;
static WINDOW *screen;
static bool hascolour;

#define	HISTORY	300
static struct scrollbar {
	unsigned char	sb_ssi;		/* relative signal strength */
	unsigned char	sb_mode;	/* Modem mode */
	unsigned int	sb_tx;		/* Tx bytes */
	unsigned int	sb_rx;		/* Rx bytes */
} scbar[HISTORY];

static const string modes[] = { "Unknown", "None", "GPRS", "UMTS", "HSDPA", "HSPA6", "HSPA7" };
static int colour[8];
static __typeof__(ACS_S1) c[5];

#define RSSI_NOTHING	99	/* Coming from the modem */
#define	RSSI_SCALE	31	/* Max meaningful RSSI value */

#define VHIST	30
long arx[VHIST], atx[VHIST];

static long uptime = 0, lastuptime = 0;	/* Seconds */
static long rxnow = 0, txnow = 0, rxtotal = 0, txtotal = 0;
static int srvst = -1;

static void
bytestosomething(long b, char *s, size_t len)
{

	if (b > 20 * 1024 * 1024) {
		snprintf(s, len, "%2.02f MiB", (double)b / (1024 * 1024));
	} else if (b > 20 * 1024) {
		snprintf(s, len, "%2.02f KiB", (double)b / 1024);
	} else {
		snprintf(s, len, "%ld   B", b);
	}
}

static void
screen_init(void)
{

	mainwindow = initscr();
	hascolour = has_colors();
	noecho();
	cbreak();
	nodelay(mainwindow, TRUE);
	if (hascolour) {
		start_color();
		use_default_colors();
		init_pair(1, COLOR_WHITE, -1);	colour[1] = COLOR_PAIR(1);
		init_pair(2, COLOR_GREEN, -1);	colour[2] = COLOR_PAIR(2);
		init_pair(3, COLOR_BLUE, -1);	colour[3] = COLOR_PAIR(3);
		init_pair(4, COLOR_CYAN, -1);	colour[4] = COLOR_PAIR(4);
		init_pair(5, COLOR_RED, -1);	colour[5] = COLOR_PAIR(5);
		init_pair(6, COLOR_MAGENTA, -1);colour[6] = COLOR_PAIR(6);
		init_pair(7, COLOR_YELLOW, -1);	colour[7] = COLOR_PAIR(7);
		wattrset(mainwindow, COLOR_PAIR(1));
	}
	refresh();
	wrefresh(mainwindow);
	screen = newwin(0, 0, 0, 0);
	/* Unfortunately, these aren't constants */
	c[0] = ACS_S9;
	c[1] = ACS_S7;
	c[2] = ACS_HLINE;
	c[3] = ACS_S3;
	c[4] = ACS_S1;

}

/* Calculate appropriate scaling value and write legend */
static unsigned
scale(int vol, int Y, unsigned yscale)
{
	unsigned tens, mult;
	unsigned v1;	/* input scale */
	unsigned v2;	/* range to use */
	unsigned v3;	/* scaled range to print */
	char prefix;	/* range scale */

	if (vol <= 0)
		return (1);

	for (v1 = vol * 20, tens = 0, mult = 1; v1 > 175; ) {
		v1 /= 10;
		tens++;
		mult *= 10;
	}

	v2 = (v1 > 135) ? 15 : (v1 > 110) ? 12 : (v1 > 90) ? 10 :
	     (v1 > 70) ? 8 : (v1 > 50) ? 6 : (v1 > 35) ? 4 : (v1 > 25) ? 3 : 2;
	v2 = v2 * mult / 2;
	v1 = v1 * mult / 20;

	prefix = ' ';
	v3 = v2;
	if (v2 > 8000000) {
		prefix = 'M';
		v3 /= 1000000;
	} else if (v2 > 8000) {
		prefix = 'k';
		v3 /= 1000;
	}

	mvwprintw(screen, Y - 1 - (v2 * yscale) / v1, 0, "%u%cB", v3, prefix);
	return (v1);
}

static void
update_display(int delay)
{
	char suptime[16];
	int u, days, hours, mins, secs;
	char stxtotal[16], srxtotal[16], stxnow[16], srxnow[16];
	char sdelay[32];

	u = uptime;
	days = u / 86400; u %= 86400;
	hours = u / 3600; u %= 3600;
	mins = u / 60; u %= 60;
	secs = u;

	if (days > 0) {
		snprintf(suptime, sizeof(suptime), "%dD %2d:%02d:%02d",
			 days, hours, mins, secs);
	} else {
		snprintf(suptime, sizeof(suptime), "%2d:%02d:%02d",
			 hours, mins, secs);
	}
	sdelay[0] = 0;
	if (delay > 5) {
		snprintf(sdelay, sizeof(sdelay), " (no data for %d seconds)",
			 delay);
	}

	bytestosomething(rxtotal, srxtotal, sizeof(srxtotal));
	bytestosomething(txtotal, stxtotal, sizeof(stxtotal));
	bytestosomething(rxnow, srxnow, sizeof(srxnow));
	bytestosomething(txnow, stxnow, sizeof(stxnow));

	int X = getmaxx(screen);
	int Y = getmaxy(screen);

	wattrset(screen, colour[1]);
	werase(screen);
	curs_set(0);
	mvwprintw(screen, 0, (X - 20)/2, "E169 stats (%d x %d)%s",
		  X, Y, sdelay);
	mvwprintw(screen, 1, 0, "Time online: %s", suptime);
	mvwaddstr(screen, 2, 0, "Mode: ");
	wattrset(screen, colour[scbar[0].sb_mode]);
	waddstr(screen, modes[scbar[0].sb_mode]);
	wattrset(screen, colour[1]);
	wprintw(screen, " / SRVST: %d", srvst);
	if (scbar[0].sb_ssi == RSSI_NOTHING)
		mvwprintw(screen, 3, 0, "RSSI:  no data");
	else
		mvwprintw(screen, 3, 0, "RSSI:  %d dBm (%d)",
			  2 * scbar[0].sb_ssi - 113, scbar[0].sb_ssi);
	mvwprintw(screen, 4, 0, "Total: %s / %s", stxtotal, srxtotal);
	mvwprintw(screen, 5, 0, "Now:   %s / %s", stxnow, srxnow);
//	mvwprintw(screen, 6, 0, "Last:  %d / %d", scbar[0].sb_tx, scbar[0].sb_rx);

	int i;
	for (i = -9; i <= 0; i++) {
		char buf[100], srx[100], stx[100];
		struct tm *tm;
		time_t now;

		now = time(NULL) + i * 60;
		tm = localtime(&now);
		strftime(buf, 100, "%H:%M", tm);

		bytestosomething(arx[VHIST + i - 1], srx, sizeof(srx));
		bytestosomething(atx[VHIST + i - 1], stx, sizeof(stx));

		mvwprintw(screen, 11 + i, 39, "%s %12s / %12s", buf, stx, srx);
	}

	/* Calculate volume scale */
	unsigned yscale = (Y > 20) ? Y - 13 : Y;
	int vol1 = 0;
	for (i = 0; i < X; i++) {
		if (scbar[i].sb_tx > vol1)
			vol1 = scbar[i].sb_tx;
		if (scbar[i].sb_rx > vol1)
			vol1 = scbar[i].sb_rx;
	}

	unsigned vol = scale(vol1, Y, yscale);
	mvwaddstr(screen, Y - 1 - yscale, 10, "-51dBm");

	unsigned ssi_scale = yscale * LENGTH(c);
	for (i = 0; i < X; i++) {
		if (scbar[i].sb_ssi != RSSI_NOTHING) {
			int ssi = (scbar[i].sb_ssi * ssi_scale) / RSSI_SCALE;

			mvwaddch(screen, Y - 1 - (ssi / LENGTH(c)), X - i,
				colour[scbar[i].sb_mode] | c[ssi % LENGTH(c)]);
		}
		if (scbar[i].sb_tx > 0) {
			mvwaddch(screen,
				 Y - 1 - (scbar[i].sb_tx * yscale) / vol,
				 X - i, colour[scbar[i].sb_mode] | '^');
		}
		if (scbar[i].sb_rx > 0) {
			mvwaddch(screen,
				 Y - 1 - (scbar[i].sb_rx * yscale) / vol,
				 X - i, colour[scbar[i].sb_mode] | 'v');
		}
		if (scbar[i].sb_rx == 0 && scbar[i].sb_tx == 0) {
			mvwaddch(screen, Y - 1,
				 X - i, colour[7] | ACS_DIAMOND);
		}
	}
	wattrset(screen, colour[1]);
	wrefresh(screen);
}

static void
screen_end(void)
{

	endwin();
}

static int
isafile(int fd)
{
	struct stat buf;

	if (fstat(fd, &buf) < 0)
		err(1, "stat device");

	return (S_ISREG(buf.st_mode));
}

static void
handle_keyboard(void)
{
	int input;

	if ((input = wgetch(mainwindow)) == ERR)
		return;

	if (input == 12) {	/* ^L */
		wrefresh(curscr);
		return;
	}
	if (input == 'q' || input == 'Q') {
		screen_end();
		exit(0);
	}

	// ignore
}

int
main(int argc, char **argv)
{
	FILE *fin, *fout = NULL;
	int fd;
	char line[100];
	int i;
	fd_set fdset;
	int empty = 0;
	const char *dev = "/dev/cuaU0.2";
	struct timeval timeout;
	int isfile;

	for (i = 0; i < HISTORY; i++) {
		scbar[i].sb_ssi = RSSI_NOTHING;
		scbar[i].sb_tx = -1;
		scbar[i].sb_rx = -1;
	}

	if (argc == 2)
		dev = argv[1];

	screen_init();
	cbreak();
	timeout(0);
	nodelay(mainwindow, TRUE);

	while (1) {
		handle_keyboard();

		mvwprintw(screen, 1, 0, "Offline");
		wclrtoeol(screen);
		wrefresh(screen);
		fin = fopen(dev, "r");
		if (fin == NULL) {
			mvwprintw(screen, 1, 0, "Open: %s", strerror(errno));
			wclrtoeol(screen);
			wrefresh(screen);
			usleep(1000000);
			continue;
		}
		fd = fileno(fin);
		isfile = isafile(fd);

		if (fout != NULL)
			fout = fopen(isfile ? "/dev/null" : "log", "w");

		while (1) {
			handle_keyboard();
			update_display(empty);
			FD_ZERO(&fdset);

			FD_SET(fd, &fdset);
			if (!isfile) {
				timeout.tv_sec = 5;
				timeout.tv_usec = 0;
				if (select(fd + 1, &fdset, NULL, NULL,
				    &timeout) < 0) {
					if (errno != EINTR)
						break;
					continue;
				}
			}

			if (!FD_ISSET(fd, &fdset)) {	/* timeout */
				/* Shift anyway, the time should go on */
				memmove(scbar + 1, scbar,
				    sizeof(scbar[0]) * (HISTORY - 1));
				/* Mode & SSI get copied from previous */
				scbar[0].sb_tx = -1;
				scbar[0].sb_rx = -1;

				empty += 5;
				if (fout != NULL) {
					fprintf(fout,
					    "Nothing for %d seconds!\n", empty);
					fflush(fout);
				}
			}

			empty = 0;
			if (fgets(line, sizeof(line), fin) == NULL) {
				if (errno != EINTR) {
					warn("fgets");
					screen_end();
					break;
				}
				continue;
			}

			if (line[0] < ' ')
				continue;

			if (fout != NULL) {
				fprintf(fout, "%s", line);
				fflush(fout);
			}

			if (strncmp(line, "^BOOT:", 6) == 0)
				continue;

			if (strncmp(line, "^RSSI:", 6) == 0) {
				/* 0..31 => n*2 - 113 dBm.  99 => unknown */
				scbar[0].sb_ssi = atoi(line + 6);
				continue;
			}

			if (strncmp(line, "^SRVST:", 7) == 0) {
				srvst = atoi(line + 7);
				continue;
			}

			if (strncmp(line, "^DSFLOWRPT:", 11) == 0) {
				/* Time */
				char *ep;

				uptime = strtol(line + 11, &ep, 16);
/*
0         1         2         3         4         5         6         7         8
012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789
^DSFLOWRPT:0000071A,0000002A,0000002A,0000000000060BB1,00000000000CF3FB,00003E80,00003E80
*/
				/* TX Bytes in last two seconds */
				txnow = 0;
				if (*++ep == '0')
					txnow = strtol(ep, &ep, 16);
				/* RX Bytes in last two seconds */
				rxnow = 0;
				if (*++ep == '0')
					rxnow = strtol(ep, &ep, 16);
				/* TX Bytes in total */
				txtotal = strtol(ep + 1, &ep, 16);
				/* RX Bytes in total */
				rxtotal = strtol(ep + 1, &ep, 16);

				/* Accumulate dataflow over last minute */
				if (lastuptime + 60 < uptime ||
				    uptime < lastuptime) {
					int diffmins = (uptime - lastuptime) / 60;
					if (fout)
						fprintf(fout, "%ld %ld %d\n",
						    lastuptime, uptime,
						    diffmins);
					if (diffmins < 0) {
						diffmins = 0;
					} else if (diffmins >= VHIST) {
						diffmins = VHIST - 1;
					}
					memmove(arx, arx + diffmins,
					    sizeof(int) * (VHIST - diffmins));
					memmove(atx, atx + diffmins,
					    sizeof(int) * (VHIST - diffmins));
					for (i = 1; i <= diffmins; i++) {
						arx[VHIST - i] = 0;
						atx[VHIST - i] = 0;
					}
					lastuptime = uptime;
				}
				arx[VHIST - 1] += rxnow;
				atx[VHIST - 1] += txnow;

				memmove(scbar + 1, scbar,
					sizeof(scbar[0]) * (HISTORY - 1));
				/* Mode & SSI get copied from previous */
				scbar[0].sb_tx = txnow;
				scbar[0].sb_rx = rxnow;
				if (isfile)
					usleep(100000);
				continue;
			}
			if (strncmp(line, "^MODE:", 6) == 0) {
				scbar[0].sb_mode =
				    (strncmp(line + 6, "0,0", 3) == 0) ? 1 :
				    (strncmp(line + 6, "3,2", 3) == 0) ? 2 :
				    (strncmp(line + 6, "5,4", 3) == 0) ? 3 :
				    (strncmp(line + 6, "5,5", 3) == 0) ? 4 :
				    (strncmp(line + 6, "5,6", 3) == 0) ? 5 :
				    (strncmp(line + 6, "5,7", 3) == 0) ? 6 : 0;
				continue;
			}
			if (fout != NULL)
				fprintf(fout, "No idea what that is\n");
		}
		fclose(fin);
	}
	screen_end();
	return 0;
}

