#define VOXNAME cmu_time_awb
#define REGISTER_VOX register_cmu_time_awb
#define UNREGISTER_VOX unregister_cmu_time_awb
#define VOXHUMAN "awb"
#define VOXGENDER "male"
#define VOXVERSION 1.1
