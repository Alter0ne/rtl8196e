nuMurmon
=

nuMurmon is a ncurses based umurmur monitoring utility

Screenshots
=

The color coding has the following meanings:
* Red -> Admin
* Green -> Talking

The main view
-
![Main view](../screenshots/numurmon.jpg?raw=true "The main view of nuMurmon")

A user speaking
-
![Main view (speaking)](../screenshots/numurmon_talking.jpg?raw=true "The main view of nuMurmon with one user currently speaking")
