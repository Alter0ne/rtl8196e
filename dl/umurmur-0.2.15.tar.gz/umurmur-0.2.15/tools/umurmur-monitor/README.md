umurmur-monitor
=

This is a utility to monitor the status of a umurmurd instance running with SHM enabled.
