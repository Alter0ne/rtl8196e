/*	Frickin PPTP Proxy, Copyright (c) 2004 Martin Akesson <ma@placid.tv>

	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the
	"Software"), to deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to
	permit persons to whom the Software is furnished to do so, subject to
	the following conditions:

	The above copyright notice and this permission notice shall be
	included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

/* RFC2637 - Point-to-Point Tunneling Protocol (PPTP)*/

#define PPTP_PORT 1723
#define MAGIC_COOKIE 0x1A2B3C4D

/* PPTP control message types */
enum ctrl_types {SCCRQ = 1, SCCRP, TCCRQ, TCCRP, ECORQ, ECORP, OCRQ, OCRP, ICRQ, ICRP, ICCN, CCRQ, CDN, WENT, SLI};

/* General error codes */
enum general_errors {NONE = 0, NOT_CONNECTED, BAD_FORMAT, BAD_VALUE, NO_RSRC, BAD_CALL_ID, PAC_ERROR};

/* PPTP Message "Header" */
struct pptp_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
};

/* Start-Control-Connection-Request */
struct sccrq_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int8_t protocol_u;
	u_int8_t protocol_l;
	u_int16_t reserved1;
	u_int32_t framing_cap;
	u_int32_t bearer_cap;
	u_int16_t max_channels;
	u_int16_t firmware_rev;
	char hostname[64];
	char vendor[64];
};

/* Start-Control-Connection result codes */
enum sccrp_results {SCC_OK = 1, SCC_ERROR, SCC_EXIST, SCC_AUTH, SCC_VER};

/* Start-Control-Connection-Reply */
struct sccrp_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int8_t protocol_u;
	u_int8_t protocol_l;
	u_int8_t result;
	u_int8_t error;
	u_int32_t framing_cap;
	u_int32_t bearer_cap;
	u_int16_t max_channels;
	u_int16_t firmware_rev;
	char hostname[64];
	char vendor[64];
};

/* Stop-Control-Connection-Request */
struct tccrq_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int8_t reason;
	u_int8_t reserved1;
	u_int16_t reserved2;
};

/* Stop-Control-Connection-Reply */
struct tccrp_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int8_t result;
	u_int8_t error;
	u_int16_t reserved1;
};

/* Echo-Request */
struct ecorq_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int32_t identifier;
};

/* Echo-Reply result codes */
enum eco_results {ECO_OK = 1, ECO_ERROR};

/* Echo-Reply */
struct ecorp_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int32_t identifier;
	u_int8_t result;
	u_int8_t error;
	u_int16_t reserved1;
};

/* Outgoing-Call-Request */
struct ocrq_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int16_t call_id;
	u_int16_t call_serial;
	u_int32_t min_bps;
	u_int32_t max_bps;
	u_int32_t bearer_type;
	u_int32_t framing_type;
	u_int16_t recv_win_sz;
	u_int16_t proc_delay;
	u_int16_t number_length;
	u_int16_t reserved1;
	char phone_number[64];
	char subaddress[64];
};

/* Outgoing-Call result codes */
enum occ_results {OC_OK = 1, OC_ERROR, OC_CARRIER, OC_BUSY, OC_TONE, OC_TIMEOUT, OC_DENIED};

/* Outgoing-Call-Reply */
struct ocrp_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int16_t call_id;
	u_int16_t peer_call_id;
	u_int8_t result;
	u_int8_t error;
	u_int16_t cause;
	u_int32_t speed;
	u_int16_t recv_win_sz;
	u_int16_t proc_delay;
	u_int32_t channel_id;
};

#if 0
/* Incoming-Call-Request */
struct iccrq_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
};

/* Incoming-Call-Reply */
struct iccrp_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
};

/* Incoming-Call-Connected */
struct icc_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
};
#endif

/* Call-Clear-Request */
struct ccrq_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int16_t call_id;
	u_int16_t reserved1;
};

enum cdn_results {CDN_CARRIER, CDN_ERROR, CDN_SHUTDOWN, CDN_REQUEST};

/* Call-Disconnect-Notify */
struct cdn_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int16_t call_id;
	u_int8_t result;
	u_int8_t error;
	u_int16_t cause;
	u_int16_t reserved1;
	char stats[128];
};

/* WAN-Error-Notify */
struct wen_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int16_t peer_call_id;
	u_int16_t reserved1;
	u_int32_t crc_errorrs;
	u_int32_t framing_errors;
	u_int32_t hardware_overruns;
	u_int32_t buffer_overruns;
	u_int32_t timeout_errors;
	u_int32_t alignment_errors;
};

/* Set-Link-Info */
struct sli_msg
{
	u_int16_t length;
	u_int16_t type;
	u_int32_t magic_cookie;
	u_int16_t ctrl_type;
	u_int16_t reserved0;
	u_int16_t peer_call_id;
	u_int16_t reserved1;
	u_int32_t send_accm;
	u_int32_t receive_accm;
};

/* GRE header */
struct gre_header
{
	u_int16_t flags;
	u_int16_t type;
	u_int16_t length;
	u_int16_t call_id;
	u_int32_t sequence_nr;
	u_int32_t ack_nr;
};

/* Prototypes */
int _send_sccrq(int a_socket, int a_protocol_u, int a_protocol_l,
		int a_framing_cap, int a_bearer_cap, int a_max_channels,
		int a_firmware_rev, char *a_hostname, char *a_vendor);
int _send_sccrp(int a_socket, int a_protocol_u, int a_protocol_l, int a_result, int a_error,
		unsigned int a_framing_cap, unsigned int a_bearer_cap, int a_max_channels,
		int a_firmware_rev, char *a_hostname, char *a_vendor);
int _send_ecorq(int a_socket, int a_identifier);
int _send_ecorp(int a_socket, int a_identifier, int a_result, int a_error);
int _send_ocrq(int a_socket, int a_call_id, unsigned int a_min_bps, unsigned int a_max_bps,
		unsigned int a_bearer_type, unsigned int a_framing_type, int a_recv_win_sz,
		int a_proc_delay, int *a_number_length, char *a_phone_number, char *a_subaddress);
int _send_ocrp(int a_socket, int a_call_id, int a_peer_call_id, int a_result, int a_error,
		int a_cause, unsigned int a_speed, int a_recv_win_sz, int a_proc_delay, unsigned int a_channel_id);
int _send_tccrq(int a_socket, int a_reason);
int _send_tccrp(int a_socket, int a_result, int a_error);
int _send_ccrq(int a_socket, int a_call_id);
int _send_cdn(int a_socket, int a_call_id, int a_result, int a_error, int a_cause, char *a_stats);
int _send_sli(int a_socket, int a_call_id, int a_sendaccm, int a_recvaccm);
