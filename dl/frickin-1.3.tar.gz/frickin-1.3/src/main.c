/*	Frickin PPTP Proxy, Copyright (c) 2004 Martin Akesson <ma@placid.tv>

	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the
	"Software"), to deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to
	permit persons to whom the Software is furnished to do so, subject to
	the following conditions:

	The above copyright notice and this permission notice shall be
	included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <getopt.h>
#include <syslog.h>
#include <pwd.h>

#include "main.h"
#include "rfc2637.h"

//#define DEBUG
//#define PACKET_DEBUG

extern const char *pptp_msg_names[];
extern const char *pptp_error_names[];

int run = 1;
const char *k_default_ip = "127.0.0.1";	/* Default listen ip address */
const char *g_vendor = "Frickin";
const char *g_version = "1.3";
char *g_user = NULL;

char *g_listen_ip;	/* Alphanumeric listen ip address */
char *g_target_ip;	/* Alphanumeric server ip address */
SIN g_target_addr;	/* Integer server address */

struct 
{
	int in;
	int out;
} g_ctrlchannel;	/* Control channel sockets */
int g_tunnel;		/* Tunnel socket */

int g_connection_max;					/* Maximum number of connections allowed */
int g_connection_count;					/* Number of connected clients */
ProxyConnection **g_connection_list;	/* List of connected clients */

int g_call_max;					/* Maximum number of calls allowed (Total) */
int g_call_count;				/* Number of calls */
CallData **g_call_list;			/* List used for "hashed" call-id's */

int g_connection_pending = 0;	/* Number of connections not yet negotiated */
int g_connection_up = 0;		/* Number of connections that are up and running */

ProxyState g_proxy;
DataBuffer g_buffer;

#if 0
void _print_buff(unsigned char *a_buffer, int a_size)
{
	int i, j;

	while (a_size)
	{
		if (a_size > 8)
			i = 8;
		else
			i = a_size;

		for (j = 0; j < i; j++) printf("%.2X ", a_buffer[j]);
		printf("\t");
		for (j = 0; j < i; j++) isprint(a_buffer[j]) ? printf("%c", a_buffer[j]) : printf(".");
		printf("\n");
		a_buffer += i;
		a_size -= i;
	}
}
#endif

#ifdef PACKET_DEBUG
void _print_msg(int a_id)
{
	struct pptp_msg *pptp;

	pptp = (struct pptp_msg*) g_buffer.data;
	switch (ntohs(pptp->ctrl_type))
	{
		case SCCRQ:
			{
				struct sccrq_msg *sccrq = (struct sccrq_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" v=%u.%u, fc=%u, bc=%u, mc=%u, fr=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], sccrq->protocol_u, sccrq->protocol_l,
						ntohl(sccrq->framing_cap), ntohl(sccrq->bearer_cap),
						ntohs(sccrq->max_channels), ntohs(sccrq->firmware_rev));
				break;
			}
		case SCCRP:
			{
				struct sccrp_msg *sccrp = (struct sccrp_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" v=%u.%u, res=%u, err=%u, fc=%u, bc=%u, mc=%u, fr=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], sccrp->protocol_u, sccrp->protocol_l,
						sccrp->result, sccrp->error, ntohl(sccrp->framing_cap),
						ntohl(sccrp->bearer_cap), ntohs(sccrp->max_channels), ntohs(sccrp->firmware_rev));
				break;
			}
		case TCCRQ:
			{
				struct tccrq_msg *tccrq = (struct tccrq_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" reason=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], tccrq->reason);
				break;
			}
		case TCCRP:
			{
				struct tccrp_msg *tccrp = (struct tccrp_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" res=%u, err=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], tccrp->error, tccrp->result);
				break;
			}
		case ECORQ:
			{
				struct ecorq_msg *ecorq = (struct ecorq_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" id=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], htonl(ecorq->identifier));
				break;
			}
		case ECORP:
			{
				struct ecorp_msg *ecorp = (struct ecorp_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" id=%u, res=%u, err=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], htonl(ecorp->identifier),
						ecorp->result, ecorp->error);
				break;
			}
		case OCRQ:
			{
				struct ocrq_msg *ocrq = (struct ocrq_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" c_id=%u, s=%u, min=%u, max=%u, bt=%u, ft=%u, rws=%u, pd=%u, nl=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], ocrq->call_id, ntohs(ocrq->call_serial),
						ntohl(ocrq->min_bps), ntohl(ocrq->max_bps), ntohl(ocrq->bearer_type), ntohl(ocrq->framing_type),
						ntohs(ocrq->recv_win_sz), ntohs(ocrq->proc_delay), ntohs(ocrq->number_length));
				break;
			}
		case OCRP:
			{
				struct ocrp_msg *ocrp = (struct ocrp_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" c_id=%u, p_id=%u, res=%u, err=%u, cause=%u, speed=%u, rws=%u, pd=%u, ch=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], ocrp->call_id, ocrp->peer_call_id,
						ocrp->result, ocrp->error, ntohs(ocrp->cause), ntohl(ocrp->speed), ntohs(ocrp->recv_win_sz),
						ntohs(ocrp->proc_delay), ntohl(ocrp->channel_id));
				break;
			}
		case CCRQ:
			{
				struct ccrq_msg *ccrq = (struct ccrq_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" c_id=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], ccrq->call_id);
				break;
			}
		case CDN:
			{
				struct cdn_msg *cdn = (struct cdn_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" c_id=%u, res=%u, err=%u, cause=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], cdn->call_id, cdn->result, cdn->error, ntohs(cdn->cause));
				break;
			}
		case SLI:
			{
				struct sli_msg *sli = (struct sli_msg*) g_buffer.data;
				syslog(LOG_INFO, "[%.3u] \"%s\" c_id=%u, s_accm=%u, r_accm=%u", a_id,
						pptp_msg_names[ntohs(pptp->ctrl_type)], sli->peer_call_id, ntohl(sli->send_accm), ntohl(sli->receive_accm));
				break;
			}
		default:
			syslog(LOG_INFO, "[%.3u] \"%s\"", a_id, pptp_msg_names[ntohs(pptp->ctrl_type)]);
	}
}
#endif

/* _drop_priv_perm() - Permanently drop privileges
 * Input:	a_user - Username to change to
 * Output:	0 if successful
 */
int _drop_priv_perm(char *a_user)
{
	int ret = -1;
	struct passwd *pw;

	if ((pw = getpwnam(a_user)))
	{
		if ((setgid(pw->pw_gid) == 0) && (setuid(pw->pw_uid) == 0))
		{
			uid_t ruid, euid;
			gid_t rgid, egid;

			ruid = getuid();
			euid = geteuid();
			rgid = getgid();
			egid = getegid();
			if ((ruid == pw->pw_uid) && (euid == pw->pw_uid) && (rgid == pw->pw_gid) && (egid == pw->pw_gid)) ret = 0;
		}
		endpwent();
	}
	return ret;
}

/* _get_socket() - Create a new socket
 * Input:	a_type - Socket type
 * 			a_proto - Protocol for socket
 * Output:	0 if failed, else a descriptor
 */
int _get_socket(int a_type, int a_proto)
{
	int s;

	if (0 != (s = socket(AF_INET, a_type, a_proto)))
	{
		int flags = 1;
		if (a_proto == IPPROTO_IP)
		{
#ifdef SO_REUSEPORT
			setsockopt(s, SOL_SOCKET, SO_REUSEPORT, (char*)&flags, sizeof(flags));
#endif
			setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char*)&flags, sizeof(flags));
			//setsockopt(s, SOL_SOCKET, SO_LINGER, , sizeof());
		}
	}

	return s;
}

/* _connect_to_server() - Connect to PPTP server
 */
int _connect_to_server()
{
	int sent = 0;

	if (0 != (g_ctrlchannel.out = _get_socket(SOCK_STREAM, IPPROTO_IP)))
	{
		SIN sin;

		bzero(&sin, sizeof(SIN));
		sin.sin_family = AF_INET;
		sin.sin_port = htons(PPTP_PORT);
		sin.sin_addr.s_addr = inet_addr(g_target_ip);

		syslog(LOG_INFO, "Connecting to server %s:%u", g_target_ip, PPTP_PORT);
		if (-1 == connect(g_ctrlchannel.out, (SA*) &sin, sizeof(SIN)))
		{
			syslog(LOG_ERR, "Could not connect to pptp server (%s)", strerror(errno));
		}
		else
		{
			if (sizeof(struct sccrq_msg) == (sent = _send_sccrq(g_ctrlchannel.out, 1, 0, 3, 3, 0, 0, NULL, NULL)))
			{
				g_proxy.state = PENDING;
				g_proxy.call_obfuscator = (random() & 0xffff);
#ifdef DEBUG
				syslog(LOG_INFO, "Call_ID obfuscator = %.4X", g_proxy.call_obfuscator);
#endif
			}
			else
			{
				syslog(LOG_WARNING, "Could not send data to server (%s)", strerror(errno));
				sent = 0;
			}
		}

		if (!sent)
		{
			if (g_ctrlchannel.out)
			{
				close(g_ctrlchannel.out);
				g_ctrlchannel.out = 0;
			}

			g_proxy.state = DOWN;
		}
	}
	else
	{
		syslog(LOG_CRIT, "Could not create tcp send socket (%s)", strerror(errno));
		exit(-1);
	}

	return sent;
}

/* _handle_connection() - Setup new client connections
 */
void _handle_connection()
{
	int i;
	ProxyConnection conn;

	conn.addrlen = sizeof(SIN);
	conn.socket = accept(g_ctrlchannel.in, (SA*) &conn.saddr, &conn.addrlen);

	for (i = 0; i < g_connection_max; i++)
	{
		if ((g_connection_list[i]) && (conn.saddr.sin_addr.s_addr == g_connection_list[i]->saddr.sin_addr.s_addr))
		{
			syslog(LOG_INFO, "Dropping duplicate connection from %s:%u", inet_ntoa(conn.saddr.sin_addr), conn.saddr.sin_port);
			close(conn.socket);
			return;
		}
	}

	if (0 < (g_buffer.length = recvfrom(conn.socket, g_buffer.data, g_buffer.size, 0, NULL, NULL)))
	{
		struct sccrq_msg *sccrq = (struct sccrq_msg*) g_buffer.data;

		if (ntohs(sccrq->ctrl_type) == SCCRQ)
		{
			if (g_buffer.length == ntohs(sccrq->length) &&
					(g_buffer.length == sizeof(struct sccrq_msg)) &&
					(MAGIC_COOKIE == ntohl(sccrq->magic_cookie)))
			{
				if (g_connection_count < g_connection_max)
				{
					for (i = 0; i < g_connection_max; i++)
					{
						if (g_connection_list[i] == NULL) break;
					}
					syslog(LOG_INFO, "Accepted connection from %s:%u (%.3u/%.3u)", inet_ntoa(conn.saddr.sin_addr),
							conn.saddr.sin_port, g_connection_count, g_connection_max);
#ifdef PACKET_DEBUG
					_print_msg(i);
#endif

					if (g_proxy.state == DOWN) _connect_to_server();

					if (g_proxy.state == PENDING)
					{
						conn.state = PENDING;
						g_connection_pending++;
					}

					if (g_proxy.state == UP)
					{
						g_connection_up++;
						conn.state = UP;
						_send_sccrp(conn.socket, 1, 0, SCC_OK, 0, g_proxy.framing_cap, g_proxy.bearer_cap,
								g_proxy.max_channels, g_proxy.firmware_rev, (char*) &g_proxy.hostname, (char*) g_vendor);
					}

					g_connection_count++;
					g_connection_list[i] = calloc(1, sizeof(ProxyConnection));
					memcpy(g_connection_list[i], &conn, sizeof(ProxyConnection));
				}
				else
				{
					_send_sccrp(conn.socket, 1, 0, SCC_ERROR, NO_RSRC, 0, 0, 0, 0, NULL, NULL);
					syslog(LOG_INFO, "Denied connection from %s:%u (No resource)", inet_ntoa(conn.saddr.sin_addr), conn.saddr.sin_port);
				}
			}
			else
			{
				_send_sccrp(conn.socket, 1, 0, SCC_ERROR, BAD_FORMAT, 0, 0, 0, 0, NULL, NULL);
			}
		}
	}
}

/* _get_call_id() - Get a free Call-ID
 * Input:	a_connection - Proxy connection making the call
 * Output:	-1 if fail, else a Call-ID
 */
int _get_call_id(ProxyConnection *a_connection)
{
	int i, ret = -1;

	for (i = 0; i < g_call_max; i++)
	{
		if (NULL == g_call_list[i])
		{
			g_call_list[i] = calloc(1, sizeof(CallData));
			g_call_list[i]->connection = a_connection;
			g_call_count++;
			ret = i;
			break;
		}
	}

	return ret;
}

/* _process_client_data() - Process control data from a client
 * Input:	a_connection - Proxy connection sending the message
 */
void _process_client_data(ProxyConnection *a_connection)
{
	struct pptp_msg *pptp = (struct pptp_msg*) g_buffer.data;

	switch (ntohs(pptp->ctrl_type))
	{
		case SCCRQ:	/* Start-Control-Connection-Request */
			if (ntohs(pptp->length) == sizeof(struct sccrq_msg))
			{
				_send_sccrp(a_connection->socket, 1, 0, SCC_EXIST, 0, g_proxy.framing_cap, g_proxy.bearer_cap,
						g_proxy.max_channels, g_proxy.firmware_rev, (char*) &g_proxy.hostname, (char*) g_vendor);
			}
			else
			{
				_send_sccrp(a_connection->socket, 1, 0, SCC_ERROR, BAD_FORMAT, 0, 0, 0, 0, NULL, NULL);
			}
			break;
		case TCCRQ:	/* Stop-Control-Connection-Request */
			if (ntohs(pptp->length) == sizeof(struct tccrq_msg))
			{
				_send_tccrp(a_connection->socket, 1, 0);
			}
			break;
		case ECORQ:	/* Echo-Request */
			if (ntohs(pptp->length) == sizeof(struct ecorq_msg))
			{
				struct ecorq_msg *ecorq = (struct ecorq_msg*) g_buffer.data;

				_send_ecorp(a_connection->socket, ntohl(ecorq->identifier), ECO_OK, 0);
				break;
			}
			break;
		case ECORP:	/* Echo-Reply */
			break;
		case OCRQ:	/* Outgoing-Call-Request */
			if (ntohs(pptp->length) == sizeof(struct ocrq_msg))
			{
				int call_id;
				struct ocrq_msg *ocrq = (struct ocrq_msg*) g_buffer.data;

				if (-1 != (call_id = (_get_call_id(a_connection))))
				{
#ifdef DEBUG
					int i;
					for (i = 0; i < g_connection_max; i++)
					{
						if (a_connection == g_connection_list[i]) break;
					}
					syslog(LOG_INFO, "[%.3u] \"%s\" c_id=%u -> %u -> %u", i, pptp_msg_names[ntohs(pptp->ctrl_type)],
							ocrq->call_id, call_id, (call_id ^ g_proxy.call_obfuscator));
#endif
					g_call_list[call_id]->client_id = ocrq->call_id;
					ocrq->call_id = (call_id ^ g_proxy.call_obfuscator);
					send(g_ctrlchannel.out, g_buffer.data, g_buffer.length, NULL);
				}
				else
				{
					_send_ocrp(a_connection->socket, 0, ocrq->call_id, OC_ERROR, NO_RSRC, 0, 0, 0, 0, 0);
				}
				break;
			}
			else
			{
				struct ocrq_msg *ocrq = (struct ocrq_msg*) g_buffer.data;
				_send_ocrp(a_connection->socket, 0, ocrq->call_id, OC_ERROR, BAD_FORMAT, 0, 0, 0, 0, 0);
			}
			break;
		case CCRQ:	/* Call-Clear-Request */
			if (ntohs(pptp->length) == sizeof(struct ccrq_msg))
			{
				int i;
				struct ccrq_msg *ccrq = (struct ccrq_msg*) g_buffer.data;

				for (i = 0; i < g_call_max; i++)
				{
					if ((g_call_list[i]) && (g_call_list[i]->client_id == ccrq->call_id))
					{
						_send_ccrq(g_ctrlchannel.out, (i ^ g_proxy.call_obfuscator));
						break;
					}
				}
				if (i == g_call_max)
				{
					_send_cdn(a_connection->socket, ccrq->call_id, CDN_ERROR, BAD_CALL_ID, 0, NULL);
				}
			}
			else
			{
				struct ccrq_msg *ccrq = (struct ccrq_msg*) g_buffer.data;
				_send_cdn(a_connection->socket, ccrq->call_id, CDN_ERROR, BAD_FORMAT, 0, NULL);
			}
		case CDN:	/* Call-Disconnect-Notify */
			if (ntohs(pptp->length) == sizeof(struct cdn_msg))
			{
				int i;
				struct cdn_msg *cdn = (struct cdn_msg*) g_buffer.data;

				for (i = 0; i < g_call_max; i++)
				{
					if ((g_call_list[i]) && (g_call_list[i]->client_id == cdn->call_id))
					{
						_send_cdn(g_ctrlchannel.out, (i ^ g_proxy.call_obfuscator), cdn->result, cdn->error, cdn->cause, cdn->stats);
						free(g_call_list[i]);
						g_call_list[i] = NULL;
						g_call_count--;
						break;
					}
				}
				if (i == g_call_max)
				{
					for (i = 0; i < g_connection_max; i++)
					{
						if (g_connection_list[i] == a_connection) break;
					}
					syslog(LOG_ERR, "[%.3u] Sent Call-Disconnect-Notify for invalid Call-ID = %u", i, cdn->call_id);
				}
			}
			break;
		case SLI:	/* Set-Link-Info */
			if (ntohs(pptp->length) == sizeof(struct sli_msg))
			{
				struct sli_msg *sli = (struct sli_msg*) g_buffer.data;

				sli->peer_call_id ^= g_proxy.call_obfuscator;
				if (g_call_max > sli->peer_call_id)
				{
						_send_sli(g_ctrlchannel.out, g_call_list[sli->peer_call_id]->server_id, sli->send_accm, sli->receive_accm);
						break;
				}
			}
			break;
	}
}

/* _process_server_data() - Process control data from server
 */
void _process_server_data()
{
	struct pptp_msg *pptp = (struct pptp_msg*) g_buffer.data;

	switch (ntohs(pptp->ctrl_type))
	{
		case SCCRP:	/* Start-Control-Connection-Reply */
			if (ntohs(pptp->length) == sizeof(struct sccrp_msg))
			{
				struct sccrp_msg *sccrp = (struct sccrp_msg*) g_buffer.data;

				if (sccrp->result == SCC_OK)
				{
					g_proxy.framing_cap = ntohl(sccrp->framing_cap);
					g_proxy.bearer_cap = ntohl(sccrp->bearer_cap);
					g_proxy.max_channels = ntohs(sccrp->max_channels);
					g_proxy.firmware_rev = ntohs(sccrp->firmware_rev);
					memcpy(&g_proxy.hostname, sccrp->hostname, 64);
					memcpy(&g_proxy.vendor, sccrp->vendor, 64);
					g_proxy.state = UP;
				}
				else
				{
					g_proxy.state = DOWN;
				}
			}
			break;
		case TCCRQ:	/* Stop-Control-Connection-Request */
			if (ntohs(pptp->length) == sizeof(struct tccrq_msg))
			{
				int i;
				struct tccrq_msg *tccrq = (struct tccrq_msg*) g_buffer.data;

				for (i = 0; i < g_connection_max; i++)
				{
					if ((g_connection_list[i]) && (g_connection_list[i]->state == UP))
					{
						_send_tccrq(g_connection_list[i]->socket, ntohs(tccrq->reason));
					}
				}
				_send_tccrp(g_ctrlchannel.out, 1, 0);
			}
			break;
		case ECORQ:	/* Echo-Request */
			if (ntohs(pptp->length) == sizeof(struct ecorq_msg))
			{
				struct ecorq_msg *ecorq = (struct ecorq_msg*) g_buffer.data;

				_send_ecorp(g_ctrlchannel.out, ntohl(ecorq->identifier), ECO_OK, 0);
				break;
			}
			break;
		case OCRP:	/* Outgoing-Call-Reply */
			if (ntohs(pptp->length) == sizeof(struct ocrp_msg))
			{
				CallData *call;
				struct ocrp_msg *ocrp = (struct ocrp_msg*) g_buffer.data;

				ocrp->peer_call_id ^= g_proxy.call_obfuscator;
				if ((ocrp->peer_call_id < g_call_max) && (call = g_call_list[ocrp->peer_call_id]))
				{
#ifdef DEBUG
					syslog(LOG_INFO, "[999] \"%s\" c_id=%u -> %u -> %u", pptp_msg_names[ntohs(pptp->ctrl_type)],
							ocrp->call_id, ocrp->peer_call_id, (ocrp->peer_call_id ^ g_proxy.call_obfuscator));
#endif
					call->server_id = ocrp->call_id;
					ocrp->call_id = (ocrp->peer_call_id ^ g_proxy.call_obfuscator);
					ocrp->peer_call_id = call->client_id;
					send(call->connection->socket, g_buffer.data, g_buffer.length, NULL);
				}
				break;
			}
			break;
		case CCRQ:	/* Call-Clear-Request */
			if (ntohs(pptp->length) == sizeof(struct ccrq_msg))
			{
				int i;
				struct ccrq_msg *ccrq = (struct ccrq_msg*) g_buffer.data;

				for (i = 0; i < g_call_max; i++)
				{
					if ((g_call_list[i]) && (g_call_list[i]->server_id == ccrq->call_id))
					{
						_send_ccrq(g_call_list[i]->connection->socket, (i ^ g_proxy.call_obfuscator));
						break;
					}
				}
				if (i == g_call_max)
				{
					_send_cdn(g_ctrlchannel.out, ccrq->call_id, CDN_ERROR, BAD_CALL_ID, 0, NULL);
				}
			}
			break;
		case CDN:	/* Call-Disconnect-Notify */
			if (ntohs(pptp->length) == sizeof(struct cdn_msg))
			{
				int i;
				struct cdn_msg *cdn = (struct cdn_msg*) g_buffer.data;

				for (i = 0; i < g_call_max; i++)
				{
					if ((g_call_list[i]) && (g_call_list[i]->server_id == cdn->call_id))
					{
						_send_cdn(g_call_list[i]->connection->socket, (i ^ g_proxy.call_obfuscator), cdn->result, cdn->error, cdn->cause, cdn->stats);
						free(g_call_list[i]);
						g_call_list[i] = NULL;
						g_call_count--;
						break;
					}
				}
				if (i == g_call_max)
				{
					syslog(LOG_ERR, "[999] Sent Call-Disconnect-Notify for invalid Call-ID = %u", cdn->call_id);
				}
			}
			break;
	}
}

int main(int argc, char **argv)
{
	int ch;

	g_target_ip = NULL;
	g_listen_ip = (char*) k_default_ip;
	g_connection_max = 20;

	if (1 == argc)
	{
		printf("Frickin PPTP Proxy %s, Copyright (c) 2004 Martin Akesson\n", g_version);
		printf("usage: %s -s <pptp server> [-l <listen ip>] [-c <max connections>] [-u <daemon user>]\n\n", *argv);
		exit(0);
	}

	while (-1 != (ch = getopt(argc, argv, "s:l:c:u:")))
	{
		switch (ch)
		{
			case 's':
				g_target_ip = optarg;
				break;
			case 'l':
				g_listen_ip = optarg;
				break;
			case 'c':
				g_connection_max = strtol(optarg, NULL, 10);
				break;
			case 'u':
				g_user = optarg;
				break;
		}
	}

	if (g_target_ip == NULL)
	{
		fprintf(stderr, "error: No PPTP server specified\n");
		exit(-1);
	}
	else
	{
		g_target_addr.sin_family = AF_INET;
		g_target_addr.sin_addr.s_addr = inet_addr(g_target_ip);
		g_target_addr.sin_port = htons(PPTP_PORT);
	}

	if (0 != (g_ctrlchannel.in = _get_socket(SOCK_STREAM, IPPROTO_IP)))
	{
		SIN sin;

		bzero(&sin, sizeof(SIN));
		sin.sin_family = AF_INET;
		sin.sin_port = htons(PPTP_PORT);
		sin.sin_addr.s_addr = inet_addr(g_listen_ip);

		if (-1 == bind(g_ctrlchannel.in, (SA*) &sin, sizeof(SIN)))
		{
			fprintf(stderr, "error: Could not bind listen socket (%s)\n", strerror(errno));
			exit(-1);
		}
	}
	else
	{
		fprintf(stderr, "error: Could not create tcp listen socket (%s)\n", strerror(errno));
		exit(-1);
	}

	if (0 < (g_tunnel = _get_socket(SOCK_RAW, IPPROTO_GRE)))
	{
		int opt = 0;

		if (setsockopt(g_tunnel, 0, IP_HDRINCL, &opt, sizeof(opt)))
		{
			fprintf(stderr, "error: Could not setsockopt(IP_HDRINCL) for gre socket (%s)\n", strerror(errno));
			exit(-1);
		}
	}
	else
	{
		fprintf(stderr, "error: Could not create gre socket (%s)\n", strerror(errno));
		exit(-1);
	}

	if ((g_user) && (0 != _drop_priv_perm(g_user)))
	{
		fprintf(stderr, "error: Could not change user (%s)\n", strerror(errno));
		exit(-1);
	}

	openlog(g_vendor, LOG_PID, LOG_DAEMON);
	g_buffer.size = 4096 * 4;
	g_buffer.data = calloc(1, g_buffer.size);
	g_connection_list = calloc(g_connection_max, sizeof(ProxyConnection*));
	g_call_max = g_connection_max * 2;
	g_call_list = calloc(g_call_max, sizeof(ProxyConnection*));

	listen(g_ctrlchannel.in, 0);
	while (run)
	{
		int i;
		int topFd;
		fd_set fdSet;

		topFd = g_tunnel;
		FD_ZERO(&fdSet);
		FD_SET(g_ctrlchannel.in, &fdSet);
		FD_SET(g_tunnel, &fdSet);
		if (g_ctrlchannel.out)
		{
			FD_SET(g_ctrlchannel.out, &fdSet);
			if (g_ctrlchannel.out > topFd) topFd = g_ctrlchannel.out;
		}
		for (i = 0; i < g_connection_max; i++)
		{
			if (g_connection_list[i] && g_connection_list[i]->socket > 0)
			{
				FD_SET(g_connection_list[i]->socket, &fdSet);
				if (topFd < g_connection_list[i]->socket) topFd = g_connection_list[i]->socket;
			}
		}

		select(topFd + 1, &fdSet, NULL, NULL, NULL);
		if (FD_ISSET(g_ctrlchannel.in, &fdSet)) _handle_connection();

		if (g_ctrlchannel.out && FD_ISSET(g_ctrlchannel.out, &fdSet))
		{
			if (0 < (g_buffer.length = recvfrom(g_ctrlchannel.out, g_buffer.data, g_buffer.size, 0, NULL, NULL)))
			{
				struct pptp_msg *pptp = (struct pptp_msg*) g_buffer.data;

				if (g_buffer.length == ntohs(pptp->length) && (MAGIC_COOKIE == ntohl(pptp->magic_cookie)))
				{
#ifdef PACKET_DEBUG
					_print_msg(999);
#endif
					_process_server_data();
				}
			}
			else
			{
				syslog(LOG_INFO, "Server closed the connection");
				close(g_ctrlchannel.out);
				g_ctrlchannel.out = 0;
				g_proxy.state = DOWN;

				/* Send Call-Disconnect-Notify to all ongoing calls */
				for (i = 0; i < g_call_max; i++)
				{
					if (g_call_list[i])
					{
						_send_cdn(g_call_list[i]->connection->socket, (i ^ g_proxy.call_obfuscator), CDN_CARRIER, 0, 0, NULL);
						free(g_call_list[i]);
						g_call_list[i] = NULL;
						g_call_count--;
					}
				}

				/* Send Stop-Control-Connection-Request to all open connections */
				for (i = 0; i < g_connection_max; i++)
				{
					if (g_connection_list[i])
					{
						_send_tccrq(g_connection_list[i]->socket, 1);
						free(g_connection_list[i]);
						g_connection_list[i] = NULL;
						g_connection_count--;
					}
				}
			}
		}

		if (FD_ISSET(g_tunnel, &fdSet))
		{
			int slen = sizeof(SIN);
			SIN saddr;

			/* Process 10 gre packets or as many there are available,
			 * this is supposed to be a performance improvement.. */
			i = 10;
			do
			{
				if (0 < (g_buffer.length = recvfrom(g_tunnel, g_buffer.data, g_buffer.size, MSG_DONTWAIT, (SA*) &saddr, &slen)))
				{
					int sent;
					int call_id;
					struct gre_header *gre = (struct gre_header*) (g_buffer.data + 20);
					CallData *call;

					call_id = (gre->call_id ^ g_proxy.call_obfuscator);
					if ((call_id < g_call_max) && (call = g_call_list[call_id]))
					{
						if (call->connection->saddr.sin_addr.s_addr == saddr.sin_addr.s_addr)
						{
							gre->call_id = call->server_id;
							sent = sendto(g_tunnel, g_buffer.data + 20, g_buffer.length - 20, 0, (SA*) &g_target_addr, sizeof(SIN));
						}
						else
						{
							gre->call_id = call->client_id;
							sent = sendto(g_tunnel, g_buffer.data + 20, g_buffer.length - 20, 0, (SA*) &call->connection->saddr, sizeof(SIN));
						}
					}
				}
			} while ((g_buffer.length > 0) && i--);
		}

		for (i = 0; i < g_connection_max; i++)
		{
			ProxyConnection *conn;

			conn = g_connection_list[i];
			if (conn && FD_ISSET(conn->socket, &fdSet))
			{
				if (0 < (g_buffer.length = recvfrom(conn->socket, g_buffer.data, g_buffer.size, 0, NULL, NULL)))
				{
					struct pptp_msg *pptp = (struct pptp_msg*) g_buffer.data;

					if (g_buffer.length == ntohs(pptp->length) && (MAGIC_COOKIE == ntohl(pptp->magic_cookie)))
					{
#ifdef PACKET_DEBUG
						_print_msg(i);
#endif
						_process_client_data(conn);
					}
				}
				else
				{	/* Connection to the client was lost */
					g_connection_count--;
					syslog(LOG_INFO, "Connection closed %s:%u (%.3u/%.3u)", inet_ntoa(conn->saddr.sin_addr),
							conn->saddr.sin_port, g_connection_count, g_connection_max);
					if (conn->state == PENDING) g_connection_pending--;
					if (conn->state == UP)
					{
						int j;

						/* For each outgoing call from this client we should send a
						 * Call-Disconnect-Notify to the server stating NO_CARRIER as error */
						for (j = 0; j < g_call_max; j++)
						{
							if ((g_call_list[j]) && (g_call_list[j]->connection == conn))
							{
								_send_cdn(g_ctrlchannel.out, (j ^ g_proxy.call_obfuscator), CDN_CARRIER, 0, 0, NULL);
								free(g_call_list[j]);
								g_call_list[j] = NULL;
								g_call_count--;
							}
						}
						g_connection_up--;
					}
					g_connection_list[i] = NULL;
					close(conn->socket);
					free(conn);
				}
			}
		}

		if (g_connection_pending && (g_proxy.state == UP))
		{
			for (i = 0; i < g_connection_max; i++)
			{
				ProxyConnection *conn;

				if ((conn = g_connection_list[i]))
				{
					if (conn->state == PENDING)
					{
						g_connection_pending--;
						g_connection_up++;
						conn->state = UP;
						_send_sccrp(conn->socket, 1, 0, SCC_OK, 0, g_proxy.framing_cap, g_proxy.bearer_cap,
								g_proxy.max_channels, g_proxy.firmware_rev, (char*) &g_proxy.hostname, (char*) g_vendor);
					}
				}
			}
		}

		if ((g_proxy.state == DOWN) && (g_connection_up || g_connection_pending))
		{
			for (i = 0; i < g_call_max; i++)
			{
				if (g_call_list[i])
				{
					_send_cdn(g_call_list[i]->connection->socket, (i ^ g_proxy.call_obfuscator), CDN_CARRIER, 0, 0, NULL);
					free(g_call_list[i]);
					g_call_list[i] = NULL;
					g_call_count--;
				}
			}
			for (i = 0; i < g_connection_max; i++)
			{
				ProxyConnection *conn;

				if ((conn = g_connection_list[i]))
				{
					if (conn->state == PENDING)
					{
						_send_sccrp(conn->socket, 1, 0, SCC_ERROR, NO_RSRC, 0, 0, 0, 0,  NULL, NULL);
						g_connection_pending--;
					}
					if (conn->state == UP)
					{
						_send_tccrq(g_connection_list[i]->socket, 1);
						g_connection_up--;
					}
					g_connection_list[i] = NULL;
					close(conn->socket);
					free(conn);
				}
			}
		}
	}

	close(g_ctrlchannel.in);
	close(g_ctrlchannel.out);
	closelog();
	return 0;
}
