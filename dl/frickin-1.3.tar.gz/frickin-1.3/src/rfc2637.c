/*	Frickin PPTP Proxy, Copyright (c) 2004 Martin Akesson <ma@placid.tv>

	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the
	"Software"), to deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to
	permit persons to whom the Software is furnished to do so, subject to
	the following conditions:

	The above copyright notice and this permission notice shall be
	included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "main.h"
#include "rfc2637.h"

extern DataBuffer g_buffer;

const char *pptp_msg_names[] =
{
	NULL,
	"Start-Control-Connection-Request",
	"Start-Control-Connection-Reply",
	"Stop-Control-Connection-Request",
	"Stop-Control-Connection-Reply",
	"Echo-Request",
	"Echo-Reply",
	"Outgoing-Call-Request",
	"Outgoing-Call-Reply",
	"Incoming-Call-Request",
	"Incoming-Call-Reply",
	"Incoming-Call-Connected",
	"Call-Clear-Request",
	"Call-Disconnect-Notify",
	"WAN-Error-Notify",
	"Set-Link-Info"
};

const char *pptp_error_names[] =
{
	"No error",
	"Not connected",
	"Bad format",
	"Bad value",
	"No resource",
	"Bad CALL-ID",
	"PAC error"
};

int _send_sccrq(int a_socket, int a_protocol_u, int a_protocol_l,
		int a_framing_cap, int a_bearer_cap, int a_max_channels,
		int a_firmware_rev, char *a_hostname, char *a_vendor)
{
	struct sccrq_msg *sccrq = (struct sccrq_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct sccrq_msg));
	sccrq->length = htons(sizeof(struct sccrq_msg));
	sccrq->type = htons(1);
	sccrq->magic_cookie = htonl(MAGIC_COOKIE);
	sccrq->ctrl_type = htons(SCCRQ);
	sccrq->protocol_u = a_protocol_u;
	sccrq->protocol_l = a_protocol_l;
	sccrq->framing_cap = htonl(a_framing_cap);
	sccrq->bearer_cap = htonl(a_bearer_cap);
	sccrq->max_channels = htons(a_max_channels);
	sccrq->firmware_rev = htons(a_firmware_rev);
	if (a_hostname) strncpy(sccrq->hostname, a_hostname, 64);
	if (a_vendor) strncpy(sccrq->vendor, a_vendor, 64);
	return send(a_socket, g_buffer.data, sizeof(struct sccrq_msg), 0);
}

int _send_sccrp(int a_socket, int a_protocol_u, int a_protocol_l, int a_result, int a_error,
		unsigned int a_framing_cap, unsigned int a_bearer_cap, int a_max_channels,
		int a_firmware_rev, char *a_hostname, char *a_vendor)
{
	struct sccrp_msg *sccrp = (struct sccrp_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct sccrp_msg));
	sccrp->length = htons(sizeof(struct sccrp_msg));
	sccrp->type = htons(1);
	sccrp->magic_cookie = htonl(MAGIC_COOKIE);
	sccrp->ctrl_type = htons(SCCRP);
	sccrp->protocol_u = a_protocol_u;
	sccrp->protocol_l = a_protocol_l;
	sccrp->result = a_result;
	sccrp->error = a_error;
	sccrp->framing_cap = htonl(a_framing_cap);
	sccrp->bearer_cap = htonl(a_bearer_cap);
	sccrp->max_channels = htons(a_max_channels);
	sccrp->firmware_rev = htons(a_firmware_rev);
	if (a_hostname) strncpy(sccrp->hostname, a_hostname, 64);
	if (a_vendor) strncpy(sccrp->vendor, a_vendor, 64);
	return send(a_socket, g_buffer.data, sizeof(struct sccrp_msg), 0);
}

int _send_ecorq(int a_socket, int a_identifier)
{
	struct ecorq_msg *ecorq = (struct ecorq_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct ecorq_msg));
	ecorq->length = htons(sizeof(struct ecorq_msg));
	ecorq->type = htons(1);
	ecorq->magic_cookie = htonl(MAGIC_COOKIE);
	ecorq->ctrl_type = htons(ECORQ);
	ecorq->identifier = htonl(a_identifier);
	return send(a_socket, g_buffer.data, sizeof(struct ecorq_msg), 0);
}

int _send_ecorp(int a_socket, int a_identifier, int a_result, int a_error)
{
	struct ecorp_msg *ecorp = (struct ecorp_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct ecorp_msg));
	ecorp->length = htons(sizeof(struct ecorp_msg));
	ecorp->type = htons(1);
	ecorp->magic_cookie = htonl(MAGIC_COOKIE);
	ecorp->ctrl_type = htons(ECORP);
	ecorp->identifier = htonl(a_identifier);
	ecorp->result = a_result;
	ecorp->error = a_error;
	return send(a_socket, g_buffer.data, sizeof(struct ecorp_msg), 0);
}

int _send_ocrq(int a_socket, int a_call_id, unsigned int a_min_bps, unsigned int a_max_bps,
		unsigned int a_bearer_type, unsigned int a_framing_type, int a_recv_win_sz,
		int a_proc_delay, int *a_number_length, char *a_phone_number, char *a_subaddress)
{
	struct ocrq_msg *ocrq = (struct ocrq_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct ocrq_msg));
	ocrq->length = htons(sizeof(struct ocrq_msg));
	ocrq->type = htons(1);
	ocrq->magic_cookie = htonl(MAGIC_COOKIE);
	ocrq->ctrl_type = htons(OCRQ);
	ocrq->call_id = a_call_id;
	ocrq->min_bps = htonl(a_min_bps);
	ocrq->max_bps = htonl(a_max_bps);
	ocrq->bearer_type = htonl(a_bearer_type);
	ocrq->framing_type = htonl(a_framing_type);
	ocrq->recv_win_sz = htons(a_recv_win_sz);
	ocrq->proc_delay = htons(a_proc_delay);
	if (a_phone_number) strncpy(ocrq->phone_number, a_phone_number, 64);
	if (a_subaddress) strncpy(ocrq->subaddress, a_subaddress, 64);
	return send(a_socket, g_buffer.data, sizeof(struct ocrq_msg), 0);
}

int _send_ocrp(int a_socket, int a_call_id, int a_peer_call_id, int a_result, int a_error,
		int a_cause, unsigned int a_speed, int a_recv_win_sz, int a_proc_delay, unsigned int a_channel_id)
{
	struct ocrp_msg *ocrp = (struct ocrp_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct ocrp_msg));
	ocrp->length = htons(sizeof(struct ocrp_msg));
	ocrp->type = htons(1);
	ocrp->magic_cookie = htonl(MAGIC_COOKIE);
	ocrp->ctrl_type = htons(OCRP);
	ocrp->call_id = a_call_id;
	ocrp->peer_call_id = a_peer_call_id;
	ocrp->result = a_result;
	ocrp->error = a_error;
	ocrp->cause = htons(a_cause);
	ocrp->speed = htonl(a_speed);
	ocrp->recv_win_sz = htons(a_recv_win_sz);
	ocrp->proc_delay = htons(a_proc_delay);
	ocrp->channel_id = htonl(a_channel_id);
	return send(a_socket, g_buffer.data, sizeof(struct ocrp_msg), 0);
}

int _send_tccrq(int a_socket, int a_reason)
{
	struct tccrq_msg *tccrq = (struct tccrq_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct tccrq_msg));
	tccrq->length = htons(sizeof(struct tccrq_msg));
	tccrq->type = htons(1);
	tccrq->magic_cookie = htonl(MAGIC_COOKIE);
	tccrq->ctrl_type = htons(TCCRQ);
	tccrq->reason = htons(a_reason);
	return send(a_socket, g_buffer.data, sizeof(struct tccrq_msg), 0);
}

int _send_tccrp(int a_socket, int a_result, int a_error)
{
	struct tccrp_msg *tccrp = (struct tccrp_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct tccrp_msg));
	tccrp->length = htons(sizeof(struct tccrp_msg));
	tccrp->type = htons(1);
	tccrp->magic_cookie = htonl(MAGIC_COOKIE);
	tccrp->ctrl_type = htons(TCCRP);
	tccrp->result = a_result;
	tccrp->error = a_error;
	return send(a_socket, g_buffer.data, sizeof(struct tccrp_msg), 0);
}

int _send_ccrq(int a_socket, int a_call_id)
{
	struct ccrq_msg *ccrq = (struct ccrq_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct ccrq_msg));
	ccrq->length = htons(sizeof(struct ccrq_msg));
	ccrq->type = htons(1);
	ccrq->magic_cookie = htonl(MAGIC_COOKIE);
	ccrq->ctrl_type = htons(CCRQ);
	ccrq->call_id = a_call_id;
	return send(a_socket, g_buffer.data, sizeof(struct ccrq_msg), 0);
}

int _send_cdn(int a_socket, int a_call_id, int a_result, int a_error, int a_cause, char *a_stats)
{
	struct cdn_msg *cdn = (struct cdn_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct cdn_msg));
	cdn->length = htons(sizeof(struct cdn_msg));
	cdn->type = htons(1);
	cdn->magic_cookie = htonl(MAGIC_COOKIE);
	cdn->ctrl_type = htons(CDN);
	cdn->call_id = a_call_id;
	cdn->result = a_result;
	cdn->error = a_error;
	cdn->cause = htons(a_cause);
	if (a_stats) memcpy(cdn->stats, a_stats, 128);
	return send(a_socket, g_buffer.data, sizeof(struct cdn_msg), 0);
}

int _send_sli(int a_socket, int a_call_id, int a_sendaccm, int a_recvaccm)
{
	struct sli_msg *sli = (struct sli_msg*) g_buffer.data;

	memset(g_buffer.data, 0, sizeof(struct sli_msg));
	sli->length = htons(sizeof(struct sli_msg));
	sli->type = htons(1);
	sli->magic_cookie = htonl(MAGIC_COOKIE);
	sli->ctrl_type = htons(SLI);
	sli->peer_call_id = a_call_id;
	sli->send_accm = a_sendaccm;
	sli->receive_accm = a_recvaccm;
	return send(a_socket, g_buffer.data, sizeof(struct sli_msg), 0);
}
