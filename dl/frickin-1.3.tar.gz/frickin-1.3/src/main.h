/*	Frickin PPTP Proxy, Copyright (c) 2004 Martin Akesson <ma@placid.tv>

	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the
	"Software"), to deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to
	permit persons to whom the Software is furnished to do so, subject to
	the following conditions:

	The above copyright notice and this permission notice shall be
	included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

typedef struct sockaddr SA;
typedef struct sockaddr_in SIN;

enum conn_state {DOWN, PENDING, UP};

struct data_buffer
{
	unsigned char *data;
	int size;
	int length;
};
typedef struct data_buffer DataBuffer;

struct proxy_connection
{
	int socket;
	enum conn_state state;
	unsigned int addrlen;
	SIN saddr;
//	struct timeval active;
};
typedef struct proxy_connection ProxyConnection;

struct call_data
{
	unsigned int client_id;
	unsigned int server_id;
	ProxyConnection *connection;
};
typedef struct call_data CallData;

struct proxy_state
{
	enum conn_state state;
	unsigned int framing_cap;
	unsigned int bearer_cap;
	int max_channels;
	int firmware_rev;
	char hostname[64];
	char vendor[64];
	unsigned int call_obfuscator;
};
typedef struct proxy_state ProxyState;
