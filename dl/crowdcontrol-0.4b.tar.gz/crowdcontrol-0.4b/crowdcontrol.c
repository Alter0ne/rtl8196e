/*
 * Crowd Control HTTP Proxy, version 0.4 beta
 *
 * Copyright (c) 2005 Tokachu. Portions copyright (c) 2004, 2005 Christopher
 * Devine.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 U.S.A.
 */
 
#ifndef WIN32

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <unistd.h>
#include <netdb.h>

#define recv(a,b,c,d) read(a,b,c)
#define send(a,b,c,d) write(a,b,c)

#else

#pragma comment(lib, "ws2_32.lib")

#include <winsock2.h>
#include <windows.h>

#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <regex.h>

#ifndef uint32
#define uint32 unsigned long int
#endif

#define MAXIMUM_FILE_DESCRIPTORS 1024
#define URLBUF_SIZE 4096
#define URLBUF_STRL 4095
#define HOST_SIZE 128

#ifndef TCP_WINDOW_SIZE
#define TCP_WINDOW_SIZE 8192
#endif

#define child_exit(ret)     \
	shutdown(client_fd, 2); \
	shutdown(remote_fd, 2); \
	close(client_fd);       \
	close(remote_fd);       \
	return(ret);

/* Constants. */
const int REGFLAGS = REG_NOSUB | REG_EXTENDED | REG_ICASE;
const int PERMITTED = 0, BLOCKED = 1;

/* Structure to hold a linked list of regular expressions. */
struct regex_item
{
	regex_t reg;
	int isdom;
	char *domain;
	struct regex_item *next;
};

/* Linked list of regular expressions. */
struct regex_item *permitted_urls, *blocked_urls;

/* Global identifiers. */
int _GLOBAL_MAX_CONNECTIONS = 16;
int _GLOBAL_IMPLICITACTION  = 0;
char *_GLOBAL_FILEMODE      = "rt";
char *_GLOBAL_ERRPARAM      = "%s: Parameter required for %s.\n";
char *_GLOBAL_ERRNOFILE     = "%s: Cannot open \"%s\".\n";
char *_GLOBAL_ERRNOMEM      = "%s: Out of memory.\n";
char *_GLOBAL_ERRREGEX      = "%s: Error converting \'%s\' to regex.\n";

/* Web-based error messages. */
int _GLOBAL_SIZEOF_BLOCKTEXT = 68;
char *_GLOBAL_BLOCKTEXT      =
"HTTP/1.0 410 Gone\r\n"
"Content-type: text/plain\r\n"
"Content-length: 0\r\n"
"\r\n\r\n";

int _GLOBAL_SIZEOF_BLOCKIMG  = 117;
char *_GLOBAL_BLOCKIMG       =
"HTTP/1.0 410 Gone\r\n"
"Content-type: image/gif\r\n"
"Content-length: 49\r\n\r\n"
"GIF89a\x01\x00\x01\x00\xa1\x01\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff"
"\xff\xff\x21\xf9\x04\x01\n\x00\x01\x00\x2c\x00\x00\x00\x00\x01\x00\x01\x00"
"\x00\x02\x02L\x01\x00;\r\n";

enum
{
	PARAM_PORT = 1,
	PARAM_BIND,
	PARAM_SUBNET,
	PARAM_MAXCONNECTIONS,
	PARAM_HTTPONLY,
	PARAM_HTTPWITHSSL,
	PARAM_HTTPTUNNEL,
	PARAM_IMPLICITLYDENY,
	PARAM_IMPLICITLYPERMIT,
	PARAM_PERMITDOMAINS,
	PARAM_PERMITURLS,
	PARAM_PERMITEXPRESSIONS,
	PARAM_DENYDOMAINS,
	PARAM_DENYURLS,
	PARAM_DENYEXPRESSIONS,
	PARAM_TESTURL
};

struct thread_data
{
	int client_fd;
	int log_fd;
	uint32 server_ip;
	uint32 auth_ip;
	uint32 netmask;
	uint32 client_ip;
	int connect;
};

/* Function declarations. */
char *dgets(FILE *stream);
struct regex_item *loaddomainfile(char *argv0, char *filename,
                                  struct regex_item *urllist);
struct regex_item *loadurlfile(char *argv0, char *filename,
                                   struct regex_item *urllist);
struct regex_item *loadexpressionfile(char *argv0, char *filename,
                                      struct regex_item *urllist);
struct regex_item *add_url(char *url, int isdom, struct regex_item *list);
int domainmatches(char *domain, int domain_s, char *filter, int filter_s);
int check_url(char *url, int isdom, struct regex_item *item);
int check_urls(char *url, int isdom);
int isregchar(char c);
int isurlchar(char c);
char x2c(char *what);
char *unescape_url(char *url, int len);
char *url2regex(char *domain);
void deny_access(int client_fd, int c_flag, char *url);
void log_request(uint32 client_ip, char *headers, int headers_len,
				 uint32 auth_ip, uint32 netmask);
int client_thread(struct thread_data *td);

/*
 * char *dgets(FILE *stream, int &n)
 *
 * Reads a line from a file, allocates memory to hold the line, and returns a
 * pointer to the string.
 */
char *dgets(FILE *stream)
{
	register char c;
	int size = 1;
	char *mystr = malloc(size);
	
	/* Go through the stream until we hit the end of the file or line. */
	while (!feof(stream) && (c = fgetc(stream)) & 0xE0)
	{
		if (c == '#' || c == ' ')
		{
			while (!feof(stream) && (fgetc(stream) != '\n'));
			return mystr;
		}
		
		/* Skip funny characters. */
		if (feof(stream) || !(c & 0xE0))
			continue;
		
		if ((mystr = realloc(mystr, ++size)))
		{
			mystr[size - 2] = c;
		}
		else
		{
			free(mystr);
			return NULL;
		}
	}
	
	if (size > 1)
	{
		mystr[size - 1] = '\0';
		return mystr;
	}
	else
	{
		free(mystr);
		return NULL;
	}
	
	free(mystr);
	return NULL;
}

/*
 * struct regex_item *loaddomainfile(char *argv0, char *filename,
 *                                   struct regex_item *urllist)
 *
 * Loads a list of domains from file "filename" into list "urllist". Returns a
 * pointer to the list upon success, NULL if it failed.
 */
struct regex_item *loaddomainfile(char *argv0, char *filename,
                                  struct regex_item *urllist)
{
	FILE *in;
	char *fileline = NULL;
	
	/* Process a list of domains. */
	if (filename)
	{
		if (!(in = fopen(filename, _GLOBAL_FILEMODE)))
		{
			fprintf(stderr, _GLOBAL_ERRNOFILE, argv0, urllist);
			return NULL;
		}
		
		while (!feof(in))
		{
			if (!(fileline = dgets(in)))
				continue;
			
			if (!(urllist = add_url(fileline, strlen(fileline), urllist)))
			{
				fprintf(stderr, _GLOBAL_ERRNOMEM, argv0);
				free(fileline);
				return NULL;
			}
		}
		
		free(fileline);
		fclose(in);
	}
	
	return urllist;
}

/*
 * struct regex_item *loadurlfile(char *argv0, char *filename,
 *                                struct regex_item *urllist)
 *
 * Loads a list of URLs from file "filename" into list "urllist". Returns a
 * pointer to the list upon success, NULL if it failed.
 */
struct regex_item *loadurlfile(char *argv0, char *filename,
                               struct regex_item *urllist)
{
	FILE *in;
	char *fileline = NULL;
	
	if (filename)
	{
		if (!(in = fopen(filename, _GLOBAL_FILEMODE)))
		{
			fprintf(stderr, _GLOBAL_ERRNOFILE, argv0, urllist);
			return NULL;
		}
		
		while (!feof(in))
		{
			if (!(fileline = dgets(in)))
				continue;
			
			if (!(fileline = url2regex(fileline)))
			{
				fprintf(stderr, _GLOBAL_ERRNOMEM, argv0);
				free(fileline);
				return NULL;
			}
			
			if (!(urllist = add_url(fileline, 0, urllist)))
			{
				fprintf(stderr, _GLOBAL_ERRREGEX, argv0, fileline);
				free(fileline);
				return NULL;
			}
		}
		
		free(fileline);
		fclose(in);
	}
	
	return urllist;
}

/*
 * struct regex_item *loadexpressionfile(char *argv0, char *filename,
 *                                       struct regex_item *urllist)
 *
 * Loads a list of regular expressions from file "filename" into list
 * "urllist". Returns a pointer to the list upon success, NULL if it failed.
 */
struct regex_item *loadexpressionfile(char *argv0, char *filename,
                                      struct regex_item *urllist)
{
	FILE *in;
	char *fileline = NULL;
	
	if (filename)
	{
		if (!(in = fopen(filename, _GLOBAL_FILEMODE)))
		{
			fprintf(stderr, _GLOBAL_ERRNOFILE, argv0, filename);
			return NULL;
		}
		
		while (!feof(in))
		{
			if (!(fileline = dgets(in)))
				continue;
			
			if (!(urllist = add_url(fileline, 0, urllist)))
			{
				fprintf(stderr, _GLOBAL_ERRREGEX, argv0, fileline);
				free(fileline);
				return NULL;
			}
		}
		
		free(fileline);
		fclose(in);
	}
	
	return urllist;
}

/*
 * struct regex_item *add_url(char *url, int isdom, struct regex_item *list)
 *
 * Add a regular expression to the linked list. It returns a pointer to the
 * beginning of the linked list if the addition succeeds, or NULL otherwise.
 */
struct regex_item *add_url(char *url, int isdom, struct regex_item *list)
{	
	if (!list)
	{
		/* If the list is empty, create the first item in the linked list. */
		if ((list = malloc(sizeof(*list))))
		{
			if (isdom)
			{
				list->isdom = strlen(url);
				
				/* If the memory cannot be allocated, bail out. */
				if (!(list->domain = malloc(list->isdom + 1)))
					return NULL;
				
				strncpy(list->domain, url, list->isdom);
			}
			else
			{
				/* If the regex can't be compiled, bail out. */
				if (regcomp(&list->reg, url, REGFLAGS))
					return NULL;
				
				list->isdom = 0;
				list->domain = NULL;
			}
			
			list->next = NULL;
			return list;
		}
		else
			return NULL;
	}
	else
	{
		/* If the list has items, add another item to the linked list. */
		struct regex_item *current;
		current = list;
		
		/* Seek to the end of the list. */
		while (current->next)
			current = current->next;
		
		/* Create a new item. */
		if ((current->next = malloc(sizeof(*current))))
		{
			current = current->next;
			
			if (isdom)
			{
				current->isdom = strlen(url);
				
				/* If the memory cannot be allocated, bail out. */
				if (!(current->domain = malloc(list->isdom + 1)))
					return NULL;
				
				strncpy(current->domain, url, current->isdom);
			}
			else
			{
				/* If the regex can't be compiled, bail out. */
				if (regcomp(&current->reg, url, REGFLAGS))
					return NULL;
				
				current->isdom = 0;
			}
			
			current->next = NULL;
			return list;
		}
		else
			return NULL;
	}
	
	/* As a default measure, return NULL. */
	return NULL;
}

/*
 * int domainmatches(char *domain, int domain_s, char *filter, int filter_s)
 *
 * Checks to see if the string "domain" is the same as "filter".
 */
int domainmatches(char *domain, int domain_s, char *filter, int filter_s)
{
	if (domain_s < filter_s)
		return 0;
	
	if (domain_s == filter_s || filter[filter_s - 1] == '.')
		return (!strncmp(domain, filter, domain_s));
	
	domain_s -= filter_s;
	
	if (domain[domain_s - 1] == '.')
	{
		if (!strncmp((char *)(domain + domain_s), filter, filter_s))
			return 1;
	}
	
	return 0;
}

/*
 * int check_url(char *url, int isdom, struct regex_item *item)
 *
 * Go through a single list of regular expressions to find a match for "url".
 * Returns 1 (true) if a match was found, 0 (false) otherwise.
 */
int check_url(char *url, int isdom, struct regex_item *item)
{
	struct regex_item *current = item;
	
	/* If the list is empty, just return 0. */
	if (!item)
		return 0;
	
	while (current)
	{	
		/* If we reach the end of the domain list with no matches, return 0. */
		if (isdom)
		{
			if (!(current->isdom))
				return 0;
			
			if (domainmatches(url, strlen(url), current->domain,
							  current->isdom))
				return 1;
		}
		
		/* If we find a match, return 1. */
		if (!regexec(&current->reg, url, 0, NULL, 0))
			return 1;
		
		/* Seek to the next element. */
		current = current->next;
	}
	
	/* If no match is found, return 0. */
	return 0;
}

/*
 * int check_urls(char *url, int isdom)
 *
 * Checks to see if a URL should be permitted or blocked. Returns 1 (true) if
 * the URL should be permitted, or 0 (false) if it should be blocked.
 */
int check_urls(char *url, int isdom)
{
	if (check_url(url, isdom, permitted_urls))
	{
		return 1;
	}
	else
	{
		if (_GLOBAL_IMPLICITACTION == BLOCKED)
			return 0;
		
		if (check_url(url, isdom, blocked_urls))
			return 0;
	}
	
	return 1;
}

/*
 * int isregchar(char c)
 *
 * Checks to see if a character should be preceeded with a blackslash for a
 * regular expression. Returns 1 (true) if it should, 0 (false) otherwise.
 */
int isregchar(char c)
{
	return (c == '.' || c == '?' || c == '+' || c == '[' || c == ']' ||
			c == '\\'|| c == '{' || c == '}' || c == '*' || c == '(' ||
			c == ')' || c == '$' || c == '^' || c == '|');
}

/*
 * int isurlchar(char c)
 *
 * Checks to see if a character (in a URL) should NOT be percent-encoded.
 * Returns 0 (false) if the character should be percent-encoded, 1 (true)
 * otherwise.
 */
int isurlchar(char c)
{
	return (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~');
}

/*
 * char x2c(char *what)
 *
 * Decode a percent-encoded character (routine from the original NCSA server).
 */
char x2c(char *what)
{
	register char c;
	
	c = (what[0] >= 'A' ? ((what[0] & 0xDF) - 'A') + 10 : (what[0] - '0'));
	c *= 16;
	c +=(what[1] >= 'A' ? ((what[1] & 0xDF) - 'A') + 10 : (what[1] - '0'));
	
	return isurlchar(c) ? c : 0;
}

/*
 * char *unescape_url(char *url, int len)
 *
 * Unescape a URL (routine from the original NCSA server).
 */
char *unescape_url(char *url, int len)
{
	int x, y;
	char c, *newurl = malloc(len + 1);
	
	for (x = 0, y = 0; url[x] && x < len; ++x, ++y)
	{
		if ((newurl[x] = url[y]) == '%')
		{
			if ((c = x2c(&url[y + 1])))
			{
				newurl[x] = c;
				y += 2;
			}
		}
	}
	
	newurl[x] = '\0';
	return newurl;
}

/*
 * char *url2regex(char *domain)
 *
 * Converts a URL segment to a valid regular expression string.
 */
char *url2regex(char *domain)
{
	int i, domsize = 20, chars = 19;
	char *regex;
	
	for (i = 0; domain[i]; i++)
	{
		if (isregchar(domain[i]))
			domsize++;
		domsize++;
	}
	
	if (!(regex = malloc(domsize)))
		return NULL;
	
	strncpy(regex, "^([a-z0-9\\._-]+\\.)?", domsize);
	
	for (i = 0; domain[i] && chars < domsize; i++)
	{
		if (isregchar(domain[i]))
			regex[chars++] = '\\';
		regex[chars++] = domain[i];
	}
	
	regex[chars] = '\0';
	return regex;
}

/*
 * void deny_access(struct thread_data *td, int c_flag)
 *
 * Returns a "410 Gone" error with an appropriate file (for HTTP requests), or
 * just closes the connection (for HTTPS/tunnel connections).
 */
void deny_access(int client_fd, int c_flag, char *url)
{
	if (!c_flag)
	{
		/* Quick and dirty way to find the file extension. */
		int i = 0, loc = 0;
		
		while (url[i++])
		{
			if (url[i] == '.')
			{
				loc = i + 1;
			}
			
			if (url[i] == '?')
				break;
		}
		
		char *ext = malloc(4);
		strncpy(ext, (char *)(url + loc), 3);
		ext[3] = '\0';
		
		if (!strcasecmp(ext, "gif") || !strcasecmp(ext, "jpg") ||
			!strcasecmp(ext, "png") || !strcasecmp(ext, "jpe"))
		{
			send(client_fd, _GLOBAL_BLOCKIMG, _GLOBAL_SIZEOF_BLOCKIMG,
				 0);
		}
		else
		{
			send(client_fd, _GLOBAL_BLOCKTEXT, _GLOBAL_SIZEOF_BLOCKTEXT,
				 0);
		}
	}
}

/*
 * void log_request(uint32 client_ip, char *headers, int headers_len,
 *                  uint32 auth_ip, uint32 netmask)
 *
 * Logs a request.
 * TODO: Change this to make an SNMP broadcast.
 */
void log_request(uint32 client_ip, char *headers, int headers_len,
				 uint32 auth_ip, uint32 netmask)
{
	int i;
	time_t t;
	struct tm *lt;
	char hyphen[2] = "-";
	char *buffer;
	char strbuf[16];
	char *ref, *u_a;
	
	buffer = malloc(headers_len + 1);
	memcpy(buffer, headers, headers_len + 1);
	
	/* Find the Referer: and User-Agent: headers. */
	strncpy(strbuf, "Referer: ", sizeof(strbuf));
	ref = strstr(buffer, strbuf);
	ref = ((ref) ? ref + 9 : hyphen);
	
	strncpy(strbuf, "User-Agent: ", sizeof(strbuf));
	u_a = strstr(buffer, strbuf);
	u_a = ((u_a) ? u_a + 12 : hyphen);
	
	/* Replace special characters with a space. */
	for (i = 0; i < headers_len; i++)
	{
		if (buffer[i] < ' ' || buffer[i] > '~')
		{
			if (buffer[i] == '\r' && buffer[i + 1] == '\n')
				buffer[i] = '\0';
			else
				buffer[i] = ' ';
		}
	}
	
	/* Put the information together and send it out. */
	t = time(NULL);
	lt = localtime(&t);
	lt->tm_year += 1900;
	lt->tm_mon++;
	
	int quads[4] = {
		(int)(client_ip)       & 0xFF,
		(int)(client_ip >>  8) & 0xFF,
		(int)(client_ip >> 16) & 0xFF,
		(int)(client_ip >> 24) & 0xFF
	};
	
	free(buffer);
	
	char *logstr = malloc(headers_len + 1);
	sprintf(logstr, "[%04d-%02d-%02d %02d:%02d:%02d] "
			"%d.%d.%d.%d \"%s\" \"%s\" \"%s\"", lt->tm_year,
			lt->tm_mon, lt->tm_mday, lt->tm_hour, lt->tm_min, lt->tm_sec,
		    quads[0], quads[1], quads[2], quads[3], buffer, ref, u_a);
	
	/* Insert SNMP-sending thing here. */
	auth_ip |= (~netmask);
}

#ifdef WIN32
HANDLE tdSem;
#define close(fd) closesocket(fd)
#endif

int client_thread(struct thread_data *td)
{
	int remote_fd = -1, remote_port, state, c_flag, n, client_fd, loc;
	uint32 client_ip;
	
	char *str_end, *current_url, c;
	char *url_host, buffer[URLBUF_SIZE], *url_port, last_host[HOST_SIZE];
	
	struct sockaddr_in remote_addr;
	struct hostent *remote_host;
	struct timeval timeout;
	
	fd_set rfds;
	
	client_fd = td->client_fd;
	client_ip = td->client_ip;
	
#ifdef WIN32
	/* Let the master thread continue. */
	ReleaseSemaphore(tdSem, 1, NULL);
#endif
	
	/* Fetch the HTTP request headers. */
	FD_ZERO(&rfds);
	FD_SET((unsigned int)client_fd, &rfds);
	
	timeout.tv_sec = 10;
	timeout.tv_usec = 0;
	
	if (select(client_fd + 1, &rfds, NULL, NULL, &timeout) <= 0)
	{
		child_exit(11);
	}
	
	if ((n = recv(client_fd, buffer, URLBUF_STRL, 0)) <= 0)
	{
		child_exit(12);
	}
	
	memset(last_host, 0, sizeof(last_host));
	
process_request:
	buffer[n] = '\0';
	
	/* Log the client request. */
	/*
	if (td->logfile)
		log_request(td->client_ip, buffer, n, td->auth_ip, td->netmask);
	*/

	/* Look to see if the HTTP request is a CONNECT method or not. */
	c_flag = 0;
	
	if (!strncmp(buffer, "CONNECT ", 8))
	{
		if (!td->connect)
		{
			child_exit(13);
		}
		
		c_flag = 1;
	}
	
	/* Skip the HTTP method. */
	
	url_host = buffer;
	while (*url_host != ' ')
	{
		if ((url_host - buffer) > 10 || !(*url_host))
		{
			child_exit(14);
		}
		
		url_host++;
	}
	
	url_host++;
	
	/* Get the HTTP server hostname. */
	if (!c_flag)
	{
		if (!strncmp(url_host, "http://", 7))
			url_host += 7;
		else
		{
			child_exit(15);
		}
	}
	
	/* Copy the requested URL to a temporary buffer for access control. */
	for (loc = 0; url_host[loc] != (c_flag ? ':' : ' ') &&
	     url_host[loc]; loc++);
	current_url = malloc(loc + 1);
	strncpy(current_url, url_host, loc);
	
	char *new_url;
	new_url = unescape_url(current_url, loc);
	free(current_url);
	current_url = new_url;
	
	/* Resolve the HTTP server hostname. */
	str_end = url_host;
	
	while (*str_end != ':' && *str_end != '/')
	{
		if ((str_end - url_host) >= HOST_SIZE || (!(*str_end)))
		{
			child_exit(16);
		}
		
		str_end++;
	}

	c = *str_end;
	*str_end = '\0';
	
	if (!check_urls(url_host, 1) || (!c_flag && !check_urls(current_url, 0)))
	{
		deny_access(client_fd, c_flag, current_url);
		free(current_url);
		
		if (c_flag)
		{
			child_exit(17);
		}
		
		goto process_request;
	}
	
	if (!(remote_host = gethostbyname(url_host)))
	{
		child_exit(18);
	}
	
	*str_end = c;
	
	/* Get the HTTP server port. */
	if (c != ':')
	{
		c           = *str_end;
		*str_end    = '\0';
		remote_port = 80;
	}
	else
	{
		url_port = ++str_end;
		while (*str_end != ' ' && *str_end != '/')
		{
			if (*str_end < '0' || *str_end > '9')
			{
				child_exit(19);
			}
			
			str_end++;
			
			if (str_end - url_port > 5)
			{
				child_exit(20);
			}
		}
		
		c           = *str_end;
		*str_end    = '\0';
		remote_port = atoi(url_port);
	}
	
	if (c_flag)
	{
		if ((td->connect == 1 && remote_port != 443) ||
		    (remote_port < 1 || remote_port > 65535))
		{
			child_exit(21);
		}
	}
	
	/* Connect to the remote server, if not already connected. */
	if (strcmp(url_host, last_host))
	{
		shutdown(remote_fd, 2);
		close(remote_fd);
		
		remote_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
		
		if (remote_fd < 0)
		{
			child_exit(22);
		}
		
		remote_addr.sin_family = AF_INET;
		remote_addr.sin_port   = htons((unsigned short)remote_port);
		
		memcpy((void *)&remote_addr.sin_addr, (void *)remote_host->h_addr,
		       remote_host->h_length);
		
		if (connect(remote_fd, (struct sockaddr *)&remote_addr,
			sizeof(remote_addr)) < 0)
		{
			child_exit(23);
		}
		
		memset(last_host, 0, sizeof(last_host));
		strncpy(last_host, url_host, sizeof(last_host) - 1);
	}
	
	*str_end = c;
	
	if (c_flag)
	{
		strncpy(buffer, "HTTP/1.0 200 Connection Established\r\n\r\n",
				sizeof(buffer));
		
		if (send(client_fd, buffer, 39, 0) != 39)
		{
			child_exit(24);
		}
	}
	else
	{
		int m_len;
		
		/* Remote "http://hostname[:port]" and send headers. */
		m_len = url_host - 7 - buffer;
		n -= 7 + (str_end - url_host);
		memcpy(str_end -= m_len, buffer, m_len);
		
		if (send(remote_fd, str_end, n, 0) != n)
		{
			child_exit(25);
		}
	}
	
	/* Tunnel the data between the client and the server. */
	state = 0;
	
	while (1)
	{
		FD_ZERO(&rfds);
		FD_SET((unsigned int)client_fd, &rfds);
		FD_SET((unsigned int)remote_fd, &rfds);
		
		n = (client_fd > remote_fd) ? client_fd : remote_fd;
		
		if (select(n + 1, &rfds, NULL, NULL, NULL) < 0)
		{
			child_exit(26);
		}
		
		if (FD_ISSET(remote_fd, &rfds))
		{
			if ((n = recv(remote_fd, buffer, URLBUF_STRL, 0)) <= 0)
			{
				child_exit(27);
			}
			
			state = 1;
			
			if (send(client_fd, buffer, n, 0) != n)
			{
				child_exit(28);
			}
		}
		
		if (FD_ISSET(client_fd, &rfds))
		{
			if ((n = recv(client_fd, buffer, URLBUF_STRL, 0)) <= 0)
			{
				child_exit(29);
			}
			
			if (state && !c_flag)
			{
				/* New HTTP request. */
				goto process_request;
			}
			
			if (send(remote_fd, buffer, n, 0) != n)
			{
				child_exit(30);
			}
		}
	}
	
	/* Not reached. */
	return -1;
}

int main(int argc, char **argv)
{
	int i, param = 0, rp = 0, proxy_port = 32800, proxy_fd, log_fd;
	char *permitdomains = NULL, *permiturls = NULL, *permitexpressions = NULL;
	char *denydomains = NULL, *denyurls = NULL, *denyexpressions = NULL;
	char *testurl = NULL;
	socklen_t n;
	
	struct sockaddr_in proxy_addr, client_addr;
	struct thread_data td;
	
	/* Read the program arguments. */
	td.server_ip = INADDR_ANY;
	td.auth_ip   = INADDR_ANY;
	td.netmask   = 0xFFFFFFFF;
	td.connect   = 2;
	
	for (i = 1; i < argc; i++)
	{
		if (argv[i][0] == '-')
		{
			if (rp)
			{
				fprintf(stderr, _GLOBAL_ERRPARAM, argv[0], argv[i - rp]);
			}
			
			if (argv[i][1] == '-')
			{
				if (!strcmp(argv[i], "--port"))
				{
					param = PARAM_PORT;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--bind"))
				{
					param = PARAM_BIND;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--subnet"))
				{
					param = PARAM_SUBNET;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--max-connections"))
				{
					param = PARAM_MAXCONNECTIONS;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--http-only"))
				{
					param = PARAM_HTTPONLY;
					continue;
				}
				
				if (!strcmp(argv[i], "--http-with-ssl"))
				{
					param = PARAM_HTTPWITHSSL;
					continue;
				}
				
				if (!strcmp(argv[i], "--http-tunnel"))
				{
					param = PARAM_HTTPTUNNEL;
					continue;
				}
				
				if (!strcmp(argv[i], "--implicitly-deny"))
				{
					param = PARAM_IMPLICITLYDENY;
					continue;
				}
				
				if (!strcmp(argv[i], "--implicitly-permit"))
				{
					param = PARAM_IMPLICITLYPERMIT;
					continue;
				}
				
				if (!strcmp(argv[i], "--permit-domains"))
				{
					param = PARAM_PERMITDOMAINS;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--permit-urls"))
				{
					param = PARAM_PERMITURLS;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--permit-expressions"))
				{
					param = PARAM_PERMITEXPRESSIONS;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--deny-domains"))
				{
					param = PARAM_DENYDOMAINS;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--deny-urls"))
				{
					param = PARAM_DENYURLS;
					rp = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--deny-expressions"))
				{
					param = PARAM_DENYEXPRESSIONS;
					rp    = 1;
					continue;
				}
				
				if (!strcmp(argv[i], "--test"))
				{
					param = PARAM_TESTURL;
					rp    = 1;
					continue;
				}
			}
			else
			{
				if (argv[i][1] == 'p')
				{
					param = PARAM_PORT;
					rp    = 1;
					continue;
				}
				
				if (argv[i][1] == 'a')
				{
					param = PARAM_BIND;
					rp    = 1;
					continue;
				}
				
				if (argv[i][1] == 's')
				{
					param = PARAM_SUBNET;
					rp    = 1;
					continue;
				}
				
				if (argv[i][1] == 'm')
				{
					param = PARAM_MAXCONNECTIONS;
					rp    = 1;
					continue;
				}
			}
		}
		else
		{
			switch (param)
			{
				case 0:
					break;
					
				case PARAM_PORT:
					proxy_port = atoi(argv[i]);
					--rp;
					break;
					
				case PARAM_BIND:
					td.auth_ip = td.server_ip = inet_addr(argv[i]);
					--rp;
					break;
					
				case PARAM_SUBNET:
					td.netmask = inet_addr(argv[i]);
					--rp;
					break;
					
				case PARAM_MAXCONNECTIONS:
					_GLOBAL_MAX_CONNECTIONS = atoi(argv[i]);
					if (!_GLOBAL_MAX_CONNECTIONS)
						_GLOBAL_MAX_CONNECTIONS = 16;
					--rp;
					break;
					
				case PARAM_HTTPONLY:
					td.connect = 0;
					break;
					
				case PARAM_HTTPWITHSSL:
					td.connect = 1;
					break;
					
				case PARAM_HTTPTUNNEL:
					td.connect = 2;
					break;
					
				case PARAM_IMPLICITLYDENY:
					_GLOBAL_IMPLICITACTION = BLOCKED;
					break;
					
				case PARAM_IMPLICITLYPERMIT:
					break;
					
				case PARAM_PERMITDOMAINS:
					permitdomains = argv[i];
					--rp;
					break;
					
				case PARAM_PERMITURLS:
					permiturls = argv[i];
					--rp;
					break;
					
				case PARAM_PERMITEXPRESSIONS:
					permitexpressions = argv[i];
					--rp;
					break;
					
				case PARAM_DENYDOMAINS:
					denydomains = argv[i];
					--rp;
					break;
					
				case PARAM_DENYURLS:
					denyurls = argv[i];
					--rp;
					break;
					
				case PARAM_DENYEXPRESSIONS:
					denyexpressions = argv[i];
					--rp;
					break;
					
				case PARAM_TESTURL:
					testurl = argv[i];
					--rp;
					break;
			}
			
			param = 0;
		}
	}
	
	if (rp)
	{
		fprintf(stderr, _GLOBAL_ERRPARAM, argv[0], argv[i - rp]);
		return 1;
	}
	
	/* Process a list of permitted domains. */
	if (!(permitted_urls = loaddomainfile(argv[0], permitdomains,
		                                 permitted_urls)))
	{
		return 1;
	}
	
	/* Process a list of permitted URLs. */
	if (!(permitted_urls = loadurlfile(argv[0], permiturls, permitted_urls)))
	{
		return 1;
	}
	
	/* Process a list of permitted expressions. */
	if (!(permitted_urls = loadexpressionfile(argv[0], permitexpressions,
		                                      permitted_urls)))
		return 1;
	
	/* Process a list of blocked domains. */
	if (!(blocked_urls = loaddomainfile(argv[0], denydomains, blocked_urls)))
		return 1;
	
	/* Process a list of blocked URLs. */
	if (!(blocked_urls = loadurlfile(argv[0], denyurls, blocked_urls)))
		return 1;
	
	/* Process a list of blocked expressions. */
	if (!(blocked_urls = loadexpressionfile(argv[0], denyexpressions,
		                                    blocked_urls)))
		return 1;
	
	if (testurl)
	{
		if (!check_urls(testurl, 1))
		{
			fprintf(stderr, "%s\nDomain blocked.\n", testurl);
			return 0;
		}
		
		if (!check_urls(testurl, 0))
		{
			fprintf(stderr, "%s\nURL/regex blocked.\n", testurl);
			return 0;
		}
		
		fprintf(stderr, "%s\nPermitted.\n", testurl);
		return 0;
	}
	
	td.auth_ip  &= td.netmask;
	td.client_ip = 0;
	
#ifdef WIN32
	int tid;
	WSADATA wsaData;
	
	tdSem = CreateSemaphore(NULL, 0, 1, NULL);
	
	if (WSAStartup(MAKEWORD(2, 0), &wsaData) == SOCKET_ERROR)
		return 3;
#else
	int pid;
	
	/* If inetd mode is enabled, use stdin. */
	if (!proxy_port)
	{
		td.client_fd = 0;
		return (client_thread(&td));
	}
	
	/* Fork into background. */
	if ((pid = fork()) < 0)
	{
		return 2;
	}
	
	if (pid)
		return 0;
	
	/* Create a new session. */
	
	if (setsid() < 0)
		return 3;
	
	/* Close all file descriptors. */
	while (!close(n) && n++ < MAXIMUM_FILE_DESCRIPTORS);
#endif
	
	/* Create a socket. */
	proxy_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
	
	if (proxy_fd < 0)
		return 4;
	
	log_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	
	if (log_fd < 0)
		return 4;
	
	/* Bind the proxy on the local port and listen. */
#ifndef WIN32
	n = 1;
	
	if (setsockopt(proxy_fd, SOL_SOCKET, SO_REUSEADDR, (void *)&n, sizeof(n))
		< 0)
		return 5;
	
	n = TCP_WINDOW_SIZE;
	
	if (setsockopt(proxy_fd, SOL_SOCKET, SO_SNDBUF, (void *)&n, sizeof(n)) < 0)
		return 5;

	if (setsockopt(proxy_fd, SOL_SOCKET, SO_RCVBUF, (void *)&n, sizeof(n)) < 0)
		return 5;
#endif
	/*n = 1;
	if (setsockopt(log_fd, SOL_SOCKET, SO_BROADCAST, (void *)&n, sizeof(n))
		< 0)
		return 5;
	
	td.log_fd = log_fd;*/
	td.auth_ip &= td.netmask;

	memset(&proxy_addr, 0, sizeof(proxy_addr));
	proxy_addr.sin_family      = AF_INET;
	proxy_addr.sin_port        = htons((unsigned short)proxy_port);
	proxy_addr.sin_addr.s_addr = td.server_ip;
	
	if (bind(proxy_fd, (struct sockaddr *)&proxy_addr, sizeof(proxy_addr)) < 0)
		return 6;
	
	if (listen(proxy_fd, _GLOBAL_MAX_CONNECTIONS))
		return 7;
	
	while (1)
	{
		n = sizeof(client_addr);
		
		/* Wait for an inbound connection. */
		
		if ((td.client_fd = accept(proxy_fd, (struct sockaddr *)&client_addr,
			 &n)) < 0)
			return 8;
		
		td.client_ip = client_addr.sin_addr.s_addr;
		
		/* Verify that the client is authorized. */
		
		if ((td.client_ip & td.netmask) != td.auth_ip)
		{
			close(td.client_fd);
			continue;
		}
		
#ifndef WIN32
		/* Fork a child process to handle the connection. */
		if ((pid = fork()) < 0)
		{
			close(td.client_fd);
			continue;
		}
		
		if (pid)
		{
			/* In parent thread: wait for child to finish. */
			close(td.client_fd);
			waitpid(pid, NULL, 0);
			continue;
		}
		
		/* In child: fork and exit so that the parent thread becomes init. */
		if ((pid = fork()) < 0)
			return 9;
		
		if (pid)
			return 0;
		
		return client_thread(&td);
#else
		/* Spawn a thread to handle the connection. */
		CloseHandle(CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)
		            client_thread, &td, 0, &tid));
		
		/* Wait until the thread has read its data. */
		WaitForSingleObject(tdSem, INFINITE);
#endif
	}
	
	/* Not reached. */
	return -1;
}
