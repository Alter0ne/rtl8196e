#ifndef PRODUCT
#define PRODUCT "uHub"
#endif

#ifndef PRODUCT_TITLE
#define PRODUCT_TITLE "(micro-Hub)"
#endif

#ifndef VERSION
#define VERSION "0.2.8"
#endif

#ifndef COPYRIGHT
#define COPYRIGHT "Copyright (c) 2007-2009, Jan Vidar Krey <janvidar@extatic.org>"
#endif
