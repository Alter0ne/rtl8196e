This is a sample of what you can do by using LCD4Linux and the ST2205 library.
Howto: Edit the config and make 'port' reflect the /dev/sdX-device your
unit is connected to. Then, run:
lcd4linux -F -f lcd4linux.conf
