#ifndef CORE_H_
#define CORE_H_

#define ZSTREAM_LOCAL  __attribute__ ((visibility("hidden")))
#define typeof __typeof__

#include "zstream.h"
#include <unistd.h>

#define ZSTREAM_BANNER "zstream/0.3"

#define ZSTREAM_DATA_READABLE		0x0001
#define ZSTREAM_DATA_WRITABLE		0x0002
#define ZSTREAM_IO_CONNECTED		0x0010
#define ZSTREAM_IO_COMMITED		0x0020
#define ZSTREAM_IO_FLUSH		0x0040
#define ZSTREAM_IO_COMPLETED		0x0080
#define ZSTREAM_META_READABLE		0x0100
#define ZSTREAM_META_WRITABLE		0x0200
#define ZSTREAM_META_SENT		0x0400
#define ZSTREAM_META_RECEIVED		0x0800

#define ZSTREAM_BUFFER_SIZE		8192


typedef struct zstream_handler {
	int(*reopen)(zstream_t*, const char*);
	ssize_t(*recvmsg)(zstream_t*, zstream_req_t*);
	ssize_t(*sendmsg)(zstream_t*, zstream_req_t*);
} zstream_handler_t;

struct zstream_protocol {
	struct zstream_protocol *next;
	struct zstream_handler *handler;
	char protocol[16];
};

struct zstream {
	int action;
	int status;
	char *url;
	char *proto;
	char *auth;
	char *host;
	char *port;
	char *path;
	zstream_handler_t *handler;
	void *data;
};

#include <openssl/ssl.h>
ZSTREAM_LOCAL FILE* zstream_tls_fdopen(SSL *ssl);
ZSTREAM_LOCAL SSL* zstream_tls_new(SSL_CTX *ctx);

ZSTREAM_LOCAL void zstream_register(struct zstream_protocol *proto);
ZSTREAM_LOCAL void zstream_url_free(zstream_t *stream);
ZSTREAM_LOCAL void zstream_url_parse(zstream_t *stream, const char *surl);

#define ZSTREAM_HANDLER(name, hndl) \
		static struct zstream_protocol zstream_proto_##name##_ctx = { .handler = &hndl, .protocol = #name }; \
        void  __attribute__ ((constructor)) zstream_hndl_##name##_ct(void) { \
        	zstream_register(&zstream_proto_##name##_ctx); \
        }

#endif /* CORE_H_ */
