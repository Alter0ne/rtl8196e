/**
 *   zstream - Minimalistic network stream library
 *   Copyright (C) 2011 Steven Barth <steven@midlink.org>
 *   Copyright (C) 2011 John Crispin <blogic@openwrt.org>
 *
 *   This library is free software; you can redistribute it and/or modify it
 *   under the terms of the GNU Lesser General Public License as published
 *   by the Free Software Foundation; either version 2.1 of the License,
 *   or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *   See the GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this library; if not, write to the Free Software Foundation,
 *   Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
 *
 */

#include "core.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

static SSL_CTX *dctx = NULL;

static void __attribute__((constructor)) tls_ctor() {
	SSL_library_init();
	dctx = SSL_CTX_new(TLSv1_client_method());
	SSL_CTX_set_verify(dctx, SSL_VERIFY_NONE, NULL);
}

static void __attribute__ ((destructor)) tls_dtor() {
    SSL_CTX_free(dctx);
}

/* TLS stdio read fopencookie() callback */
static ssize_t tls_read(void *cookie, char *buf, size_t size) {
	SSL *ssl = cookie;
	int status = SSL_read(ssl, buf, size);
	if (status < 0) {
		status = SSL_get_error(ssl, status);
		if (status == SSL_ERROR_WANT_READ || status == SSL_ERROR_WANT_WRITE) {
			errno = EAGAIN;
			return -1;
		} else {
			return 0;
		}
	}
	return status;
}

/* TLS stdio write fopencookie() callback */
static ssize_t tls_write(void *cookie, const char *buf, size_t size){
	SSL *ssl = cookie;
	int status = SSL_write(ssl, buf, size);
	if (status < 0) {
		status = SSL_get_error(ssl, status);
		errno = (status == SSL_ERROR_WANT_READ||status == SSL_ERROR_WANT_WRITE)
				? EAGAIN : EPIPE;
		return -1;
	}
	return status;
}

static cookie_io_functions_t io = {
	.read = tls_read,
	.write = tls_write
};

ZSTREAM_LOCAL FILE* zstream_tls_fdopen(SSL *ssl) {
	return fopencookie(ssl, "r+", io);
}

ZSTREAM_LOCAL SSL* zstream_tls_new(SSL_CTX *ctx) {
	return SSL_new((ctx) ? ctx : dctx);
}
