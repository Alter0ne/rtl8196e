/**
 *   zstream - Minimalistic network stream library
 *   Copyright (C) 2011 Steven Barth <steven@midlink.org>
 *   Copyright (C) 2011 John Crispin <blogic@openwrt.org>
 *
 *   This library is free software; you can redistribute it and/or modify it
 *   under the terms of the GNU Lesser General Public License as published
 *   by the Free Software Foundation; either version 2.1 of the License,
 *   or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *   See the GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this library; if not, write to the Free Software Foundation,
 *   Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
 *
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include "core.h"

static struct zstream_protocol *protos = NULL;


zstream_t* zstream_open(const char *url, int action) {
	zstream_t *stream = calloc(1, sizeof(zstream_t));
	if (!stream) return NULL;
	if (!zstream_reopen(stream, url, action))
		return stream;
	zstream_close(stream);
	return NULL;
}

int zstream_reopen(zstream_t *stream, const char *url, int action) {
	zstream_handler_t *handler = NULL;
	struct zstream_protocol *p = protos;
	const char *delim = strstr(url, "://");
	if (delim) {
		size_t plen = delim - url;
		for (; p; p = p->next) {
			if (strlen(p->protocol) == plen &&
			!memcmp(p->protocol, url, plen)) {
				handler = p->handler;
				break;
			}
		}
	}

	if (!handler || !(url))
		return -1;

	// Free resources if we are switching protocols
	if (stream->handler && stream->handler != handler)
		stream->handler->reopen(stream, NULL);

	stream->handler = handler;
	stream->action = action;

	if (stream->handler->reopen(stream, url)) {
		stream->handler->reopen(stream, NULL);
		return -1;
	}

	return 0;
}

ssize_t zstream_read(zstream_t *stream, void *buf, size_t len) {
	zstream_req_t req = {.data = buf, .len = len};
	return stream->handler->recvmsg(stream, &req);
}

ssize_t zstream_write(zstream_t *stream, const void *buf, size_t len) {
	zstream_req_t req = {.data = (void*)buf, .len = len};
	return stream->handler->sendmsg(stream, &req);
}

ssize_t zstream_recvmsg(zstream_t *stream, zstream_req_t *req) {
	return stream->handler->recvmsg(stream, req);
}

ssize_t zstream_sendmsg(zstream_t *stream, zstream_req_t *req) {
	return stream->handler->sendmsg(stream, req);
}

int zstream_close(zstream_t *stream) {
	int stat = 0;
	if (stream->handler)
		stat = stream->handler->reopen(stream, NULL);
	free(stream);
	return stat;
}

// Internal

ZSTREAM_LOCAL void zstream_register(struct zstream_protocol *proto) {
	proto->next = protos;
	protos = proto;
}

ZSTREAM_LOCAL void zstream_url_free(zstream_t *stream) {
	if (stream->url) {
		free(stream->url);
		stream->url = NULL;
	}
	if (stream->proto) {
		free(stream->proto);
		stream->proto = NULL;
	}
	if (stream->auth) {
		free(stream->auth);
		stream->auth = NULL;
	}
	if (stream->host) {
		free(stream->host);
		stream->host = NULL;
	}
	if (stream->port) {
		free(stream->port);
		stream->port = NULL;
	}
	if (stream->path) {
		free(stream->path);
		stream->path = NULL;
	}
}

ZSTREAM_LOCAL void zstream_url_parse(zstream_t *stream, const char *surl) {
	const char *delim = strstr(surl, "://");
	size_t plen = delim - surl;

	stream->proto = strndup(surl, plen);

	const char *url = surl;
	const char *c = url + plen + 3, *d = c;

	if (!(c = strchr(d, '/'))) {
		stream->path = strdup("/");
		c = d + strlen(d);
	} else {
		stream->path = strdup(c);
	}
	const char *p = c;
	stream->url = strdup(url);

	if ((c = strchr(d, '@')) && c < p) {
		plen = c - d;
		stream->auth = strndup(d, plen);
		d = c + 1;
	}

	if (*d == '[') {
		d++;
	}
	if (!(c = strchr(d, ']'))) {
		c = d;
	}

	if ((c = strchr(c, ':')) && c < p) {
		plen = (*(c - 1) != ']') ? c - d : c - d - 1;
		stream->host = strndup(d, plen);

		plen = p - ++c;
		stream->port = strndup(c, plen);
	} else {
		plen = (*(p - 1) != ']') ? p - d : p - d - 1;
		stream->host = strndup(d, plen);
	}
}
