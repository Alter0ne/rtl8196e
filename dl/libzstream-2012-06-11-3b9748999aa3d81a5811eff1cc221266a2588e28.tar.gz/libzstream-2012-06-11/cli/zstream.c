/**
 *   zstream - Minimalistic network stream library
 *   Copyright (C) 2011 Steven Barth <steven@midlink.org>
 *   Copyright (C) 2011 John Crispin <blogic@openwrt.org>
 *
 *   This library is free software; you can redistribute it and/or modify it
 *   under the terms of the GNU Lesser General Public License as published
 *   by the Free Software Foundation; either version 2.1 of the License,
 *   or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *   See the GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this library; if not, write to the Free Software Foundation,
 *   Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
 *
 */

#include <zstream.h>
#include <zstream/http.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


static int usage(const char *app) {
	fprintf(stderr,
		"zstream - Minimalistic network stream library\n"
		"(c) 2011 Steven Barth, John Crispin\n\n"
		"Usage: %s [options] [command] url\n\n"
		"Commands:\n"
		"	get			Open URL for reading (default)\n"
		"	put			Open URL for writing\n"
		"	post			Open URL for application call\n"
		"\n\nOptions:\n"
		"	-A			Aggregate data (for broken HTTP servers)\n"
		"	-c			Continue transfer (get only)\n"
		"	-C <limit>		Enable Cookies and set limit (HTTP)\n"
		"	-h			Show this help message\n"
		" 	-o <offset>		Set source offset\n"
		"	-s <size>		Set source size\n"
		"	-v			Increase verbosity\n"
		//"	-H <key>:<value>	Set header\n"
		"	-I <path>		Read from source (default: stdin)\n"
		"	-O <path>		Save to destination (default: stdout)\n",
		app);
	return 1;
}

int main(int argc, char* const *argv) {
	FILE *fpout = stdout, *fpin = stdin;
	const char *optstr = "AcC:ho:s:vH:I:O:", *in = NULL, *out = NULL;
	int option, cont = 0, verbose = 0, aggregate = 0, cookies = 0;
	uint64_t size = 0, offset = 0;
	size_t reqsize = 0;
	char *header[argc], **hc = header, *reqpayload = NULL, buffer[BUFSIZ];
	struct stat s;

	while ((option = getopt(argc, argv, optstr)) != -1) {
		switch (option) {
			case 'A':
				aggregate = 1;

			case 'c':
				cont = 1;
				break;

			case 'C':
				cookies = atoi(optarg);
				break;

			case 'h':
				return usage(*argv);

			case 'o':
				offset = (uint64_t)atoll(optarg);
				break;

			case 's':
				size = (uint64_t)atoll(optarg);
				break;

			case 'H':
				*hc++ = optarg;
				break;

			case 'I':
				in = optarg;
				break;

			case 'O':
				out = optarg;
				break;

			case 'v':
				verbose++;
				break;
		}
	}
	*hc = NULL;

	if (argc < 2)
		return usage(*argv);

	const char *actstr = argv[optind];
	const char *url = actstr;
	int action = ZSTREAM_GET;

	if (!strcasecmp(actstr, "put")) {
		action = ZSTREAM_PUT;
		url = argv[optind + 1];
	} else if (!strcasecmp(actstr, "post")) {
		action = ZSTREAM_POST;
		url = argv[optind + 1];
	} else if (!strcasecmp(actstr, "get")) {
		action = ZSTREAM_GET;
		url = argv[optind + 1];
	} else if (!strstr(actstr, "://")) {
		return usage(*argv);
	}

	if (in) {
		if (!(fpin = fopen(in, "r"))) {
			goto error;
		}
		if (!size) {
			fstat(fileno(fpin), &s);
			size = S_ISREG(s.st_mode) ? s.st_size : 0;
		}
	}

	if (out) {
		if (!(fpout = fopen(out, (cont) ? "a" : "w"))) {
			goto error;
		}
		if (!offset && cont) {
			fstat(fileno(fpout), &s);
			offset = S_ISREG(s.st_mode) ? s.st_size : 0;
		}
	}

	if (!size && aggregate) {
		size_t len;
		FILE *fpagg = open_memstream(&reqpayload, &reqsize);
		while ((len = fread(buffer, 1, sizeof(buffer), fpin)) > 0) {
			if (!fwrite(buffer, 1, len, fpagg)) {
				goto error;
			}
		}
		if (fclose(fpagg)) {
			goto error;
		}
		size = (uint64_t)reqsize;
	}

	zstream_t *stream = zstream_open(url, action);
	if (!stream)
		goto error;

	if (cookies)
		zstream_http_configure(stream, ZSTREAM_HTTP_COOKIES, cookies);

	struct zstream_req req = {
		.offset = offset,
		.size = size,
	};

	if (action == ZSTREAM_POST || action == ZSTREAM_PUT) {
		if (reqpayload) {
			req.data = reqpayload;
			req.len = reqsize;
			if (zstream_sendmsg(stream, &req) != reqsize) {
				goto error;
			}
		} else {
			size_t remain = (size < sizeof(buffer)) ? size : sizeof(buffer);
			while ((reqsize = fread(buffer, 1, remain, fpin))) {
				req.data = buffer;
				req.len = reqsize;
				if (!reqsize
				|| (zstream_sendmsg(stream, &req) != reqsize)) {
					goto error;
				}
				size -= reqsize;
				remain = (size < sizeof(buffer)) ? size : sizeof(buffer);
			}
		}
	}

	ssize_t rxed;
	while ((rxed = zstream_read(stream, buffer, sizeof(buffer))) > 0)
		fwrite(buffer, 1, rxed, fpout);

	zstream_close(stream);
	fclose(fpout);
	fclose(fpin);

	if (rxed < 0)
		goto error;

	return 0;

error:
	perror("zstream");
	return 128 - errno;
}
