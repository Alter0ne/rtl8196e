#define _XOPEN_SOURCE
#define _SVID_SOURCE
#include "../core.h"
#include "../ustream-encoding.h"
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

static int ftp_open(ustream_t *stream);
static int ftp_close(ustream_t *stream);
static ssize_t ftp_read(ustream_t *stream, void *buf, size_t len);
static ssize_t ftp_write(ustream_t *stream, const void *buf, size_t len);
static int ftp_ctl(ustream_t *stream, int cmd, void *value);


static ustream_handler_t handler_ftp = {
		.open = ftp_open,
		.close = ftp_close,
		.read = ftp_read,
		.write = ftp_write,
		.ctl = ftp_ctl,
		.protocol = "ftp"
};

static ustream_handler_t handler_ftps = {
		.open = ftp_open,
		.close = ftp_close,
		.read = ftp_read,
		.write = ftp_write,
		.ctl = ftp_ctl,
		.protocol = "ftps"
};

typedef struct ustream_ftp {
	int status;
	int ctlstat;
	int ctlsocket;
	int datasocket;
	int dataport;
	FILE *ctltransport;
	FILE *datatransport;
	uint64_t offset;
	uint64_t size;
	uint64_t remaining;
	time_t mtime;
	SSL *ctlssl;
	SSL *datassl;
} ustream_ftp_t;


static time_t ftp_timestamp(char *buffer) {
    struct tm t;
    return (strptime(buffer, "%Y%m%d%H%M%S", &t)) ? timegm(&t) : 0;
}


static int ftp_open(ustream_t *stream) {
	if (!stream->host) {
		return -(errno = EINVAL);
	}
	if (!stream->port) {
		stream->port = strdup("21");
	}

	if (!(stream->data = calloc(1, sizeof(ustream_ftp_t)))) {
		return -(errno = ENOMEM);
	}
	ustream_ftp_t *ftp = stream->data;
	ftp->ctlsocket = -1;

	if (strpbrk(stream->path, "\r\n")) {
		return -(errno = EINVAL);
	}

	if (!stream->auth) {
		stream->auth = strdup("anonymous:luci2%40example.com");
	}

	stream->status = USTREAM_META_WRITABLE;
	switch (stream->action & 0xff) {
		case USTREAM_PUT:
			stream->status |= USTREAM_DATA_WRITABLE;
			break;

		case USTREAM_GET:
			stream->status |= USTREAM_DATA_READABLE;
			break;

		default:
			return -(errno = ENOTSUP);
	}

	if (stream->handler == &handler_ftps
	&& (!(ftp->ctlssl = ustream_tls_new(stream->ctx))
	|| !(ftp->datassl = ustream_tls_new(stream->ctx)))) {
		return -errno;
	}

	ftp->ctlsocket = ftp->datasocket = -1;

	return 0;
}

static char* ftp_fgets(char *s, int size, FILE *stream) {
	do {
		if (!fgets(s, size, stream)) {
			return 0;
		}
	} while (s[0] == ' ' || s[3] == '-');
	return s;
}

static int ftp_connect(ustream_t *stream) {
	ustream_ftp_t *ftp = stream->data;

	if (ftp->ctlsocket == -1
	&& (ftp->ctlsocket = ustream_socket(stream->ctx, stream->host, stream->port)) == -1) {
		goto error;
	}

	if (!ftp->ctltransport) {
		int fd = dup(ftp->ctlsocket);
		fcntl(fd, F_SETFD, fcntl(fd, F_GETFD) | FD_CLOEXEC);
		if (!(ftp->ctltransport = fdopen(fd, "r+"))) {
			close(fd);
			close(ftp->ctlsocket);
			goto error;
		}
		setvbuf(ftp->ctltransport, NULL, _IOLBF, 0);
	}

	stream->status &= ~USTREAM_META_WRITABLE;
	char buf[256] = {0}, *c = NULL;
	struct sockaddr_storage sa;
	socklen_t salen = sizeof(sa);

	switch (ftp->ctlstat) {
		case 0:
			if (stream->handler == &handler_ftps) {
				if (fputs("AUTH TLS\r\n", ftp->ctltransport) == EOF) {
					goto error;
				}
			}
			ftp->ctlstat++;

		case 1:
			if (stream->handler == &handler_ftps) {
				if (!fgets(buf, sizeof(buf), ftp->ctltransport)) {
					goto error;
				}
				if (memcmp(buf, "234 ", 4)) {
					errno = EPROTO;
					goto error;
				}
				fclose(ftp->ctltransport);
				SSL_set_fd(ftp->ctlssl, ftp->ctlsocket);
			}
			ftp->ctlstat++;

		case 2:
			if (stream->handler == &handler_ftps) {
				int stat;
				if ((stat = SSL_connect(ftp->ctlssl)) <= 0) {
					stat = SSL_get_error(ftp->ctlssl, stat);
					errno = (stat == SSL_ERROR_WANT_READ
							|| stat == SSL_ERROR_WANT_WRITE) ? EAGAIN : EPIPE;
					goto error;
				}
				if (!(ftp->ctltransport = ustream_tls_fdopen(ftp->ctlssl))) {
					goto error;
				}
			}
			ftp->ctlstat++;

		case 3:
			if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
				goto error;
			}
			ftp->ctlstat++;

		case 4:
			strncpy(buf, stream->auth, sizeof(buf) - 1);
			if ((c = strchr(buf, ':'))) {
				*c = 0;
			}
			if (fprintf(ftp->ctltransport, "USER %s\r\n", buf) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 5:
			if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
				goto error;
			}
			if (memcmp(buf, "331 ", 4)) {
				errno = EACCES;
				goto error;
			}
			ftp->ctlstat++;

		case 6:
			strncpy(buf, stream->auth, sizeof(buf) - 1);
			if (!(c = strchr(buf, ':'))) {
				c = "\0";
			}
			if (fprintf(ftp->ctltransport, "PASS %s\r\n", ++c) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 7:
			if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
				goto error;
			}
			if (memcmp(buf, "230 ", 4)) {
				errno = EACCES;
				goto error;
			}
			ftp->ctlstat++;

		case 8:
			if (stream->handler == &handler_ftps
			&& fputs("PBSZ 0\r\n", ftp->ctltransport) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 9:
			if (stream->handler == &handler_ftps) {
				if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
					goto error;
				}
				if (memcmp(buf, "200 ", 4)) {
					errno = EACCES;
					goto error;
				}
			}
			ftp->ctlstat++;

		case 10:
			if (stream->handler == &handler_ftps
			&& fputs("PROT P\r\n", ftp->ctltransport) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 11:
			if (stream->handler == &handler_ftps) {
				if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
					goto error;
				}
				if (memcmp(buf, "200 ", 4)) {
					errno = EACCES;
					goto error;
				}
			}
			ftp->ctlstat++;

		case 12:
			if (fputs("TYPE I\r\n", ftp->ctltransport) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 13:
			if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
				goto error;
			}
			if (memcmp(buf, "200 ", 4)) {
				errno = EACCES;
				goto error;
			}
			ftp->ctlstat++;

		case 14:
			if (fputs("EPSV\r\n", ftp->ctltransport) < 0) {
					goto error;
			}
			ftp->ctlstat++;

		case 15:
			if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
				goto error;
			}
			int port;
			if (!(c = strstr(buf, "|||")) || !(port = atoi(c + 3))) {
				errno = EPROTO;
				goto error;
			}
			ftp->dataport = port;
			ftp->ctlstat++;

		case 16:
			if ((stream->action & 0xff) == USTREAM_GET
			&& fprintf(ftp->ctltransport, "SIZE %s\r\n", stream->path) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 17:
			if ((stream->action & 0xff) == USTREAM_GET) {
				if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
					goto error;
				}
				if (memcmp(buf, "213 ", 4)) {
					errno = ENOENT;
					goto error;
				}
				ftp->remaining = (ftp->size = atoll(buf + 4)) - ftp->offset;
			}
			ftp->ctlstat++;

		case 18:
			if ((stream->action & 0xff) == USTREAM_GET
			&& fprintf(ftp->ctltransport, "MDTM %s\r\n", stream->path) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 19:
			if ((stream->action & 0xff) == USTREAM_GET) {
				if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
					goto error;
				}
				if (memcmp(buf, "213 ", 4)) {
					errno = ENOENT;
					goto error;
				}
				ftp->mtime = ftp_timestamp(buf + 4);
			}
			ftp->ctlstat++;

		case 20:
			if (ftp->offset && fprintf(ftp->ctltransport, "REST %llu\r\n",
					(unsigned long long)ftp->offset) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 21:
			if (ftp->offset) {
				if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
					goto error;
				}
				if (memcmp(buf, "350 ", 4)) {
					errno = ENOTSUP;
					goto error;
				}
			}
			ftp->ctlstat++;

		case 22:
			getpeername(ftp->ctlsocket, (struct sockaddr*)&sa, &salen);
			if (sa.ss_family == AF_INET) {
				((struct sockaddr_in*)&sa)->sin_port = htons(ftp->dataport);
			} else if (sa.ss_family == AF_INET6) {
				((struct sockaddr_in6*)&sa)->sin6_port = htons(ftp->dataport);
			}
			if (ftp->datasocket == -1) {
				if ((ftp->datasocket = socket(sa.ss_family, SOCK_STREAM, 0)) == -1) {
					goto error;
				}
				fcntl(ftp->datasocket, F_SETFD, fcntl(ftp->ctlsocket, F_GETFD));
				fcntl(ftp->datasocket, F_SETFL, fcntl(ftp->ctlsocket, F_GETFL));

				struct timeval t;
				socklen_t tl = sizeof(t);
				getsockopt(ftp->ctlsocket, SOL_SOCKET, SO_SNDTIMEO, &t, &tl);
				setsockopt(ftp->datasocket, SOL_SOCKET, SO_SNDTIMEO, &t, tl);
				setsockopt(ftp->datasocket, SOL_SOCKET, SO_RCVTIMEO, &t, tl);
			}
			if (connect(ftp->datasocket, (struct sockaddr*)&sa, salen)) {
				goto error;
			}
			ftp->ctlstat++;

		case 23:
			switch (stream->action & 0xff) {
				case USTREAM_GET:
					c = "RETR";
					break;

				case USTREAM_PUT:
					c = "STOR";
					break;
			}
			if (fprintf(ftp->ctltransport, "%s %s\r\n", c, stream->path) < 0) {
				goto error;
			}
			ftp->ctlstat++;

		case 24:
			if (!ftp_fgets(buf, sizeof(buf), ftp->ctltransport)) {
				goto error;
			}
			if (memcmp(buf, "150 ", 4)) {
				errno = ENOENT;
				goto error;
			}
			ftp->ctlstat++;

		case 25:
			if (stream->handler == &handler_ftps) {
				SSL_set_fd(ftp->datassl, ftp->datasocket);
				int stat;
				if ((stat = SSL_connect(ftp->datassl)) <= 0) {
					stat = SSL_get_error(ftp->datassl, stat);
					errno = (stat == SSL_ERROR_WANT_READ
							|| stat == SSL_ERROR_WANT_WRITE) ? EAGAIN : EPIPE;
					goto error;
				}
				if (!(ftp->datatransport = ustream_tls_fdopen(ftp->datassl))) {
					goto error;
				}
			} else {
				int fd = dup(ftp->datasocket);
				fcntl(fd, F_SETFD, fcntl(fd, F_GETFD) | FD_CLOEXEC);
				if (!(ftp->datatransport = fdopen(fd, "r+"))) {
					close(fd);
					goto error;
				}
			}
			ftp->ctlstat++;
	}

	stream->status |= USTREAM_IO_CONNECTED;
	return 0;

error:
	if (errno != EAGAIN) {
		ftp->status = -errno;
		stream->status |= USTREAM_IO_COMPLETED;
	}
	return -errno;
}


static int ftp_commit(ustream_t *stream) {
	if (!(stream->status & USTREAM_IO_CONNECTED)) {
		int s = ftp_connect(stream);
		if (s) {
			return s;
		}
	}
	stream->status |= USTREAM_IO_COMMITED;
	return 0;
}


static int ftp_ctl(ustream_t *stream, int cmd, void *value) {
	ustream_ftp_t *ftp = stream->data;
	switch (cmd) {
		case USTREAM_CTL_CONNECT:
			return (stream->status & USTREAM_IO_CONNECTED)
				? -(errno = EALREADY) : ftp_connect(stream);

		case USTREAM_CTL_COMMIT:
			if (stream->status & USTREAM_IO_COMMITED) {
				return -(errno = EALREADY);
			}
			int ret = ftp_commit(stream);
			if (ret) {
				return ret;
			}

		case USTREAM_GET_STATUS:
			if (!(stream->status & USTREAM_IO_COMMITED)) {
				return -(errno = ENOTSUP);
			}
			ustream_stat_t *stat = value;
			if (stat) {
				stat->status = ftp->status;
				stat->url = stream->url;
				stat->size = ftp->size;
				stat->mtime = ftp->mtime;
			}
			return 0;

		case USTREAM_SET_OFFSET:
			if (stream->status & USTREAM_META_WRITABLE) {
				uint64_t *off = value;
				ftp->offset = *off;
				return 0;
			}
			return -(errno = EALREADY);
	}

	return -(errno = ENOTSUP);
}

static ssize_t ftp_read(ustream_t *stream, void *buf, size_t len) {
	ustream_ftp_t *ftp = stream->data;
	if (stream->status & USTREAM_IO_COMPLETED) {
		return 0;
	} else if (!(stream->status & USTREAM_IO_COMMITED)) {
		int s = ftp_commit(stream);
		if (s) {
			return s;
		}
	} else if (!(stream->status & USTREAM_DATA_READABLE)) {
		return -(errno = ENOTSUP);
	}
	size_t rxed = 0;

	if (ftp->remaining && len > ftp->remaining) {
		len = ftp->remaining;
	}

	while (len) {
		ssize_t recvc = len;
		if ((recvc = fread(buf, 1, recvc, ftp->datatransport))) {
			rxed += recvc;
			len -= recvc;
			buf = (char*)buf + recvc;
		} else {
			break;
		}
	}

	if (rxed && ftp->remaining) {
		if ((ftp->remaining -= rxed) == 0) {
			stream->status |= USTREAM_IO_COMPLETED;
		}
	} else if (len && !rxed && errno != EAGAIN) {
		stream->status |= USTREAM_IO_COMPLETED;
	}
	return (rxed || !len || feof(ftp->datatransport))
			? rxed : (ftp->status = -errno);
}

static ssize_t ftp_write(ustream_t *stream, const void *buf, size_t len) {
	ustream_ftp_t *ftp = stream->data;
	if ((stream->status & (USTREAM_IO_COMPLETED | USTREAM_IO_COMMITED))
	|| !(stream->status & USTREAM_DATA_WRITABLE)) {
		return -(errno = EPIPE);
	} else if (!(stream->status & USTREAM_IO_CONNECTED)) {
		int s = ftp_commit(stream);
		if (s) {
			return s;
		}
	}

	size_t txed = 0;
	while (len) {
		ssize_t sendc = len;
		if ((sendc = fwrite(buf, 1, sendc, ftp->datatransport))) {
			txed += sendc;
			len -= sendc;
			buf = (char*)buf + sendc;
		} else {
			break;
		}
	}

	if (len && !txed && errno != EAGAIN) {
		stream->status |= USTREAM_IO_COMPLETED;
	}
	return (txed || !len) ? txed : (ftp->status = -errno);
}

static int ftp_close(ustream_t *stream) {
	ustream_ftp_t *ftp = stream->data;
	int stat = 0;
	if (stream->status & USTREAM_IO_COMPLETED) {
		stat = (ftp->status > 0)
				? -!(ftp->status >= 200 && ftp->status <= 299) : ftp->status;
	} else if (!(stream->status & USTREAM_IO_COMMITED)) {
		stat = ftp_commit(stream);
	}

	if (ftp->datatransport) {
		if (!stat && fflush(ftp->datatransport)) {
			stat = -errno;
		}
		fclose(ftp->datatransport);
	}

	if (ftp->ctltransport) {
		if (!stat && fflush(ftp->ctltransport)) {
			stat = -errno;
		}
		fclose(ftp->ctltransport);
	}

	if (ftp->datassl) {
		SSL_shutdown(ftp->datassl);
		SSL_free(ftp->datassl);
	}
	close(ftp->datasocket);

	if (ftp->ctlssl) {
		SSL_shutdown(ftp->ctlssl);
		SSL_free(ftp->ctlssl);
	}
	close(ftp->ctlsocket);

	free(ftp);

	free(stream->url);
	free(stream->auth);
	free(stream->path);
	free(stream->port);
	free(stream->host);
	free(stream);
	return stat;
}

USTREAM_HANDLER(ftp, handler_ftp)
USTREAM_HANDLER(ftps, handler_ftps)
