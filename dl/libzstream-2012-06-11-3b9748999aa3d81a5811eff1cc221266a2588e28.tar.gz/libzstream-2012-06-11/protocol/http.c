/**
 *   zstream - Minimalistic network stream library
 *   Copyright (C) 2011 Steven Barth <steven@midlink.org>
 *   Copyright (C) 2011 John Crispin <blogic@openwrt.org>
 *
 *   This library is free software; you can redistribute it and/or modify it
 *   under the terms of the GNU Lesser General Public License as published
 *   by the Free Software Foundation; either version 2.1 of the License,
 *   or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *   See the GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this library; if not, write to the Free Software Foundation,
 *   Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include "libubox/usock.h"
#include "../core.h"
#include "libubox/list.h"
#include "../zstream/http.h"

#define HTTP_WRITE_CHUNKED		0x010000
#define HTTP_READ_CHUNKED		0x020000
#define HTTP_RANGE			0x040000


static int http_reopen(zstream_t *stream, const char *url);
static ssize_t http_recvmsg(zstream_t *stream, zstream_req_t *req);
static ssize_t http_sendmsg(zstream_t *stream, zstream_req_t *req);
static int http_commit(zstream_t *stream);

#define HDR_AUTHORIZATION		0x0001
#define HDR_CONTENT_TYPE		0x0002
#define HDR_CONTENT_LENGTH		0x0004
#define HDR_EXPECT			0x0008
#define HDR_HOST			0x0010
#define HDR_USER_AGENT			0x0020
#define HDR_RANGE			0x0040
#define HDR_TRANSFER_ENCODING		0x0080


static zstream_handler_t handler_http = {
	.reopen = http_reopen,
	.recvmsg = http_recvmsg,
	.sendmsg = http_sendmsg,
};

struct http_header {
	struct list_head _head;
	char key[32];
	char val[];
};

struct http_cookie {
	struct list_head _head;
	char *name;
	char *value;
	char *domain;
	char *path;
	time_t expires;
	int secure;
};

typedef struct zstream_http {
// persistent
	int cfg_linkdepth;
	int cfg_timeout;
	int cfg_maxcookies;
	SSL_CTX *cfg_ssl_ctx;
	struct list_head header_in;
	struct list_head cookies;
	int cookiecnt;

// per-request
	int status;
	int socket;
	int headers;
	int linkdepth;
	FILE *transport;
	uint64_t offset;
	uint64_t size;
	uint64_t remaining;
	uint64_t chunkremain;
	time_t mtime;
	const char *type;
	struct list_head header_out;
	SSL *ssl;
} zstream_http_t;


static void http_freecookie(struct http_cookie *cookie) {
	free(cookie->domain);
	free(cookie->name);
	free(cookie->path);
	free(cookie->value);
	free(cookie);
}

static int http_addcookie
(zstream_t *stream, const char *cstr, const char *dom, const char *path) {
	if (!cstr[0])
		return -(errno = EINVAL);

	zstream_http_t *http = stream->data;
	struct http_cookie *cookie = calloc(1, sizeof(*cookie));
	if (!cookie)
		return -errno;

	size_t len = strcspn(cstr, "=;");
	cookie->name = strndup(cstr, len);
	cstr += len;

	if (*cstr == '=') {
		len = strcspn(++cstr, ";");
		cookie->value = strndup(cstr, len);
		cstr += len;
	}

	while (*(cstr += strspn(cstr, "; "))) {
		len = strcspn(cstr, "=;") + 1;
		const char *val = cstr + len;
		size_t vlen = strcspn(val, ";");
		if (!strncasecmp("expires=", cstr, len)) {
			char date[32] = {0};
			strncpy(date, val, sizeof(date) - 1);
			struct tm t;
			cookie->expires = (strptime(date, "%a, %d %h %Y %T GMT", &t))
				? timegm(&t) : 0;
		} else if (!strncasecmp("domain=", cstr, len)) {
			if (!dom || (val[0] == '.' && !strncasecmp(&val[1], dom, vlen-1)))
				cookie->domain = strndup(val, vlen);
		} else if (!strncasecmp("path=", cstr, len)) {
			if (!path || !strncmp(path, val, strlen(val)))
				cookie->path = strndup(val, vlen);
		} else if (!strncasecmp("secure;", cstr, len)) {
			cookie->secure = 1;
		}
		cstr = val + vlen;
	}

	if (!cookie->domain)
		cookie->domain = strdup(stream->host);

	if (!cookie->path) {
		char *last = strrchr(stream->path, '/');
		cookie->path = (!last) ? strdup("/") :
			strndup(stream->path, last - stream->path + 1);
	}

	if (!cookie->domain || !cookie->path || !cookie->name) {
		http_freecookie(cookie);
		return -(errno = ENOMEM);
	}

	struct http_cookie *now;
	list_for_each_entry(now, &http->cookies, _head) {
		if (!strcmp(now->domain, cookie->domain)
		&& !strcmp(now->name, cookie->name)
		&& !strcmp(now->path, cookie->path)) {
			list_del(&now->_head);
			http->cookiecnt--;
			http_freecookie(now);
			break;
		}
	}

	if ((!cookie->expires || cookie->expires > time(NULL))
	&& http->cookiecnt < http->cfg_maxcookies) {
		list_add(&cookie->_head, &http->cookies);
		http->cookiecnt++;
	} else {
		http_freecookie(cookie);
	}
	return 0;
}


int zstream_http_addcookie(zstream_t *stream, const char *cookie) {
	zstream_http_t *http = stream->data;
	if (!http || (stream->handler != &handler_http))
		return -(errno = EINVAL);

	return http_addcookie(stream, cookie, NULL, NULL);
}

int zstream_http_getcookies(zstream_t *stream, char **vals, size_t len) {
	zstream_http_t *http = stream->data;
	if (!http || (stream->handler != &handler_http))
		return -(errno = EINVAL);

	int i = 0;
	struct http_cookie *c;
	list_for_each_entry(c, &http->cookies, _head) {
		if (i >= len)
			break;

		char dbuf[64];
		struct tm t;
		gmtime_r(&c->expires, &t);
		strftime(dbuf, sizeof(dbuf), "; expires=%a, %d %h %Y %T GMT", &t);

		if (asprintf(&vals[i++], "%s=%s; domain=%s; path=%s%s%s",
		c->name, (c->value) ? c->value : "", c->domain, c->path,
		(c->secure) ? "; secure" : "", (c->expires) ? dbuf : "") < 0) {
			i--;
			break;
		}
	}
	return i;
}

int zstream_http_addheader(zstream_t *stream, const char *key, const char *val) {
	zstream_http_t *http = stream->data;
	if (!http || (stream->handler != &handler_http))
		return -(errno = EINVAL);

	struct http_header *hdr = malloc(sizeof(*hdr) + strlen(val) + 1);
	if (!hdr)
		return -errno;

	hdr->key[sizeof(hdr->key) - 1] = 0;
	strncpy(hdr->key, key, sizeof(hdr->key) - 1);
	strcpy(hdr->val, val);
	list_add(&hdr->_head, &http->header_in);

	if (!strcasecmp(hdr->key, "authorization")) {
		http->headers |= HDR_AUTHORIZATION;
	} else if (!strcasecmp(hdr->key, "content-type")) {
		http->headers |= HDR_CONTENT_TYPE;
	} else if (!strcasecmp(hdr->key, "content-length")) {
		http->headers |= HDR_CONTENT_LENGTH;
	} else if (!strcasecmp(hdr->key, "expect")) {
		http->headers |= HDR_EXPECT;
	} else if (!strcasecmp(hdr->key, "host")) {
		http->headers |= HDR_HOST;
	} else if (!strcasecmp(hdr->key, "user-agent")) {
		http->headers |= HDR_USER_AGENT;
	} else if (!strcasecmp(hdr->key, "range")) {
		http->headers |= HDR_RANGE;
	} else if (!strcasecmp(hdr->key, "transfer-encoding")) {
		http->headers |= HDR_TRANSFER_ENCODING;
	}

	return 0;
}

int zstream_http_getheader(zstream_t *stream, const char *key, char** vals, size_t len) {
	zstream_http_t *http = stream->data;
	if (!http || (stream->handler != &handler_http))
		return -(errno = EINVAL);

	int i = 0;
	struct http_header *hdr;
	list_for_each_entry(hdr, &http->header_out, _head) {
		if (i >= len)
			break;

		if (!strcasecmp(hdr->key, key))
			if (!(vals[i++] = strdup(hdr->val))) {
				i--;
				break;
			}
	}
	return i;
}

int zstream_http_set_ssl(zstream_t *stream, SSL_CTX *ctx) {
	zstream_http_t *http = stream->data;
	if (!http || (stream->handler != &handler_http))
		return -(errno = EINVAL);
	http->cfg_ssl_ctx = ctx;
	return 0;
}

int zstream_http_configure(zstream_t *stream, enum zstream_http_conf key, unsigned value) {
	zstream_http_t *http = stream->data;
	if (!http || (stream->handler != &handler_http))
		return -(errno = EINVAL);
	switch (key) {
	case ZSTREAM_HTTP_TIMEOUT:
		http->cfg_timeout = value;
		break;

	case ZSTREAM_HTTP_LINKDEPTH:
		http->cfg_linkdepth = http->linkdepth = value;
		break;

	case ZSTREAM_HTTP_COOKIES:
		http->cfg_maxcookies = value;
		break;

	default:
		return -1;
	}

	return 0;
}

static int http_reopen(zstream_t *stream, const char *url) {
	int stat = 0;
	zstream_http_t *http = stream->data;

	// This stream was already open, so free all per-request resources
	if (http) {
		if (stream->status & ZSTREAM_IO_COMPLETED) {
			stat = (http->status > 0)
				? -!(http->status >= 200 && http->status <= 299) : http->status;
		} else if (!(stream->status & ZSTREAM_IO_COMMITED)) {
			stat = http_commit(stream);
		}

		while (!list_empty(&http->header_out)) {
			struct http_header *hdr =
				list_first_entry(&http->header_out, struct http_header, _head);
			list_del(&hdr->_head);
			free(hdr);
		}

		if (http->transport) {
			if (!stat && fflush(http->transport))
				stat = -errno;
			fclose(http->transport);
		}

		if (http->ssl) {
			SSL_shutdown(http->ssl);
			SSL_free(http->ssl);
			close(http->socket);
		}

		if (!url)
			goto out;
	}

	zstream_url_free(stream);
	zstream_url_parse(stream, url);

	if (!stream->port)
		stream->port = strdup(!strcmp(stream->proto, "https") ? "443" : "80");

	// Initialize persistent resources as this is the first init of this stream
	if (!http && (stream->data = calloc(1, sizeof(zstream_http_t)))) {
		http = stream->data;
		http->cfg_linkdepth = 5;
		INIT_LIST_HEAD(&http->header_in);
		INIT_LIST_HEAD(&http->cookies);
	}

	// malloc() failed or invalid url
	if (!http || !stream->port || !stream->host) {
		stat = -(errno = ENOMEM);
		goto out;
	}

	// Initialize per-request resources
	http->socket = -1;
	http->chunkremain = http->remaining = http->size = http->headers = \
		http->status = 0;
	http->linkdepth = http->cfg_linkdepth;
	INIT_LIST_HEAD(&http->header_out);

	stream->status = ZSTREAM_META_WRITABLE;
	switch (stream->action & 0xff) {
		case ZSTREAM_POST:
		case ZSTREAM_PUT:
			stream->status |= (ZSTREAM_DATA_WRITABLE | ZSTREAM_DATA_READABLE);
			break;

		case ZSTREAM_GET:
			stream->status |= ZSTREAM_DATA_READABLE;
			break;

		default:
			stat = -(errno = ENOTSUP);
			goto out;
	}

	return 0;

out:
	// Finally free the persistent resources and the context
	if (!url && http) {
		while (!list_empty(&http->header_in)) {
			struct http_header *hdr =
				list_first_entry(&http->header_in, struct http_header, _head);
			list_del(&hdr->_head);
			free(hdr);
		}

		while (!list_empty(&http->cookies)) {
			struct http_cookie *hdr =
				list_first_entry(&http->cookies, struct http_cookie, _head);
			list_del(&hdr->_head);
			http_freecookie(hdr);
		}

		free(http);
		stream->data = NULL;
	}

	zstream_url_free(stream);
	return stat;
}

static void http_normalize(char *line) {
	char *sep = strchr(line, ':');
	if (sep) {
		int d = 1;
		for (char *c = line; c < sep; c++) {
			*c = (d) ? toupper(*c) : tolower(*c);
			d = !isalnum(*c);
		}
	}
	for (char *e = line + strlen(line) - 1; e >= line && isspace(*e); *e-- = 0);
}

static int http_connect(zstream_t *stream) {
	zstream_http_t *http = stream->data;
	if (stream->status & ZSTREAM_IO_FLUSH)
		goto flush;

	int usockfl = USOCK_TCP
			| ((stream->action & ZSTREAM_NONBLOCK) ? USOCK_NONBLOCK : 0);
	if ((http->socket = usock(usockfl, stream->host, stream->port)) == -1)
		goto error;

	if (!strcmp(stream->proto, "https")) {
		if (!http->ssl && !(http->ssl = zstream_tls_new(http->cfg_ssl_ctx)))
			goto error;
		SSL_set_fd(http->ssl, http->socket);
		int stat;
		if ((stat = SSL_connect(http->ssl)) <= 0) {
			stat = SSL_get_error(http->ssl, stat);
			errno = (stat == SSL_ERROR_WANT_READ||stat == SSL_ERROR_WANT_WRITE)
				? EAGAIN : EPIPE;
			goto error;
		}
		if (!(http->transport = zstream_tls_fdopen(http->ssl))) {
			goto error;
		}
	} else {
		if (!(http->transport = fdopen(http->socket, "r+"))) {
			close(http->socket);
			goto error;
		}
	}

	setvbuf(http->transport, NULL, _IOFBF, ZSTREAM_BUFFER_SIZE);
	char *method = NULL;
	int need_chunked = 0;
	int action = stream->action & 0xff;

	switch (action) {
		case ZSTREAM_PUT:
			method = "PUT";
			need_chunked = 1;
			break;

		case ZSTREAM_POST:
			method = "POST";
			need_chunked = 1;
			break;

		case ZSTREAM_GET:
			method = "GET";
			break;
	}

	fprintf(http->transport, "%s %s HTTP/1.1\r\n", method, stream->path);

	if (stream->auth && !(http->headers & HDR_AUTHORIZATION)) {
		char *auth = zstream_urldecode(stream->auth, 0);
		if (auth) {
			char *bd;
			size_t authlen = strlen(auth);
			if ((bd = zstream_b64encode(auth, &authlen))) {
				fputs("Authorization: Basic ", http->transport);
				fputs(bd, http->transport);
				fputs("\r\n", http->transport);
				free(bd);
			}
			free(auth);
		}
	}

	if (stream->status & ZSTREAM_DATA_WRITABLE) {
		if (action == ZSTREAM_POST && !http->type)
			http->type = "application/x-www-form-urlencoded";

		if (http->type && !(http->headers & HDR_CONTENT_TYPE))
			fprintf(http->transport, "Content-Type: %s\r\n", http->type);

		if (!(http->headers & HDR_EXPECT))
			fputs("Expect: 100-continue\r\n", http->transport);
	}

	if (!(http->headers & HDR_HOST)) {
		fputs("Host: ", http->transport);
		fputs(stream->host, http->transport);
		fputc(':', http->transport);
		fputs(stream->port, http->transport);
		fputs("\r\n", http->transport);
	}

	if (!(http->headers & HDR_USER_AGENT)) {
		fputs("User-Agent: " ZSTREAM_BANNER "\r\n", http->transport);
	}
	fputs("Connection: close\r\n", http->transport);

	if (http->offset && !(http->headers & HDR_RANGE)) {
		fprintf(http->transport, "Range: bytes=%llu-\r\n",
			(unsigned long long)http->offset);
		stream->status |= HTTP_RANGE;
	}

	if (need_chunked && !(http->headers & HDR_TRANSFER_ENCODING)){
		if (http->size > 0 && !(http->headers & HDR_CONTENT_LENGTH)) {
			fprintf(http->transport, "Content-Length: %llu\r\n",
					(unsigned long long)http->size);
		} else if (!(http->headers & HDR_CONTENT_LENGTH)) {
			fputs("Transfer-Encoding: chunked\r\n", http->transport);
			stream->status |= HTTP_WRITE_CHUNKED;
		}
	}

	struct http_header *hdr;
	list_for_each_entry(hdr, &http->header_in, _head) {
		fputs(hdr->key, http->transport);
		fputs(": ", http->transport);
		fputs(hdr->val, http->transport);
		fputs("\r\n", http->transport);

		if (!strcasecmp(hdr->key, "content-length"))
			http->size = atoll(hdr->val);
	}

	int cookies = 0;
	struct http_cookie *cookie;
	char *firstdom = strchr(stream->host, '.');
	if (!firstdom)
		firstdom = stream->host;
	list_for_each_entry(cookie, &http->cookies, _head) {
		if ((!strcmp(stream->host, cookie->domain)
		|| !strcmp(firstdom, cookie->domain))
		&& !strncmp(stream->path, cookie->path, strlen(cookie->path))) {
			fprintf(http->transport, "%s%s=%s", (cookies) ? "; " : "Cookie: ",
				cookie->name, (cookie->value) ? cookie->value : "");
			cookies++;
		}
	}
	if (cookies)
		fputs("\r\n", http->transport);

	if (http->size > 0)
		http->remaining = http->size;

	fputs("\r\n", http->transport);
	stream->status |= ZSTREAM_IO_FLUSH;
	stream->status &= ~ZSTREAM_META_WRITABLE;

flush:
	if (!fflush(http->transport)) {
		stream->status |= ZSTREAM_IO_CONNECTED;
		stream->status &= ~ZSTREAM_IO_FLUSH;
		http->size = 0;
		return 0;
	}

error:
	if (errno != EAGAIN) {
		http->status = -errno;
		stream->status |= ZSTREAM_IO_COMPLETED;
	}
	return -errno;
}

static int http_error_code(int http_status) {
	int c;
	switch (http_status) {
		case 304:
			c = 0;
			break;

		case 400:
			c = EINVAL;
			break;

		case 401:
		case 403:
			c = EACCES;
			break;

		case 404:
			c = ENOENT;
			break;


		default:
			if (http_status < 0) {
				c = http_status;
			} else if (http_status >= 200 && http_status <= 299) {
				c = 0;
			} else if (http_status >= 300 && http_status <= 399) {
				c = EXDEV;
			} else {
				c = EPROTO;
			}
	}
	return c;
}


static void http_follow_url(zstream_t *stream) {
	zstream_http_t *http = stream->data;
	char *url = NULL;
	struct http_header *hdr;
	list_for_each_entry(hdr, &http->header_out, _head) {
		if (!strcasecmp(hdr->key, "location")) {
			url = hdr->val;
			break;
		}
	}
	if (!url)
		return;

	if (strstr(url, "http://") != url && strstr(url, "https://") != url) {
		char *urlbuf = malloc(strlen(stream->url) + strlen(url) + 2);
		if (!urlbuf) {
			return;
		}
		char *c;
		if (*url == '/') {
			url++;
			c = strchr(stream->url + strlen(stream->proto) + 3, '/');
		} else {
			char *d = strchr(stream->url, '?');
			c = strrchr((d) ? d : stream->url, '/');
		}
		if (c) {
			*c = 0;
		}

		sprintf(urlbuf, "%s/%s", stream->url, url);
		url = urlbuf;
	} else {
		url = strdup(url);
	}

	zstream_url_free(stream);
	zstream_url_parse(stream, url);
	free(url);
}


static int http_commit(zstream_t *stream) {
	zstream_http_t *http = stream->data;
	if (!(stream->status & ZSTREAM_IO_CONNECTED)) {
		int s = http_connect(stream);
		if (s) {
			return s;
		}
	}

	if (http->remaining || http->chunkremain)
		return -(errno = ESPIPE);

	stream->status &= ~ZSTREAM_DATA_WRITABLE;

	if (stream->status & HTTP_WRITE_CHUNKED) {
		fputs("0\r\n\r\n", http->transport);
		stream->status &= ~HTTP_WRITE_CHUNKED;
	}

	http->remaining = http->chunkremain = 0;

	char lbuf[ZSTREAM_BUFFER_SIZE], *line;
	while ((line = fgets(lbuf, sizeof(lbuf), http->transport))) {
		http_normalize(line);
		if (!http->status) {
			if (!*line) {
				continue;
			}
			char *c = strchr(line, ' '), *d;
			if (!c++ || !(d = strchr(c, ' ')) || !(http->status = atoi(c))) {
				return (http->status = -(errno = EPROTO));
			}
			if (http->status == 100) {
				http->status = 0;
				continue;
			}
			continue;
		}

		if (!*line) {
			int s = http->status;
			if (s == 301 || s == 302 || s == 303 || s == 307) {
				http_follow_url(stream);
				if (http->linkdepth) {
					int ld = http->linkdepth - 1;

					char *u = strdup(stream->url);
					s = http_reopen(stream, u);
					free(u);

					if (s < 0)
						return s;
					http->linkdepth = ld;
					return http_commit(stream);
				}
				errno = ELOOP;
			} else if ((stream->status & HTTP_RANGE) && s != 206) {
				errno = EPROTO;
			} else if (s == 200 || s == 201 || s == 202 || s == 206) {
				http->remaining = http->size;
				stream->status |= ZSTREAM_IO_COMMITED;
				return 0;
			} else {
				errno = http_error_code(http->status);
			}
			break;
		}

		char *c = strchr(line, ':');
		if (!c) {
			stream->status |= ZSTREAM_IO_COMMITED | ZSTREAM_IO_COMPLETED;
			return (http->status = -(errno = EPROTO));
		}

		*c = 0;
		while (isspace(*++c));

		size_t vallen = strlen(c);
		if (!vallen)
			goto out;
		struct http_header *hdr = malloc(sizeof(*hdr) + vallen + 1);
		if (hdr) {
			hdr->val[vallen] = hdr->key[sizeof(hdr->key) - 1] = 0;
			strncpy(hdr->key, line, sizeof(hdr->key) - 1);
			memcpy(hdr->val, c, vallen);
			list_add(&hdr->_head, &http->header_out);
		}

		if (!strcmp(line, "Transfer-Encoding") && strstr(c, "chunked")){
			stream->status |= HTTP_READ_CHUNKED;
		} else if (!strcmp(line, "Content-Length")) {
			http->size = atoll(c);
		} else if (!strcmp(line, "Content-Type")) {
			http->type = hdr->val;
		} else if (!strcmp(line, "Last-Modified")) {
			struct tm t;
			http->mtime = (strptime(c, "%a, %d %h %Y %T GMT", &t))
				? timegm(&t) : 0;
		} else if (!strcmp(line, "Set-Cookie")) {
			http_addcookie(stream, hdr->val, stream->host, stream->path);
		}
	}

out:
	if (errno != EAGAIN) {
		http->status = -errno;
		stream->status |= ZSTREAM_IO_COMMITED | ZSTREAM_IO_COMPLETED;
	}
	return (http->status = -errno);
}

static ssize_t http_recvmsg(zstream_t *stream, zstream_req_t *req) {
	zstream_http_t *http = stream->data;
	req->name = stream->url;

	if (stream->status & ZSTREAM_IO_COMPLETED) {
		return http_error_code(http->status);
	} else if (!(stream->status & ZSTREAM_IO_COMMITED)) {
		http->offset = req->offset;
		int s = http_commit(stream);
		req->name = stream->url;
		if (s) {
			return s;
		}
	}

	if (req->offset && req->offset != http->offset)
		return -(errno = EALREADY);

	req->size = http->size;
	req->offset = http->offset;
	req->time = http->mtime;
	req->type = http->type;

	size_t rxed = 0, len = req->len;
	uint8_t *buf = req->data;

	if (http->remaining && len > http->remaining
	&& !(stream->status & HTTP_READ_CHUNKED))
		len = http->remaining;

	while (len) {
		if ((stream->status & HTTP_READ_CHUNKED) && !http->chunkremain) {
			char linebf[128];
			if (fgets(linebf, sizeof(linebf), http->transport)) {
				if (isspace(*linebf))
					continue;
				if (!(http->chunkremain = strtoll(linebf, NULL, 16))) {
					stream->status |= ZSTREAM_IO_COMPLETED;
					len = 0;
					break;
				}
			} else {
				break;
			}
		} else {
			ssize_t recvc = (http->chunkremain && http->chunkremain < len)
				? http->chunkremain : len;
			if ((recvc = fread(buf, 1, recvc, http->transport))) {
				rxed += recvc;
				len -= recvc;
				buf += recvc;
				if (http->chunkremain)
					http->chunkremain -= recvc;
			} else {
				break;
			}
		}
	}

	if (rxed && http->remaining) {
		if ((http->remaining -= rxed) == 0)
			stream->status |= ZSTREAM_IO_COMPLETED;
	} else if (len && !rxed && errno != EAGAIN) {
		stream->status |= ZSTREAM_IO_COMPLETED;
	}
	return (rxed || !len || feof(http->transport))
			? rxed : (http->status = -errno);
}

static ssize_t http_sendmsg(zstream_t *stream, zstream_req_t *req) {
	zstream_http_t *http = stream->data;
	if ((stream->status & (ZSTREAM_IO_COMPLETED | ZSTREAM_IO_COMMITED))
	|| !(stream->status & ZSTREAM_DATA_WRITABLE)) {
		return -(errno = EPIPE);
	} else if (!(stream->status & ZSTREAM_IO_CONNECTED)) {
		http->size = req->size;
		http->type = req->type;
		int s = http_connect(stream);
		http->type = NULL;
		if (s)
			return s;
	}

	if ((req->type && strcmp(req->type, (http->type) ? http->type : ""))
	|| (req->size && req->size != http->size))
		return -(errno = EALREADY);


	size_t txed = 0;
	size_t len = req->len;
	uint8_t *buf = req->data;

	if (len > http->remaining && !(stream->status & HTTP_WRITE_CHUNKED))
		len = http->remaining;

	while (len) {
		if ((stream->status & HTTP_WRITE_CHUNKED) && !http->chunkremain) {
			fprintf(http->transport, "%lx\r\n", (unsigned long)len);
			http->chunkremain = len;
		} else {
			ssize_t sendc = (http->chunkremain && http->chunkremain < len)
				? http->chunkremain : len;
			if ((sendc = fwrite(buf, 1, sendc, http->transport))) {
				txed += sendc;
				len -= sendc;
				buf += sendc;
				if ((stream->status & HTTP_WRITE_CHUNKED)
				&& (http->chunkremain -= sendc) == 0)
					fputs("\r\n", http->transport);
			} else {
				break;
			}
		}
	}

	if (txed && http->remaining) {
		http->remaining -= txed;
	} else if (len && !txed && errno != EAGAIN) {
		stream->status |= ZSTREAM_IO_COMPLETED;
	}
	return (txed || !len) ? txed : (http->status = -errno);
}

ZSTREAM_HANDLER(http, handler_http)
ZSTREAM_HANDLER(https, handler_http)
